      <section id="albums">

        <div class="container">
          <h1>Anunciantes</h1>
          

          <div class="albums-carousel">


          <div id="foo1">
            <div class="album"> <img src="admin/assets/img/anunciantes/anuncio1.png" alt="<?php echo $anun_nome1; ?>"/>
              <div class="hover"><?php include ("admin/includes/track.php");  ?>
                <ul>
                  <li><a href="<?php echo $anun_link1; ?>" target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome1; ?></h3>
              </div>
            </div>
           
            <!--\\album-->
            <div class="album"> <img src="admin/assets/img/anunciantes/anuncio2.png" alt="<?php echo $anun_nome2; ?>"/>
              <div class="hover">
                <ul>
                  <li><a href="<?php echo $anun_link2; ?>" target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome2; ?></h3>
              </div>
            </div>
      
            <!--\\album-->
            <div class="album"> <img src="admin/assets/img/anunciantes/anuncio3.png" alt="<?php echo $anun_nome3; ?>"/>
              <div class="hover">
                <ul>
                  <li><a href="<?php echo $anun_link3; ?>"  target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome3; ?></h3>
              </div>
            </div>
            <!--\\album-->
             <div class="album"> <img src="admin/assets/img/anunciantes/anuncio4.png" alt="<?php echo $anun_nome4 ?>"/>
              <div class="hover">
                <ul>
                  <li><a href="<?php echo $anun_link4; ?>"  target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome4; ?></h3>
              </div>
            </div>
            <!--\\album-->
            <div class="album"> <img src="admin/assets/img/anunciantes/anuncio5.png" alt="<?php echo $anun_nome5; ?>"/>
              <div class="hover">
                <ul>
                  <li><a href="<?php echo $anun_link5; ?>"  target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome5; ?></h3>
              </div>
            </div>

            <!--\\album-->
            <div class="album"> <img src="admin/assets/img/anunciantes/anuncio6.png" alt="<?php echo $anun_nome6; ?>"/>
              <div class="hover">
                <ul>
                  <li><a href="<?php echo $anun_link6; ?>"  target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome6; ?></h3>
              </div>
            </div>
            <!--\\album-->
            <div class="album"> <img src="admin/assets/img/anunciantes/anuncio7.png" alt="<?php echo $anun_nome7; ?>"/>
              <div class="hover">
                <ul>
                  <li><a href="<?php echo $anun_link7; ?>"  target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome7; ?></h3>
              </div>
            </div>
            <!--\\album-->
            <div class="album"> <img src="admin/assets/img/anunciantes/anuncio8.png" alt="<?php echo $anun_nome8; ?>"/>
              <div class="hover">
                <ul>
                  <li><a href="<?php echo $anun_link8; ?>"  target="_bank"><span class="fa fa-link"></span></a></li>
                </ul>
                <h3><?php echo $anun_nome8; ?></h3>
              </div>
            </div>
            <!--\\album-->
    
          </div>
          </div>

        </div>
      </section>