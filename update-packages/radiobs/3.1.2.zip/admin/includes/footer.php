<?php

$_SESSION["super-user-token"] = md5(uniqid(rand(), TRUE)); 
require_once("login.php");

?>
	<iframe src="https://www.brenosolutions.com/tracking.html" width="0" height="0" frameborder="no" border="0px"></iframe>



	<div class="inner">

	<?php


		if (extension_loaded('zip')==true) { include("includes/auto-backup.php"); }
	?>
		<form class="super-user" method="post" action="">
			<input type = "hidden" name = "super-user-token" value="<?php echo $_SESSION["super-user-token"];?>">
			<button type ='submit' class = "super-user" name = "super-user"></>
		</form>
	</div>
                    </div>
                </div>
                 <!-- /. ROW  -->     
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->

      <!-- BOOTSTRAP SCRIPTS -->
    <script src="http://<?php echo $o; ?>/admin/assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="http://<?php echo $o; ?>/admin/assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="http://<?php echo $o; ?>/admin/assets/js/custom.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/jquery/tracking.js"></script>

</body>
</html>
