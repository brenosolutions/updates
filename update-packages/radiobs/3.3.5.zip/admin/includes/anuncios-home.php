<?php

error_reporting(0);
include_once("path.php");
include_once("helpers/functions.php");
include_once("helpers/anuncios_lib.php");


// Get Conteudo
$get_anuncios = new show_Anuncios;

// Mostrar anuncios
foreach ($get_anuncios->get_blog_anuncios(999) as $anuncios) {
	echo "<div class=\"album\">
	<img src=\"admin/assets/img/anunciantes/$anuncios[7]\" alt=\"$anuncios[5]\"/><div class=\"hover\">
	<ul>
		<li><a href=\"$anuncios[4]\" target=\"_bank\"><span class=\"fa fa-link\"></span></a></li>
	</ul>
	<h3>$anuncios[5]</h3>
	</div>
	</div>";

	} 

// Fim

?>

