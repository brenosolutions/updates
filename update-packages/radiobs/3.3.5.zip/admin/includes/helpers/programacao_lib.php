<?php

class read_File_Programacao{
	
	function __construct($name){		
		$this->name = $name;	
		
		if($this->name == "programacao"){$this->name = ROOTPATH . "/data/programacao/programacaofile.txt";}
		else if($this->name == "comment"){$this->name = ROOTPATH . "/data/programacao/programa.txt";}
		else { echo $lang_blog_error_reading;}			
	 }	

	function getData(){
		$open = fopen($this->name , "r");
		$data = @fread($open, filesize($this->name));
		fclose($open);		
		return $data;		
	}	

	function getLines(){				
		$lines = explode("\n", $this->getData());
		return $lines;
	}
	
	function countLines(){	
		$amount_of_lines = count($this->getLines());
		return $amount_of_lines-1;		
	}	
	
}//end class


class show_Programacao{

    function __construct(){	
    	$this->blog_file_1 = new read_File_Programacao("programacao");
		$this->amount      = $this->blog_file_1->countLines();
		$this->lines       = $this->blog_file_1->getLines();    
	}	
	
	function val_programacao($test){
			
		if (isset($test) && strlen($test > 0) && is_numeric($test)) {
			   return true;
		}
	    return false; 
	}	

	function get_blog_programa($id_post){
			
		for ($i = 0; $i < $this->amount; $i++) { 
	        $blog = explode("|", $this->lines[$i]);
				 
			if ($blog[0] == $id_post) {
		    	$no_posts_found++;
				$date     = explode( ' ' , $blog[2]);
				$date     = $date[2] . ' ' . $date[1]  . ' ' . $date[3];
				$title    = cleanUrlname($blog[3]);
				$blog_0   = $blog[0];
			
				$blogfile = array($no_posts_found, $blog_0, $date, $title , $blog[4], $blog[1], $blog[3], $blog[5]);			
			}
		}
			return $blogfile;
	}	


	function amount_pages_programacao($per_page){
	
		$result_per_page = $per_page ; 
		$total_pages     = ceil($this->amount/$result_per_page);
		$cur_page        = $_GET['page'] ? $_GET['page'] : 1;

		$start = $this->amount - (($cur_page-1) * $result_per_page);
		$end   = $this->amount - (($cur_page) * $result_per_page);
		
		$nums = array($total_pages, $cur_page, $start, $end);

		return $nums;
	}
	
	function get_blog_programacao($per_page,$lang_blog_more){

		$nums = $this->amount_pages_programacao($per_page);

	    for ($n = $nums[2]-1; $n >= $nums[3]; $n-- ) { 
	    
		    $blog = explode("|", $this->lines[$n]);
		
		    if (isset($blog[0]) && $blog[0] != '') {
			
			    
			    $blogposts[] = array($blog[0], $blog[1], $blog[2], $blog[3], $blog[4], $blog[5], $blog[6], $blog[7]);
			 }
		}
		return $blogposts;
	}

		
}	
	
class add_Content_Programacao{

		function __construct($name,$data){		
		$this->name = $name;
		$this->data = $data;	
		
		if($this->name == "programacao"){$this->name = ROOTPATH . "/data/programacao/programacaofile.txt";}
		else if($this->name == "comment"){$this->name = ROOTPATH . "/data/programacao/programa.txt";}
		else { echo $lang_blog_error_reading;}
		}
		
		function appendData(){
			$open = fopen($this->name, "a");
			fwrite($open, $this->data);
			fclose($open);
		}
		
		function writeData(){			
			$open = fopen($this->name, "w");
			fwrite($open, $this->data);
			fclose($open);			
		}	
				
				
}//end class


//sanatize input
function super_clean_programacao($text){	
	$text = trim(stripslashes(strip_tags(htmlspecialchars($text, ENT_QUOTES, 'UTF-8'))));	
	return $text;
}

?>