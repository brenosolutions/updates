<?php

error_reporting(0);
include_once("path.php");
include_once(ROOTPATH."../../config.php");
include_once("helpers/functions.php");
include_once("helpers/locutores_lib.php");


// Get Conteudo
$get_locutores = new show_Locutores;

// Mostrar anuncios
foreach ($get_anuncios->get_blog_locutores(999) as $locutor) {
	echo "<div class=\"album\">
	<img src=\"admin/assets/img/locutores/$locutor[7]\" alt=\"$locutor[5]\"/><div class=\"hover\">
	<ul>
		<li><a href=\"$locutor[4]\" target=\"_bank\"><span class=\"fa fa-link\"></span></a></li>
	</ul>
	<h3>$locutor[5]</h3>
	</div>
	</div>";

	} 

// Fim

?>

