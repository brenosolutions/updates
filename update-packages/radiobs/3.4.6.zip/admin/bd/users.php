<?php
$perm_loc_page_sobre = "0";
$perm_loc_pub_slider = "0";
$perm_loc_pub_anuncios = "0";
$perm_loc_pub_equipe = "0";
$perm_loc_pub_videos = "0";
$perm_loc_pub_fotos = "0";
$perm_loc_pub_noticias = "0";
$perm_loc_pub_eventos= "0";
$perm_loc_pub_widgets = "0";

$perm_loc_msg_pedido = "1";
$perm_loc_msg_papo = "1";
$perm_loc_msg_mural = "1";

$perm_loc_aut_loc = "1";
$perm_loc_aut_prog = "1";
$perm_loc_aut_config = "1";

$perm_loc_config_site = "0";
$perm_loc_config_tema = "0";
$perm_loc_config_play = "1";
$perm_loc_config_stream = "1";
$perm_loc_config_cam = "0";
$perm_loc_config_top = "1";
$perm_loc_config_enquete = "1";
$perm_loc_config_recados = "1";
$perm_loc_config_ouvinte = "1";
$perm_loc_config_doacao = "0";

$perm_loc_ajuda_update = "0";
$perm_loc_ajuda_license = "1";
$perm_loc_ajuda_soft = "1";
?>