<section id="contact">
	<form action="pedido.php" method="post">
		<h5><?php echo $lang_nome; ?>:</h5>
		<input type="text" id="nome" name="nome" required />

		<h5><?php echo $lang_email; ?>:</h5>
		<input type="text" name="email" id="email" required/>

		<h5><?php echo $lang_seu_pedido; ?>:</h5>
		<textarea name="pedido" id="message" required></textarea>
		<br/>
		<center>
			<button id="submit1" type="submit" name="enviar"><?php echo $lang_enviar; ?></button>
		</center>
	</form>
	<div id="valid-issue" style="display:none;"> <?php echo $lang_info_validas; ?></div>   
</section>