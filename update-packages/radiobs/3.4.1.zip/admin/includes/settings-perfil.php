<div class="col-md-12">
<br/>
<h2><?php echo $lang_perfil; ?></h2>
<br/>
</div>
<div class="col-md-6">
<div class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo $lang_perfil_alterar_foto; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<?php
/* VERIFICO SE HOUVE O ENVIO DE UM ARQUIVO  */
if(count($_FILES) > 0) {
	
	/* RECUPERO TODAS AS INFORMAÇÕES POSSÍVEIS DO ARQUIVO */		
	$nome      = 'usuario.png';
	$tamanho   = $_FILES['arquivo']['size'];
	$tipo      = $_FILES['arquivo']['type'];
	$nome_temp = $_FILES['arquivo']['tmp_name'];	
	
	$erros = array();
	  

	/* VERIFICO SE O ARQUIVO ENVIADO É DO TIPO IMAGEM */
	if($tipo == 'image/jpeg' || $tipo == 'image/png' || $tipo == 'image/jpg' || $tipo == 'image/gif' || $tipo == 'image/bmp') {
		/* 
		VERIFICO SE O TAMANHO NÃO ULTRAPASSA 2Mb 
		O CALCULO DEVE SER REALIZADO EM BYTES.
		*/
		
		if($tamanho <= 10097152) {
			$pasta = './assets/img/';
			/* VERIFICO SE A PASTA NÃO EXISTE, SE ELA NÃO EXISTIR, EU CRIO A PASTA */
			if(!file_exists($pasta)) {
				mkdir($pasta, 0777);
			}
			
			/* 
			TENTO ENVIAR O ARQUIVO PARA A PASTA arquivos QUE ESTÁ LOCALIZADA NA RAIZ DO MEU PROJETO 
			*/
			
			if(move_uploaded_file($nome_temp, $pasta.$nome)) {
				/* SE ESTIVER TUDO OK, REDIRECIONO PARA UMA PÁGINA DE SUCESSO */
				$erros['logo'] = $lang_foto_sucessso;
			} else {
				$erros['pasta'] = $lang_pasta_correta;		
			}
		} else {
			$erros['tamanho'] = $lang_tamanho_max.': <strong>10Mb</strong>';	
		}
	} else {
		$erros['tipo'] = $lang_img_suporte.': <strong>png, jpg, jpeg, gif e bmp</strong>';		
	}
	
}
?>

<form id="upload" method="post" enctype="multipart/form-data" >

			<img id="output" src="assets/img/usuario.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
			<br/><?php echo $lang_tamanho_recomendado; ?>: 215x215 pixels.

            <input type="file" id="arquivo" name="arquivo" accept="image/*" onchange="loadFile(event)" />
			<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>

<br/>
        	<button class="btn btn-default" type="submit" id="enviar" value="Enviar"><i class="fa fa-refresh"></i> <?php echo $lang_alterar; ?></button>

</form>

<?php if(isset($erros)) { ?>
<div id="erros">
<?php foreach($erros as $e) { ?>

    	<p><?php echo $e; ?></p>

<?php	
}
?>
</div><!-- #erros -->
<?php } ?>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							<?php echo $lang_info_basicas; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form role="form" action = "index.php?p=settings-perfil" method = "post">

<?php

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_perfil = '<?php
$perfil_nome = "'. $perfil_nome .'";
$perfil_mail = "'. $perfil_mail .'";
$perfil_sexo = "'. $perfil_sexo .'";
$perfil_cidade = "'. $perfil_cidade .'";
$perfil_nascimento_dia = "'. $perfil_nascimento_dia .'";
$perfil_nascimento_mes = "'. $perfil_nascimento_mes .'";
$perfil_nascimento_ano = "'. $perfil_nascimento_ano .'";
$pulse_pass = "'. $password .'";
?>';

            if ($fp = fopen("bd/perfil.php", "w")) {
                fwrite($fp, $config_perfil, strlen($config_perfil));

                $_SESSION["saved"]=true;
				header("Location: index.php?p=settings-perfil");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_config_gravavel</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


	<div class="form-group">
	    <label><?php echo $lang_nome; ?></label>
	    <input class="form-control" type="text" name="perfil_nome" value="<?php echo $perfil_nome; ?>" />
	</div>

	<div class="form-group">
	    <label><?php echo $lang_email; ?></label>
	    <input class="form-control" type="email" name="perfil_mail" value="<?php echo $perfil_mail; ?>" />
	</div>

	<div class="form-group">
	   <label><?php echo $lang_sexo; ?></label>
	   <select class="form-control" name="perfil_sexo">

	   <?php
	   $perfil_sexo_options = array(
	      array($lang_masculino,'Masculino'),
	   		array($lang_geminino,'Feminino')
	   		);

	   foreach ($perfil_sexo_options as $perfil_sexo_option) {

		?><option value = "<?php echo $perfil_sexo_option[1]; ?>"<?php echo $perfil_sexo == $perfil_sexo_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($perfil_sexo_option[0]); ?></option><?php
			  } ?>
	   </select>
	</div>

	<div class="form-group">
	    <label><?php echo $lang_cidade; ?></label>
	    <input class="form-control" type="text" name="perfil_cidade" value="<?php echo $perfil_cidade; ?>" />
	</div>


	<div class="form-group">
		<div class="form-group">
			<label><?php echo $lang_data_nascimento; ?></label>
			<br/>
			<input type="text" name="perfil_nascimento_dia" size="2" maxlength="2" value="<?php echo $perfil_nascimento_dia; ?>"> 
			<input type="text" name="perfil_nascimento_mes" size="2" maxlength="2" value="<?php echo $perfil_nascimento_mes; ?>"> 
			<input type="text" name="perfil_nascimento_ano" size="4" maxlength="4" value="<?php echo $perfil_nascimento_ano; ?>">
		</div>
	</div>

	<div class="form-group">
	   <label><?php echo $lang_senha; ?> <?php echo $lang_painel; ?></label>
	   <input class="form-control" type="password" name="password" value="<?php echo $pulse_pass; ?>"/>
   </div>

    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 
  <?php greenCheckmark();?>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>