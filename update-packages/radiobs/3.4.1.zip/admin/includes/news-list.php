<?php

error_reporting(0);

include_once("path.php");
include_once(ROOTPATH."../../config.php");
include_once("lang/$pulse_lang.php");
include_once("helpers/functions.php");
include_once("helpers/news_lib.php");

$get_blog = new show_Blogs;


?> 

<style type="text/css">
	.link-none{
		padding-left: 0 !important;
    	margin-bottom: 0 !important;

	}
</style>



<?php
if ($get_blog->val_d($_GET["d"]) == true) {	

} else { 

// Show all posts
foreach ($get_blog->get_blog_posts(5, $lang_blog_more) as $post) {

	$news_list = substr($post[4], 0, 100);
	$news_txt = strip_tags($news_list, '');

	echo "<div class='col-md-12'>";
	echo "<div class='news-feed news-home-post'> 
		  <a class='link-none' href='news-$post[0]-$post[3]'><img src='admin/assets/img/news/$post[8]' alt='$post[5]'></a>
		  <a href='news-$post[0]-$post[3]'>$post[5]</a>
          <p>$news_txt...</p>
          </div>";
    echo "</div>";
}

// Pagination

}
?>