<script src="plugins/jquery/jquery.min.js"></script>
