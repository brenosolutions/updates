<?php
require_once("login.php");
require_once("helpers/img.php");


$on = 'anuncios';

if (!empty($_POST)) {
	$filename = "data/anuncios/anunciosfile.txt";

	if (isset($_POST['message'])) {
		$date    = $_POST['banner'];
		$subject = $_POST['subject'];
		$message = $_POST['message'];

		$date = $_FILES['banner']['name'];
		$image_error = $_FILES['banner']['error'];
		$image_type = $_FILES['banner']['type'];
// common image file extensions
		$allowedExts = array("gif", "jpeg", "jpg", "png");
		
			// get image file extension
		error_reporting(E_ERROR | E_PARSE);
		$extension = end(explode(".", $_FILES["banner"]["name"]));
		
		if($image_error > 0){
			$error['banner'] = " <span class='label label-danger'>Você não inseriu a imagens!</span>";
		}else if(!(($image_type == "image/gif") || 
			($image_type == "image/jpeg") || 
			($image_type == "image/jpg") || 
			($image_type == "image/x-png") ||
			($image_type == "image/png") || 
			($image_type == "image/pjpeg")) &&
		!(in_array($extension, $allowedExts))){
			
			$error['banner'] = " <span class='label label-danger'>Imagem no formato jpg, jpeg, gif, ou png!</span>";
		}
		
		if(!empty($date) && empty($error['banner'])){
			
				// create random image file name
			$string = '0123456789';
			$file = preg_replace("/\s+/", "_", $_FILES['banner']['name']);
			$function = new functions;
			$date = $function->get_random_string($string, 4)."-".date("Y-m-d").".".$extension;
			
				// upload new image
			$upload = move_uploaded_file($_FILES['banner']['tmp_name'], 'assets/img/anunciantes/'.$date);
		}


		$fp   = fopen($filename,"r") or die($lang_erro_leitura); 
		$data = @fread($fp, filesize($filename));
		fclose($fp);
		
		$line = explode("\n", $data);
		$no_of_posts = count($line)-1;
		
		
		for ($i=0; $i<$no_of_posts; $i++) {
			$blog = explode("|", $line[$i]);
			$posts[$i] = $blog[0];
		}
		
		if(count($posts) > 0) {
			$no_of_posts = max($posts)+1;
		} else {
			$no_of_posts = 1;
		}
		
		$subject = htmlspecialchars(trim(stripslashes($subject)), ENT_QUOTES, "UTF-8");
		$message = strip_tags(stripslashes($message), "<p><center><u><strong><audio><iframe><del><link><object><fieldset><dl><dt><dt><colgroup><col><font><label><embed><a><pre><b><i><style><table><tbody><td><textarea><tfoot><th><thead><title><tr><tt><ul><li><ol><img><h1><h2><h3><h4><h5><hr><address><span><div><blockquote><br><br /><button>");

		$message  = trim($message);
		$message  = str_replace("\n", "", $message);
		$message  = str_replace("\r", "", $message);
		$message  = str_replace("|", "&brvbar;", $message);

		$blog = $no_of_posts ."|0|". $date ."|". $subject ."|". $message."\n";

		$data = fopen($filename, "a");
		fwrite($data, $blog);
		fclose($data);
		
		header("Location: index.php?p=manage-anuncios");
		die();
	}
}

?>
<div class="col-md-12">

	<div id="panel-body">
		<br/>
		<a class="btn btn-primary" href="index.php?p=manage-anuncios"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>
		<button onclick="document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button>
	</div>
	<br />


	<!-- Advanced Tables -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<?php echo $lang_novo_anuncio; ?>
		</div>
		<div class="panel-body">
			<div class="table-responsive">
				<div id="" class="max">

					<form class="editor" name="editor" action="" method="post" enctype="multipart/form-data">
						<label><?php echo $lang_nome; ?></label>
						<input class="form-control" type="text" name="subject"  value="" required>
						<br/>

						<label><?php echo $lang_site; ?></label>
						<input class="form-control" type="text" name="message" placeholder="http://site.com.br"/ required>

						<br>

						<label><?php echo $lang_banner; ?></label>
						<img id="output" src="" width="209" height="auto" />
						<br/><?php echo $lang_tamanho_recomendado; ?>: 270x270 pixels.
						<input type="file" name="banner" value="" accept="image/*" class="default" onchange="loadFile(event)" required>

						<script>
							var loadFile = function(event) {
								var output = document.getElementById('output');
								output.src = URL.createObjectURL(event.target.files[0]);
							};
						</script>


					</form>

				</div>
			</div>
			
		</div>
	</div>
	<!--End Advanced Tables -->
</div>