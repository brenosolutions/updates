<div class="col-md-12">
<br/>
<h2><?php echo $lang_artista; ?> 4</h2>
<br/>
</div>
<div class="col-md-6">
<a class="btn btn-primary" href="index.php?p=settings-top5"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>
<br/>
<br/>
<div class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo $lang_alterar_foto_artista; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<?php
/* VERIFICO SE HOUVE O ENVIO DE UM ARQUIVO  */
if(count($_FILES) > 0) {
	
	/* RECUPERO TODAS AS INFORMAÇÕES POSSÍVEIS DO ARQUIVO */		
	$nome      = 'artista4.png';
	$tamanho   = $_FILES['arquivo']['size'];
	$tipo      = $_FILES['arquivo']['type'];
	$nome_temp = $_FILES['arquivo']['tmp_name'];	
	
	$erros = array();
	  

	/* VERIFICO SE O ARQUIVO ENVIADO É DO TIPO IMAGEM */
	if($tipo == 'image/jpeg' || $tipo == 'image/png' || $tipo == 'image/jpg' || $tipo == 'image/gif' || $tipo == 'image/bmp') {
		/* 
		VERIFICO SE O TAMANHO NÃO ULTRAPASSA 2Mb 
		O CALCULO DEVE SER REALIZADO EM BYTES.
		*/
		
		if($tamanho <= 10097152) {
			$pasta = './assets/img/artistas/';
			/* VERIFICO SE A PASTA NÃO EXISTE, SE ELA NÃO EXISTIR, EU CRIO A PASTA */
			if(!file_exists($pasta)) {
				mkdir($pasta, 0777);
			}
			
			/* 
			TENTO ENVIAR O ARQUIVO PARA A PASTA arquivos QUE ESTÁ LOCALIZADA NA RAIZ DO MEU PROJETO 
			*/
			
			if(move_uploaded_file($nome_temp, $pasta.$nome)) {
				/* SE ESTIVER TUDO OK, REDIRECIONO PARA UMA PÁGINA DE SUCESSO */
				$erros['logo'] = $lang_foto_sucessso;
			} else {
				$erros['pasta'] = $lang_pasta_correta;
			}
		} else {
			$erros['tamanho'] = $lang_tamanho_max.': <strong>10Mb</strong>';
		}
	} else {
		$erros['tipo'] = $lang_img_suporte.': <strong>png, jpg, jpeg, gif e bmp</strong>';		
	}
	
}
?>

<form id="upload" method="post" enctype="multipart/form-data" >

			<img id="output" src="assets/img/artistas/artista4.png?img=<?php echo urlencode($cache_today); ?>" width="220" height="auto" />
			<br/><?php echo $lang_tamanho_recomendado; ?>: 220x130 pixels.

            <input type="file" id="arquivo" name="arquivo" accept="image/*" onchange="loadFile(event)" />
			<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>

<br/>
        	<button class="btn btn-default" type="submit" id="enviar" value="Enviar"><i class=" fa fa-refresh "></i> <?php echo $lang_alterar; ?></button>

</form>

<?php if(isset($erros)) { ?>
<div id="erros">
<?php foreach($erros as $e) { ?>

    	<p><?php echo $e; ?></p>

<?php	
}
?>
</div><!-- #erros -->
<?php } ?>
</div>
</div>
</div>
</div>
