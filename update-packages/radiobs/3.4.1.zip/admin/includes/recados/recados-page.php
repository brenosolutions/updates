

<?php

error_reporting(0);

include_once("admin/bd/mural.php");
include_once("admin/includes/path.php");
include_once("admin/includes/helpers/recados_lib.php");



// Get Conteudo

$get_recados = new show_Recados;

?>



<?php


if ($get_recados->val_recados($_GET["d"]) == true) {	



} else{ 



// Show all posts
?>
	<article class="post-comments">

<?php
foreach ($get_recados->get_blog_Recados($mural_pag, '') as $recado) {?>

		<div class="comment-read">
			<div class="comment-reply">
				<b class="fa fa-user"></b>
				<h3><?php echo $recado[3]; ?></h3>
				<h4><?php echo $recado[2]; ?></h4>
				<h5><?php echo $recado[4]; ?></h5>
				
				<p><?php echo $recado[5]; ?></p>
			</div>
		</div>

<?php }?>
	</article>

<?php
// Pagination

echo '<br><div class="news-feed-btn row">';

$nums = $get_recados->amount_pages_recados($mural_pag);

if ($nums[1] < $nums[0]) { echo "<a href=\"mural-page-".($nums[1]+1)."\">$lang_proximo ></a>"; }

if ($nums[1] > 1) { echo  "<a href=\"mural-page-".($nums[1]-1)."\">< $lang_anterior</a>"; }

echo '</div>';

}

// Fim



?>

