
<?php 
	
$on = 'images'; 
require_once("login.php");

?>

<div class="col-md-12">
<h2><?php echo $lang_albuns_foto; ?></h2>   
<br/>
<div id="panel-body">
	<a class="btn btn-primary" href ="index.php?p=new-album"><i class="fa fa-plus-circle"></i> <?php echo $lang_novo; ?></a> 
</div>
<br/>

                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             <?php echo $lang_albuns_lista; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

	          
<?php 

$dir    = 'data/img/albuns/';
$handle = opendir($dir);
$nb     = 1;
	
while ($filename = readdir($handle)) {
	
     if ($filename != ".." 
         && $filename != "." 
         && is_dir($dir.$filename)) {
		 
	     echo '<div class="tab gallery">';
		 echo '<a href="index.php?p=gerenciar-fotos&g='. $filename  .'">'.  preg_replace("/-/", " ", $filename) .'</a>';
		 echo '</div>';
	
		 $albuns[$nb] = $filename;
		 $nb++; 
	  }
}			
	
if ($nb == 1) {
	echo $lang_vazio;
}
	
$_SESSION["albuns"] = $albuns;

?>	
</div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>