<?php 
require_once("login.php");


include_once("includes/path.php");
include_once(ROOTPATH."../../config.php");
include_once("includes/helpers/functions.php");
include_once("includes/helpers/locutores_lib.php");

$get_locutores = new show_Locutores;

$on = 'programacao'; 
$lang_page_title = 'Editar Programação'; 

$domain = $_SERVER['HTTP_HOST'];
$id     = strip_tags(stripslashes(trim($_GET['post_id'])));

$opFile = "data/programacao/programacaofile.txt";
$fp     = @fopen($opFile,"r") or die("$lang_erro_leitura"); 
$data   = @fread($fp, filesize($opFile));
fclose($fp);

$line   = explode("\n", $data);			
$no_of_posts = count($line)-1;

if (!empty($_POST)) {

	$id = $_POST['post_id'];
	$post_comment  = $_POST['post_comment'];
	$nome_programa = $_POST['nome_programa'];
	$nome_apresentador = $_POST['nome_apresentador'];
	$dia_semana = $_POST['dia_semana'];
	$hora_inicial = $_POST['hora_inicial'];
	$hora_final = $_POST['hora_final'];
	$status = $_POST['status'];

			
		for ($i = 0; $i < $no_of_posts; $i++){
	$blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){
		$edit_post_date    = $blog[2];
		break;
	}
}



	for ($i = 0; $i < $no_of_posts; $i++) {
		$blog = explode("|", $line[$i]);

		if ($blog[0] == $id) {	
			$new_data .=  $id .'|'.$post_comment.'|'. $nome_programa . '|' . $nome_apresentador . '|' . $dia_semana . '|'. $hora_inicial . '|'. $hora_final . '|'. $status . "\n";

		} else {
			$new_data .= $line[$i] . "\n";
		}
	}

	$file    = @fopen($opFile,"w") or die($lang_erro_leitura); 
	$success = fwrite($file, $new_data);
	fclose($file);

	if ($success == true) { 
		$_SESSION["saved"] = true;
	}

	header("Location: index.php?p=edit-programa&post_id=".$id);
	die();
}

for ($i = 0; $i < $no_of_posts; $i++){
	$blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){

		$data_post_comment = $blog[1];
		$data_nome_programa = $blog[2];
		$data_nome_apresentador = $blog[3];
		$data_dia_semana = $blog[4];
		$data_hora_inicial = $blog[5];
		$data_hora_final = $blog[6];
		$data_status = $blog[7];

		break;
	}
}
?> 

<div class="col-md-12">
	<div id="panel-body">
		<br/>
		<a class="btn btn-primary" href = "index.php?p=manage-programacao"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>
		<button onclick = "document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button>
	
	</div>
	<br/>
	<!-- Advanced Tables -->
	<div class="panel panel-default">
		<div class="panel-heading">
		<?php echo $lang_editar_programa; ?>
		</div>
		<div class="panel-body">
			<div class="table-responsive">

				<div id = "" class = "max">

					<form class="editor" method="post" name="editor" enctype="multipart/form-data">

						<input type="hidden" name="post_id" value="<?php echo $id; ?>" />

						<input type="hidden" name="post_comment" value="<?php echo $data_post_comment; ?>" />

						<label><?php echo $lang_nome_programa; ?></label>
						<input class="form-control" type="text" name="nome_programa" value="<?php echo $data_nome_programa; ?>">
						<br/>

						<label><?php echo $lang_nome_apresentador; ?></label>
						<select name="nome_apresentador" class="form-control">
							<option value="">...</option>
							<?php foreach ($get_locutores->get_blog_locutores(999) as $locutor) { ?>
								<?php echo "<option value='$locutor[3]' " ?>
									<?php 
										if ($locutor[3] == $data_nome_apresentador) {
											echo "selected";
										} 
									?>
									<?php echo ">$locutor[3]</option>";  ?>
								
							<?php } ?>
						</select>
						<br/>

						<input type="hidden" name="dia_semana" value="<?php echo $data_dia_semana; ?>">

						<label><?php echo $lang_dia_semana; ?></label>
						<select class="form-control" disabled>
							<option value="Mon" <?php if($data_dia_semana == 'Mon'){echo 'selected';} ?>><?php echo $lang_segunda; ?></option>
							<option value="Tue" <?php if($data_dia_semana == 'Tue'){echo 'selected';} ?>><?php echo $lang_terca; ?></option>
							<option value="Wed" <?php if($data_dia_semana == 'Wed'){echo 'selected';} ?>><?php echo $lang_quarta; ?></option>
							<option value="Thu" <?php if($data_dia_semana == 'Thu'){echo 'selected';} ?>><?php echo $lang_quinta; ?></option>
							<option value="Fri" <?php if($data_dia_semana == 'Fri'){echo 'selected';} ?>><?php echo $lang_sexta; ?></option>
							<option value="Sat" <?php if($data_dia_semana == 'Sat'){echo 'selected';} ?>><?php echo $lang_sabado; ?></option>
							<option value="Sun" <?php if($data_dia_semana == 'Sun'){echo 'selected';} ?>><?php echo $lang_domingo; ?></option>
						</select>
						<br/>

						<label><?php echo $lang_comeca; ?></label>
						<input type="time" name="hora_inicial" class="form-control" value="<?php echo $data_hora_inicial; ?>">
						<br/>

						<label><?php echo $lang_termina; ?></label>
						<input type="time" name="hora_final" class="form-control" value="<?php echo $data_hora_final; ?>">
						<br>

						<label>Status</label>
						<select name="status" class="form-control">
							<option value="ativo" <?php if($data_status == 'ativo'){ echo 'selected';} ?>><?php echo $lang_ativo; ?></option>
							<option value="inativo" <?php if($data_status == 'inativo'){ echo 'selected';} ?>><?php echo $lang_inativo; ?></option>
						</select>


					</form>
				</div>                            </div>

			</div>
		</div>
		<!--End Advanced Tables -->
	</div>