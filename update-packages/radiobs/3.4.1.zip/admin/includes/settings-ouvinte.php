<div class="col-md-12">
<br/>
<h2><?php echo $lang_ouvinte_do_mes; ?></h2>
<br/>
</div>

<div class="col-md-6">


<form role="form" action = "index.php?p=settings-ouvinte" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_ouvinte = '<?php
$ouvinte_nome = "'. $ouvinte_nome .'";
$ouvinte_facebook = "'. $ouvinte_facebook .'";
$ouvinte_instagram = "'. $ouvinte_instagram .'";
$ouvinte_twitter = "'. $ouvinte_twitter .'";
$ouvinte_mes = "'. $ouvinte_mes .'";

$ouvinst_select = "'. $ouvinst_select .'";
$ouvface_select = "'. $ouvface_select .'";
$ouvtw_select = "'. $ouvtw_select .'";
?>';

            if ($fp = fopen("bd/ouvinte.php", "w")) {
                fwrite($fp, $config_ouvinte, strlen($config_ouvinte));

                $_SESSION["saved"]=true;
				header("Location: index.php?p=settings-ouvinte");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_config_gravavel</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							<?php echo $lang_ouvinte_cadastro; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
    <div class="form-group">                
                <label>Foto</label>
                <br/>
                <img id="output" src="assets/img/ouvinte.png?img=<?php echo urlencode($cache_today); ?>" width="240" height="auto" />
                <br/><?php echo $lang_tamanho_recomendado; ?>: <?php echo $lang_largura; ?> 240 pixels.
                <script>
                    var loadFile = function(event) {
                    var output = document.getElementById('output');
                    output.src = URL.createObjectURL(event.target.files[0]);
                     };
                </script>
                <br/>
                <a class="btn btn-default" href="index.php?p=ouvinte" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_alterar; ?></a>
    </div>      


	<div class="form-group">
	    <label><?php echo $lang_nome; ?></label>
	    <input class="form-control" type="text" name="ouvinte_nome" value="<?php echo $ouvinte_nome; ?>" />
	</div>

	<div class="form-group">
	    <label>URL Facebook</label>
	    <input class="form-control" type="text" name="ouvinte_facebook" value="<?php echo $ouvinte_facebook; ?>" />
	             <select class="form-peq" name="ouvface_select">

     <?php
     $ouvface_select_options = array(
          array($lang_ativar,'fb.php'),
        array($lang_desativar,'off.php')
        );

     foreach ($ouvface_select_options as $ouvface_select_option) {

    ?><option value = "<?php echo $ouvface_select_option[1]; ?>"<?php echo $ouvface_select == $ouvface_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($ouvface_select_option[0]); ?></option><?php
        } ?>
     </select>
	</div>

    <div class="form-group">
        <label>URL Instagram</label>
        <input class="form-control" type="text" name="ouvinte_instagram" value="<?php echo $ouvinte_instagram; ?>" />
        	             <select class="form-peq" name="ouvinst_select">

     <?php
     $ouvinst_select_options = array(
          array($lang_ativar,'inst.php'),
        array($lang_desativar,'off.php')
        );

     foreach ($ouvinst_select_options as $ouvinst_select_option) {

    ?><option value = "<?php echo $ouvinst_select_option[1]; ?>"<?php echo $ouvinst_select == $ouvinst_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($ouvinst_select_option[0]); ?></option><?php
        } ?>
     </select>
    </div>

    <div class="form-group">
        <label>URL Twitter</label>
        <input class="form-control" type="text" name="ouvinte_twitter" value="<?php echo $ouvinte_twitter; ?>" />
        	<select class="form-peq" name="ouvtw_select">

     <?php
     $ouvtw_select_options = array(
          array($lang_ativar,'tw.php'),
        array($lang_desativar,'off.php')
        );

     foreach ($ouvtw_select_options as $ouvtw_select_option) {

    ?><option value = "<?php echo $ouvtw_select_option[1]; ?>"<?php echo $ouvtw_select == $ouvtw_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($ouvtw_select_option[0]); ?></option><?php
        } ?>
     	</select>
    </div>


      <div class="form-group">
     <label><?php echo $lang_ocultar_ouvinte; ?></label>
     <select class="form-control" name="ouvinte_mes">

     <?php
     $ouvinte_mes_options = array(
        array($lang_sim,'1'),
        array($lang_nao,'0')
        );

     foreach ($ouvinte_mes_options as $ouvinte_mes_option) {

    ?><option value = "<?php echo $ouvinte_mes_option[1]; ?>"<?php echo $ouvinte_mes == $ouvinte_mes_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($ouvinte_mes_option[0]); ?></option><?php
        } ?>
     </select>
  </div>

    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 

  </div>
</div>
</div> 


  <?php greenCheckmark();?>
    </form>

  

<?php } ?>
</div>