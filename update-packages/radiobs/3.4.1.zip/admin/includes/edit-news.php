<?php 
require_once("login.php");
require_once("helpers/img.php");
$on = 'news'; 
$lang_page_title = 'Editar Notícias'; 

$domain = $_SERVER['HTTP_HOST'];
$id     = strip_tags(stripslashes(trim($_GET['post_id'])));

$opFile = "data/news/newsfile.txt";
$fp     = @fopen($opFile,"r") or die("$lang_erro_leitura"); 
$data   = @fread($fp, filesize($opFile));
fclose($fp);

$line   = explode("\n", $data);			
$no_of_posts = count($line)-1;

if (!empty($_POST)) {
    $id       = $_POST['post_id'];
	$comments = $_POST['post_comment'];
	$date     = $_POST['post_date'];
	$title    = htmlspecialchars(trim(stripslashes($_POST['title'])), ENT_QUOTES, "UTF-8");
	$content  = strip_tags(stripslashes($_POST['content']), "<p><center><u><strong><del><audio><link><iframe><object><fieldset><dl><dt><dt><colgroup><col><font><label><em><embed><a><pre><b><i><style><table><tbody><td><textarea><tfoot><th><thead><title><tr><tt><ul><li><ol><img><h1><h2><h3><h4><h5><hr><address><span><div><blockquote><br><br /><button>");
	$content  = str_replace("\n", "", $content);
	$content  = str_replace("\r", "", $content);

	// get image info
	$banner = $_FILES['banner']['name'];
	$image_error = $_FILES['banner']['error'];
	$image_type = $_FILES['banner']['type'];
	
	// common image file extensions
	$allowedExts = array("gif", "jpeg", "jpg", "png");
	
	// get image file extension
	error_reporting(E_ERROR | E_PARSE);
	$extension = end(explode(".", $_FILES["banner"]["name"]));
	
	if(!empty($banner)){
		if(!(($image_type == "image/gif") || 
			($image_type == "image/jpeg") || 
			($image_type == "image/jpg") || 
			($image_type == "image/x-png") ||
			($image_type == "image/png") || 
			($image_type == "image/pjpeg")) &&
			!(in_array($extension, $allowedExts))){
			
			$error['banner'] = " <span class='label label-danger'>$lang_img_suporte: jpg, jpeg, gif, ou png!</span>";
		}
	}

	for ($i = 0; $i < $no_of_posts; $i++){
			$blog = explode("|", $line[$i]);
			
			if ($blog[0] != $id) continue;
			
			if ($blog[0] == $id){
				$img_atual    = $blog[5];
				break;
			}
		}



	if(!empty($banner)){
					
		// create random image file name
		$string = '0123456789';
		$file = preg_replace("/\s+/", "_", $_FILES['banner']['name']);
		$function = new functions;
		$img = $function->get_random_string($string, 4)."-".date("Y-m-d").".".$extension;
	
		// delete previous image
		$delete = unlink('assets/img/news/'."$img_atual");
		
		// upload new image
		$upload = move_uploaded_file($_FILES['banner']['tmp_name'], 'assets/img/news/'.$img);
	  
	}else{

		$img = $img_atual;
	}

	if ($_POST['off_comments'] == 1 ) { 
	    $off_comments = 1;
		 
	} else { 
		$off_comments = 0; 
	}

    for ($i = 0; $i < $no_of_posts; $i++) {
	    $blog = explode("|", $line[$i]);
	
	    if ($blog[0] == $id) {	
	        $new_data .=  $id .'|'.$comments.'|'.$date . '|' . $title . '|' . $content . '|'. $img . '|' . $off_comments ."\n";
		
	    } else {
	        $new_data .= $line[$i] . "\n";
	    }
    }

    $file    = @fopen($opFile,"w") or die($lang_erro_leitura); 
    $success = fwrite($file, $new_data);
	fclose($file);
		   
	if ($success == true) { 
	    $_SESSION["saved"] = true;
	}
 
	header("Location: index.php?p=edit-news&post_id=".$id);
	die();
}

for ($i = 0; $i < $no_of_posts; $i++){
    $blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){
	    $post_comment      = $blog[1];
        $edit_post_date    = $blog[2];
        $edit_post_title   = $blog[3];
        $edit_post_content = $blog[4];
        $off_comments      = $blog[6];
        $data_img = $blog[5];

		break;
	}
}
?> 

<div class="col-md-12">
<div id="panel-body">
<br/>
	<a class="btn btn-primary" href = "index.php?p=manage-news"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>
	<button onclick = "document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button>
	<a class = "btn btn-excluir" href = "index.php?p=del-news&post_id=<?php echo $blog[0] ; ?>"><i class="fa fa-trash"></i> <?php echo $lang_excluir; ?></a>
	<?php greenCheckmark();?>
</div>
<br/>
<!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             <?php echo $lang_editar_noticias; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<div id = "" class = "max">

<form class ="editor" name="editor" id="edit_post" method="post" action="" enctype="multipart/form-data">
    <input type = "hidden" name = "post_id" value = "<?php echo $id; ?>" />
    <input type = "hidden" name = "post_comment" value = "<?php echo $post_comment; ?>" />
    <input type = "hidden" name = "post_date" value = "<?php echo $edit_post_date; ?>" />
	<label><?php echo $lang_titulo; ?></label>
	<input cols = "100" class="form-control" type = "text" name = "title" value = "<?php echo $edit_post_title; ?>" />
	<br>
	<label><?php echo $lang_capa; ?></label>
	<img id="output" src="assets/img/news/<?php echo $data_img; ?>" width="209" height="auto" />
	<br/>
	<input type="file" name="banner" value="" accept="image/*" class="default" onchange="loadFile(event)" required>

	<script>
		var loadFile = function(event) {
			var output = document.getElementById('output');
			output.src = URL.createObjectURL(event.target.files[0]);
		};
	</script>
	<br>

	<label><?php echo $lang_descricao; ?></label>
	<textarea class = "block_editor" id = "redactor_content" cols = "100" rows = "10" name = "content"><?php echo $edit_post_content; ?></textarea>	
	<br>
	
	<select name = "off_comments" class="form-peq">
			<option value = "0" <?php if ($off_comments != 1) { echo 'selected="selected"' ;} ?>><?php echo $lang_on_comentarios; ?></option>
			<option value = "1" <?php if ($off_comments == 1) { echo 'selected="selected"' ;} ?>><?php echo $lang_off_comentarios; ?></option>
	</select> 
	
</form>


<h2 class = "comments-header"><?php echo $lang_comentarios; ?></h2>
<?php
 
$filename      = "data/news/comments.txt";
$fp_comments   = fopen($filename, "r") or die("$lang_erro_leitura");
$data_comments = @fread($fp_comments, filesize($filename));
fclose($fp_comments);

$line = explode("\n", $data_comments);
$nb   = count($line);

for ($i = 0; $i < $nb; $i++) { 
	$blog = explode("|", $line[$i]);
	
	if ($blog[0] == $id) {
	   $date       = explode( ' ' , $blog[1]);
	   $date       = $date[2] . '-' . $date[1]  . '-' . $date[3];
	   $comment_id = $i + 1;
	   
	   echo "<div class=\"comments-list\">
	    	  <span class=\"comment-title\">". $blog[2]." (". $blog[3].")</span> | <span >$date</span> | 
	    	  <a href=\"index.php?p=del-news&comment_id=". $comment_id ."&post_id=".$id."\" class=\"del-but\">$lang_excluir</a>"; 
	   echo "</div>";
	
	}
}
?>
</div>                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>