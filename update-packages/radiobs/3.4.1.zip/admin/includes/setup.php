<?PHP
$updatesDataServerUrlPrefix = base64_decode('aHR0cDovL3NydjEuYnJlbm9zb2x1dGlvbnMuY29tL2FwaS9icy91cGRhdGVzLw=='); 
#$updatesDataServerUrlPrefix = base64_decode('aHR0cDovL2xvY2FsaG9zdC91cGRhdGUv');
$filenameAllReleaseVersions = base64_decode('dmVyc29lcy1hdHVhaXMvcmFkaW9icy50eHQ=');
$directoryAllUpdatePackages = base64_decode('dXBkYXRlLXBhY2thZ2VzL3JhZGlvYnMv');
$localVersionFile = base64_decode('dmVyc2lvbi50eHQ=');
$localDownloadDir = base64_decode('YWRtaW4vdXBkYXRlcy8='); 
$automaticallyScrollToTheBottomOfThePage = TRUE;
