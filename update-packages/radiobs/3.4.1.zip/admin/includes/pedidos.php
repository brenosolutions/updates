<div class="col-md-12">
<META http-equiv="refresh" content="5"> 
<br/>
<h2><?php echo $lang_pedido_de_musicas; ?></h2>   
<br/>

                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             <?php echo $lang_pedidos; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<table class="table table-striped">
<tr>
    <th><?php echo $lang_nome; ?></th>
    <th><?php echo $lang_email; ?></th>
    <th><?php echo $lang_pedido; ?></th>
    <th><?php echo $lang_data_hora; ?></th>
</tr>
<?php include "bd/pedidos.php"; ?>



                                </table>
<form action="" method="post">
 <?php
 if (isset($_POST['limpar'])){
 unset($linhas);
 $cria = fopen("bd/pedidos.php","w+");
 fclose($cria);
 echo "<p>$lang_pedido_limpo</p> <META http-equiv='refresh' content='0'> ";
}
?>
<br/><br/>
<button class="btn btn-excluir" name="limpar"><i class="fa fa-eraser"></i> <?php echo $lang_limpar; ?></button>
</form>

</div>
</div>                            </div>
                        </div>