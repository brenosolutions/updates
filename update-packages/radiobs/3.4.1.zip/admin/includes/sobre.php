<div class="col-md-12">
    <br/>
    <h2><?php echo $lang_sobre_software; ?></h2>   
    <br/>
    <!-- Advanced Tables -->
    <div class="panel panel-default">
        <div class="panel-heading"><?php echo $lang_sobre_software; ?></div>
         <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <tbody>
                        <tr>
                            <td><i class="fa fa-cloud-upload fa-2x"></i> <?php echo $lang_versao_instalada; ?>:</td>
                            <td><?php echo file_get_contents("../version.txt"); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>