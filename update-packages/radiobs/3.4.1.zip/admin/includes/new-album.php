<?php $on = 'images'; ?>

<?php
require_once("login.php");

if ($_POST['albuns']) {
    
 function remove_accents($str){ 
    $from = array(
        "á", "à", "â", "ã", "ä", "é", "è", "ê", "ë", "í", "ì", "î", "ï", 
        "ó", "ò", "ô", "õ", "ö", "ú", "ù", "û", "ü", "ç", "Á", "À", "Â", 
        "Ã", "Ä", "É", "È", "Ê", "Ë", "Í", "Ì", "Î", "Ï", "Ó", "Ò", "Ô", 
        "Õ", "Ö", "Ú", "Ù", "Û", "Ü", "Ç"
    ); 
    $to = array(
        "a", "a", "a", "a", "a", "e", "e", "e", "e", "i", "i", "i", "i", 
        "o", "o", "o", "o", "o", "u", "u", "u", "u", "c", "A", "A", "A", 
        "A", "A", "E", "E", "E", "E", "I", "I", "I", "I", "O", "O", "O", 
        "O", "O", "U", "U", "U", "U", "C"
    );    
    return str_replace($from, $to, $str); 
 }

    $clean_name = remove_accents($_POST['albuns']);
	$clean_name = ($clean_name);   
	$name       = ucfirst($clean_name);

	if (file_exists("data/img/albuns/".$name)) {	
		echo "<p class=\"errorMsg created\"> $lang_album_existe </p>";
				
	} else {		
		$gal = mkdir("data/img/albuns/". $name , 0755);
			
		$text = "<?php ". "$"."_SERVER". "['DOCUMENT_ROOT'] "."= dirname"."( __FILE__ )"."; "."include('../../../../plugins/timthumb/tim_thumb.php')".";"." ?>";
			
		$fp = @fopen("data/img/albuns/$name/". "thumb.php","w");
		$ph = @fwrite($fp, $text);
		fclose($fp);

		if ($gal && $fp && $ph) {				
			
			header("Location: index.php?p=gerenciar-albuns");
			die();

		 } else { 		  
		  	    echo "<p class=\"errorMsg created\">$lang_album_existe</p>";		  	
		 }		  	
	 }			
}

?>

<div class="col-md-12">
<h2><?php echo $lang_novo_album; ?></h2>
	<br/>
	<div id="panel-body">
		<a class="btn btn-primary" href="index.php?p=gerenciar-albuns"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>
	</div>  
<br/>

<!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             <?php echo $lang_novo; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

	
<form action="index.php?p=new-album" method="post" class="create-form">
<div class="col-sm-4">
<div class="form-group">
	<input class="form-control" type="text" name="albuns" maxlength="20" placeholder="<?php echo $lang_nome; ?>" />
	</div>
</div>

	<div class="form-group">
	<input class="btn btn-success" type="submit" value="<?php echo $lang_add; ?>" />
	</div>
	</form>


</div>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>