<div class="col-md-12">
<br/>
<h2><?php echo $lang_temas; ?></h2>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              <?php echo $lang_temas_lista; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form role="form" action = "index.php?p=settings-theme" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

          foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_theme = '<?php
$theme = "'. $theme .'";
?>';

            if ($fp = fopen("bd/theme.php", "w")) {
                fwrite($fp, $config_theme, strlen($config_theme));

                $_SESSION["saved"]=true;

        header("Location: index.php?p=settings-theme");
        die();

            } else {
                echo "<p class=\"errorMsg\">$lang_config_gravave</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
     $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
     $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


  <div class="form-group">
     <?php
     $theme_options = array(
        array(Dark,'main.css', "assets/img/dark-theme.jpg"),
        array(Light,'light.css', "assets/img/light-theme.jpg")
        );

     foreach ($theme_options as $theme_option) {

    ?><br/><div class=""><input type="radio" name="theme" value = "<?php echo $theme_option[1]; ?>"<?php echo $theme == $theme_option[1] ? 'CHECKED' : '';?>><label><?php echo ucfirst($theme_option[0]); ?></label> <?php echo "<img src="."$theme_option[2]";?><?php echo $theme == $theme_option[1] ? ' style="border:solid 3px DeepSkyBlue; opacity: 0.5; " ' : ' style="border:solid 3px White;" ';?><?php echo " height='180px' >";?></div><?php
        } ?>
   

  </div>
<br/>


<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 
  <?php greenCheckmark();?>
  </div>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>