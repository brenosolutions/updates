

<?php



error_reporting(0);



include_once("path.php");

include_once(ROOTPATH."../../config.php");

include_once("lang/$pulse_lang.php");

include_once("helpers/functions.php");

include_once("helpers/news_lib.php");



$get_blog = new show_Blogs;

$captcha  = new read_Cap;

$order    = ($date_format=='0' || $date_format=='1') ? "d-m-Y" : $date_format;

$q_and_a  = $captcha->check_anq($questions, $_POST["answers"], $_POST["question"], $_POST["token"]);



?> 



<link rel="stylesheet" href="<?php if(empty($http_https)){echo 'http';}else{echo $http_https;} ?>://<?php echo $_SERVER['HTTP_HOST']; ?>/<?php echo $pulse_dir; ?>/css/blog.css">
<style type="text/css">
	.link-none{
		padding-left: 0 !important;
    	margin-bottom: 0 !important;

	}
</style>


<?php




if ($get_blog->val_d($_GET["d"]) == true) {

    $id_post  = super_clean($_GET["d"]);

    $comments = new show_Comments($id_post);

    $x        = 0;

	$resp     = ($blog_capcha == false) ? 1 : $q_and_a[0];

	$coms     = $comments->get_comments();



	if (isset($_POST['submit'])){

	    $comments_val = $comments->val_comment($_POST['name'], $_POST['mail'], $_POST['comment'], $_POST['ph'], $lang_erro_name, $lang_erro_email, $lang_erro_comentario);	



		if (empty($comments_val) && $blog_comments && ($resp == 1)) {

			$comment_saved = $comments->val_comment_saved();

				

			if ($comment_saved == 0) {

			    $new_data = $get_blog->update_comment_amount_in_blogfile($id_post);			

	            $comments->update_files($new_data);

				$gettitle = $get_blog->get_blog_post($id_post);

	            $comments->send_mail($email_contact,$lang_novo_comentario,$lang_titulo,$lang_nome,$lang_comentario,$lang_novo_comentario,$gettitle[6]);

	            $x = 1;

			 }

		 

			 unset($_POST['submit']);

			 $_POST['name'] = ''; $_POST['mail'] = ''; $_POST['comment'] = '';

		}	 

     }

     

	$blog_post_content = $get_blog->get_blog_post($id_post);			

	$blog_turned_off   = ($blog_post_content[7] == 1) ? true : false;

	

	if ($blog_post_content[0] == 0){ echo "404 Not Found"; header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); die(); }

	$content_blog_post = str_replace("##more##", "", $blog_post_content[4]);

	$date_blog_post = date($order, strtotime($blog_post_content[2]));

	echo "<article class='latest-post detail'>
              
              <h2>$blog_post_content[6]</h2>
              <ul>
                  <li><span class='fa fa-calendar'></span> $date_blog_post</li>
                  <li><span class='fa fa-comment'></span> ";
                  if ($blog_comments) { 
					if ($x==1) { $add = $comments->temp_values(); array_push($coms, $add); }
						echo ($blog_post_content[5]+$x)." ".$lang_comentario_s; $x = 0;
						$x = 0;
				}
			echo "</li>
              </ul><br>
              <img src='admin/assets/img/news/$blog_post_content[7]' alt='$blog_post_content[6]'>
              $content_blog_post
              
          </article>";




	if ($blog_comments) { 

		if ($x==1) { $add = $comments->temp_values(); array_push($coms, $add); }
		echo '<article class="post-comments" >';
		echo "<h1>".($blog_post_content[5]+$x)." ".$lang_comentarios."</h1>\n"; $x = 0;

		if ($blog_turned_off == true && $blog_post_content[1] == $id_post) { echo "<p class='comments-off'>$lang_comentario_fechado</p>"; }

      

		 if ($blog_turned_off == false && $blog_post_content[1] == $id_post) {

        	echo "<div class='row'>";
		 	echo '<br><div class="col-md-8 col-md-offset-2">';
		 	echo "<h4 class='text-center'>$lang_seu_comentario</h4>";
 			 if (!empty($comments_val)){ foreach ($comments_val as $error) { echo "<p style='color:red'>$error</p>"; }}
		 	echo '<article id="contact">';
			echo "<form action=news-$id_post-$blog_post_content[3] method='post'>";

			

			echo "<input type='text' placeholder='$lang_nome' name='name'  value =".super_clean($_POST['name']).">";

		
			echo "<input  placeholder='$lang_email_comentario' type='text' name='mail' value=".super_clean($_POST['mail']).">";

					

			
			echo "<textarea  id='message' placeholder='$lang_comentario...' name='comment' rows='5'>".super_clean($_POST['comment'])."</textarea>";

			

			echo "<input id='ph' type='text' name='ph' value=".super_clean($_POST['ph']).">";

						

			if (($blog_capcha == true) || (!isset($blog_capcha))) { 

			    echo "<label class='comment-label'>". $q_and_a[1][0];

			       if ($resp == 2) { echo "<span style='color:red'> - $lang_erro_captcha</span>"; }

			    echo "</label>"; 

			  
				echo "<input type='hidden' name='token' value='".md5($q_and_a[1][1])."'/>";

				echo "<input type='hidden' name='question' value='". htmlentities($q_and_a[1][0])."'/>";

				echo "<input type='text' name='answers'/>";

			 } 										

			echo "<div class='text-center'><button class='btn btn-success' type='submit' name='submit'>$lang_enviar</button></div>";			

			echo "</form>";
			echo '</div>';echo '</div> <br>';
			echo '</article>';

       }


		// Display comments

	    foreach ($coms as $comment) {

	    	echo "<div class=\"comment-read\">
				<div class=\"comment-reply\">
					<b class=\"fa fa-user\"></b>
					<h3>$comment[1]</h3>
					<h4>".date($order, strtotime($comment[0]))."</h4>
					<p>$comment[2]</p>
				</div>
			</div>";

	    }


       
		echo '</article>';
    }	

    	 				       

} else { 



// Show all posts
echo "<div class=''>";
foreach ($get_blog->get_blog_posts($per_page, $lang_leia_mais) as $post) {

	$news_list = substr($post[4], 0, 325);
	$news_txt = strip_tags($news_list, '');
	$data_post = date($order, strtotime($post[2]));
	echo "<div class='news-feed news-home-post'>
	          <a class='link-none' href='news-$post[0]-$post[3]'><img src='admin/assets/img/news/$post[8]'></a>
	          <h2><a class='feed2' href='news-$post[0]-$post[3]'>$post[5]</a></h2>
	          <ul>
	              <li><span class='fa fa-calendar'></span> $data_post</li>
	              <li><span class='fa fa-comment'></span>
	              ";
	              if ($blog_comments) {				
			        if ($post[1]) { echo "$post[1] $lang_comentario_s"; } else { echo "0 $lang_comentario"; }
			      }
	echo
	          "</li></ul>
	          <p>$news_txt...</p>
	      </div>";




}
echo "</div>";



// Pagination

echo '<div class="news-feed-btn">';

$nums = $get_blog->amount_pages($per_page);

if ($nums[1] < $nums[0]) { echo "<a href=\"eventos-page-".($nums[1]+1)."\">$lang_proximo ></a>"; }

if ($nums[1] > 1) { echo  "<a href=\"eventos-page-".($nums[1]-1)."\">< $lang_anterior</a>"; }

echo '</div>';

}


?>
