<?php 
	
$on = 'images'; 
require_once("login.php");

?>

<div class="col-md-12">
<br/>
<h2><?php echo $lang_fotos; ?></h2>   

<div id="panel-body">
<br/>
    <a class="btn btn-primary" href = "index.php?p=gerenciar-albuns"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>

	<a class="btn btn-success" href = "index.php?p=choose-albuns&g=<?php if (!empty($_GET["g"])) { echo htmlentities($_GET["g"]); }?>"><i class="fa fa-cloud-upload"></i> <?php echo $lang_upload; ?>s</a>

	<a class="btn btn-excluir" href = "index.php?p=del-album&g=<?php if (!empty($_GET["g"])) { echo htmlentities($_GET["g"]); }?>"><i class="fa fa-trash"></i> <?php echo $lang_excluir_album; ?></a>

	    
</div>
<br />

                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             <?php echo $lang_fotos_lista; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<?php 

if (!empty($_GET["g"])) {
	$albuns = strip_tags(trim(stripslashes(htmlspecialchars($_GET["g"], ENT_QUOTES, 'UTF-8'))));
	$albuns = str_replace("/","", $albuns);
	$albuns = str_replace("\\","", $albuns);	
    $albuns = str_replace("..", "",  $_GET["g"]);
    
    $opFile = ROOTPATH . "/data/img/albuns/". $albuns ."/fotos.txt";
    
    if (file_exists($opFile)) {    
    	$fp   = fopen($opFile,"r");
        $data = @fread($fp, filesize($opFile));
        fclose($fp);

        $line = explode("\n", $data);
        $nb   = count($line)-1;
               
		$image = sortImages($line);
          
        ?><ul id = "sortable" > <?php
              
        for ($i = 0; $i < $nb+1; $i++) {
            
	      if ($image[$i][1] == $albuns) { 
	  	        	       	 		        		        				     		        		        
		  ?>		        
	           <ul class = "thumb" id = "one_<?php echo $image[$i][0]; ?>"><?php
		          
                echo '<a href="#">';
                echo '<img src="data/img/albuns/'. $albuns .'/'. $image[$i][2] .'" alt="'. $image[$i][3] .'"  class="thumb-pic"/>';
                echo '</a>';
               
                echo "<a href=\"index.php?p=del-foto&f=". $image[$i][0] ."&g=". $albuns ."\" class=\"del-img\">$lang_excluir</a>";
               
           ?> </ul> <?php 
                
	       }
         }
        
       ?> </ul> <div id = "result"></div> <?php
      } 
    
    if ($nb <= 0) {
        echo "<p class=\"empty\">". $lang_vazio ."</p><br><br>";        
    }
}
?>
 
<script type = "text/javascript">
$ (function() {
    $("#sortable").sortable({ 
	  update: function() {
        var order = $(this).sortable("serialize")+ '&gallery=<?php echo $albuns;  ?>';
	        $.post("includes/helpers/gal-sort-fotos.php", order, function(theResponse){
	        $("#result").html(theResponse);
			});
        } 
    });
});
</script>

<div class = "clear"></div>

</div>                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>