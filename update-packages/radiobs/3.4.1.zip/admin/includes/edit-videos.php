<?php 
require_once("login.php");
$on = 'videos'; 
$lang_page_title = 'Editar videos'; 

$domain = $_SERVER['HTTP_HOST'];
$id     = strip_tags(stripslashes(trim($_GET['post_id'])));

$opFile = "data/videos/videosfile.txt";
$fp     = @fopen($opFile,"r") or die("$lang_erro_leitura"); 
$data   = @fread($fp, filesize($opFile));
fclose($fp);

$line   = explode("\n", $data);			
$no_of_posts = count($line)-1;

if (!empty($_POST)) {
    $id       = $_POST['post_id'];
	$comments = $_POST['post_comment'];
	$date     = $_POST['post_date'];
	$title    = htmlspecialchars(trim(stripslashes($_POST['title'])), ENT_QUOTES, "UTF-8");
	$content  = strip_tags(stripslashes($_POST['content']), "<p><center><u><strong><del><audio><link><iframe><object><fieldset><dl><dt><dt><colgroup><col><font><label><em><embed><a><pre><b><i><style><table><tbody><td><textarea><tfoot><th><thead><title><tr><tt><ul><li><ol><img><h1><h2><h3><h4><h5><hr><address><span><div><blockquote><br><br /><button>");
	$content  = str_replace("\n", "", $content);
	$content  = str_replace("\r", "", $content);

	if ($_POST['off_comments'] == 1 ) { 
	    $off_comments = 1;
		 
	} else { 
		$off_comments = 0; 
	}

    for ($i = 0; $i < $no_of_posts; $i++) {
	    $blog = explode("|", $line[$i]);
	
	    if ($blog[0] == $id) {	
	        $new_data .=  $id .'|'.$comments.'|'.$date . '|' . $title . '|' . $content . '|'. $off_comments . "\n";
		
	    } else {
	        $new_data .= $line[$i] . "\n";
	    }
    }

    $file    = @fopen($opFile,"w") or die($lang_erro_leitura); 
    $success = fwrite($file, $new_data);
	fclose($file);
		   
	if ($success == true) { 
	    $_SESSION["saved"] = true;
	}
 

	header("Location: index.php?p=edit-videos&post_id=".$id);
	die();
}

for ($i = 0; $i < $no_of_posts; $i++){
    $blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){
	    $post_comment      = $blog[1];
        $edit_post_date    = $blog[2];
        $edit_post_title   = $blog[3];
        $edit_post_content = $blog[4];
        $off_comments      = $blog[5];

		break;
	}
}
?> 

<div class="col-md-12">
<div id="panel-body">
<br/>
	<a class="btn btn-primary" href = "index.php?p=manage-videos"><i class="fa fa-chevron-circle-left"></i>  <?php echo $lang_voltar; ?></a>
	<button onclick = "document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button>
	<a class = "btn btn-excluir" href = "index.php?p=del-videos&post_id=<?php echo $blog[0] ; ?>"><i class="fa fa-trash"></i> <?php echo $lang_excluir; ?></a>
	<?php greenCheckmark();?>
</div>
<br/>
<!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             <?php echo $lang_editar_video; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<div id = "" class = "max">

<form class = "editor" name = "editor" id = "edit_post" method = "post" action = "">
    <input type = "hidden" name = "post_id" value = "<?php echo $id; ?>" />
    <input type = "hidden" name = "post_comment" value = "<?php echo $post_comment; ?>" />
    <input type = "hidden" name = "post_date" value = "<?php echo $edit_post_date; ?>" />
	<label><?php echo $lang_titulo; ?></label>
	<input cols = "100" class="form-control" type = "text" name = "title" value = "<?php echo $edit_post_title; ?>" />
		<br>
			<label>ID <?php echo $lang_video; ?> Youtube</label>

		<input class="form-control" type="text" name="content" value="<?php echo $edit_post_content; ?>"/>
	<br>
	

	
</form>


</div>                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>