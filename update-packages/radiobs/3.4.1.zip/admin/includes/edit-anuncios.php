<?php 
require_once("login.php");
require_once("helpers/img.php");
$on = 'anuncios'; 
$lang_page_title = 'Editar anuncios'; 

$domain = $_SERVER['HTTP_HOST'];
$id     = strip_tags(stripslashes(trim($_GET['post_id'])));

$opFile = "data/anuncios/anunciosfile.txt";
$fp     = @fopen($opFile,"r") or die("$lang_erro_leitura"); 
$data   = @fread($fp, filesize($opFile));
fclose($fp);

$line   = explode("\n", $data);			
$no_of_posts = count($line)-1;

if (!empty($_POST)) {
	$id       = $_POST['post_id'];
	$comments = $_POST['post_comment'];

		// get image info
			$date = $_FILES['banner']['name'];
			$image_error = $_FILES['banner']['error'];
			$image_type = $_FILES['banner']['type'];
			
			// common image file extensions
			$allowedExts = array("gif", "jpeg", "jpg", "png");
			
			// get image file extension
			error_reporting(E_ERROR | E_PARSE);
			$extension = end(explode(".", $_FILES["banner"]["name"]));
			
			if(!empty($date)){
				if(!(($image_type == "image/gif") || 
					($image_type == "image/jpeg") || 
					($image_type == "image/jpg") || 
					($image_type == "image/x-png") ||
					($image_type == "image/png") || 
					($image_type == "image/pjpeg")) &&
					!(in_array($extension, $allowedExts))){
					
					$error['banner'] = "<span class='label label-danger'>$lang_img_suporte: jpg, jpeg, gif, ou png!</span>";
				}
			}

		for ($i = 0; $i < $no_of_posts; $i++){
	$blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){
		$edit_post_date    = $blog[2];
		break;
	}
}

				if(!empty($date)){
					
					// create random image file name
					$string = '0123456789';
					$file = preg_replace("/\s+/", "_", $_FILES['banner']['name']);
					$function = new functions;
					$img = $function->get_random_string($string, 4)."-".date("Y-m-d").".".$extension;
				
					// delete previous image
					$delete = unlink('assets/img/anunciantes/'."$edit_post_date");
					
					// upload new image
					$upload = move_uploaded_file($_FILES['banner']['tmp_name'], 'assets/img/anunciantes/'.$img);
	  
	}else{

		$img = $edit_post_date;
	}
				



	$title    = htmlspecialchars(trim(stripslashes($_POST['title'])), ENT_QUOTES, "UTF-8");
	$content  = strip_tags(stripslashes($_POST['content']), "<p><center><u><strong><del><audio><link><iframe><object><fieldset><dl><dt><dt><colgroup><col><font><label><em><embed><a><pre><b><i><style><table><tbody><td><textarea><tfoot><th><thead><title><tr><tt><ul><li><ol><img><h1><h2><h3><h4><h5><hr><address><span><div><blockquote><br><br /><button>");
	$content  = str_replace("\n", "", $content);
	$content  = str_replace("\r", "", $content);

	if ($_POST['off_comments'] == 1 ) { 
		$off_comments = 1;

	} else { 
		$off_comments = 0; 
	}

	for ($i = 0; $i < $no_of_posts; $i++) {
		$blog = explode("|", $line[$i]);

		if ($blog[0] == $id) {	
			$new_data .=  $id .'|'.$comments.'|'.$img . '|' . $title . '|' . $content . '|'. $off_comments . "\n";

		} else {
			$new_data .= $line[$i] . "\n";
		}
	}

	$file    = @fopen($opFile,"w") or die($lang_erro_leitura); 
	$success = fwrite($file, $new_data);
	fclose($file);

	if ($success == true) { 
		$_SESSION["saved"] = true;
	}


	header("Location: index.php?p=edit-anuncios&post_id=".$id);
	die();
}

for ($i = 0; $i < $no_of_posts; $i++){
	$blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){
		$post_comment      = $blog[1];
		$edit_post_date    = $blog[2];
		$edit_post_title   = $blog[3];
		$edit_post_content = $blog[4];
		$off_comments      = $blog[5];

		break;
	}
}
?> 

<div class="col-md-12">
	<div id="panel-body">
		<br/>
		<a class="btn btn-primary" href = "index.php?p=manage-anuncios"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>
		<button onclick = "document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button>
		<a class = "btn btn-excluir" href="index.php?p=del-anuncios&post_id=<?php echo $blog[0] ; ?>&img=<?php echo $blog[2] ; ?>"><i class="fa fa-trash"></i> <?php echo $lang_excluir; ?></a>
		<?php greenCheckmark();?>
	</div>
	<br/>
	<!-- Advanced Tables -->
	<div class="panel panel-default">
		<div class="panel-heading">
		<?php echo $lang_editar_anuncio; ?>
		</div>
		<div class="panel-body">
			<div class="table-responsive">

				<div id = "" class = "max">

					<form class="editor" method="post" name="editor" enctype="multipart/form-data">

						<input type="hidden" name="post_id" value="<?php echo $id; ?>" />

						<input type="hidden" name="post_comment" value="<?php echo $post_comment; ?>" />

						<label><?php echo $lang_nome; ?></label>
						<input cols = "100" class="form-control" type ="text" name ="title" value="<?php echo $edit_post_title; ?>" />
						<br>
						<label><?php echo $lang_site; ?></label>
						<input class="form-control" type="text" name="content" value="<?php echo $edit_post_content; ?>"/>
						<br>

						<label><?php echo $lang_banner; ?></label>
						<img id="output" src="assets/img/anunciantes/<?php echo $edit_post_date; ?>" width="209" height="auto" />
						<br/><?php echo $lang_tamanho_recomendado; ?>: 270x270 pixels.
						<input type="file" name="banner" value="" accept="image/*" class="default" onchange="loadFile(event)" required>

						<script>
							var loadFile = function(event) {
								var output = document.getElementById('output');
								output.src = URL.createObjectURL(event.target.files[0]);
							};
						</script>


					</form>
				</div>                            </div>

			</div>
		</div>
		<!--End Advanced Tables -->
	</div>