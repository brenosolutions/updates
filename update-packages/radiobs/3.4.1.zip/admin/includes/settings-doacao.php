<div class="col-md-12">
<br/>
<h2><?php echo $lang_doacao; ?></h2>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							             <?php echo $lang_config_doacao; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form role="form" action = "index.php?p=settings-doacao" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_doacao = '<?php
$doacao = "'. $doacao .'";
$email_pagseguro = "'. $email_pagseguro .'";
$msg_doacao = "'. $msg_doacao .'";
?>';

            if ($fp = fopen("bd/doacao.php", "w")) {
                fwrite($fp, $config_doacao, strlen($config_doacao));

                $_SESSION["saved"]=true;
				header("Location: index.php?p=settings-doacao");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_config_gravavel</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


  <div class="form-group">
     <label><?php echo $lang_ativar; ?> / <?php echo $lang_desativar; ?> - <?php echo $lang_doacao; ?></label>
     <select class="form-control" name="doacao">

     <?php
     $doacao_options = array(
        array($lang_ativar,'1'),
        array($lang_desativar,'0')
        );

     foreach ($doacao_options as $doacao_option) {

    ?><option value = "<?php echo $doacao_option[1]; ?>"<?php echo $doacao == $doacao_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($doacao_option[0]); ?></option><?php
        } ?>
     </select>
  </div>

	<div class="form-group">
	    <label><?php echo $lang_email; ?> PagSeguro</label>
	    <input required class="form-control" type="email" name="email_pagseguro" value="<?php echo $email_pagseguro; ?>" />
      <a href="https://pagseguro.uol.com.br/" target="_blank"><?php echo $lang_criar_pagseguro; ?></a>
	</div>

    <div class="form-group">
      <label><?php echo $lang_mensagem; ?></label>
      <input required class="form-control" type="text" name="msg_doacao" value="<?php echo $msg_doacao; ?>" />
  </div>


<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 
  <?php greenCheckmark();?>
  </div>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>