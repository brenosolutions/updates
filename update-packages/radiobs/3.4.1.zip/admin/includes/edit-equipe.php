<?php 
require_once("login.php");
require_once("helpers/img.php");
$on = 'equipe'; 
$lang_page_title = 'Editar equipe'; 

$domain = $_SERVER['HTTP_HOST'];
$id     = strip_tags(stripslashes(trim($_GET['post_id'])));

$opFile = "data/equipe/equipefile.txt";
$fp     = @fopen($opFile,"r") or die("$lang_erro_leitura"); 
$data   = @fread($fp, filesize($opFile));
fclose($fp);

$line   = explode("\n", $data);			
$no_of_posts = count($line)-1;

if (!empty($_POST)) {
	$id       = $_POST['post_id'];
	$comments = $_POST['post_comment'];

	$name = $_POST['name'];
	$cargo = $_POST['cargo'];
	$descricao = htmlspecialchars(trim(stripslashes(preg_replace('/[\n|\r|\n\r|\r\n]{2,}/',' ', $_POST['descricao'] ))), ENT_QUOTES, "UTF-8");
	$facebook = $_POST['facebook'];
	$instagram = $_POST['instagram'];
	$twitter = $_POST['twitter'];
	$whatsapp = $_POST['whatsapp'];

		// get image info
			$banner = $_FILES['banner']['name'];
			$image_error = $_FILES['banner']['error'];
			$image_type = $_FILES['banner']['type'];
			
			// common image file extensions
			$allowedExts = array("gif", "jpeg", "jpg", "png");
			
			// get image file extension
			error_reporting(E_ERROR | E_PARSE);
			$extension = end(explode(".", $_FILES["banner"]["name"]));
			
			if(!empty($banner)){
				if(!(($image_type == "image/gif") || 
					($image_type == "image/jpeg") || 
					($image_type == "image/jpg") || 
					($image_type == "image/x-png") ||
					($image_type == "image/png") || 
					($image_type == "image/pjpeg")) &&
					!(in_array($extension, $allowedExts))){
					
					$error['banner'] = " <span class='label label-danger'>$lang_img_suporte: jpg, jpeg, gif, ou png!</span>";
				}
			}

		for ($i = 0; $i < $no_of_posts; $i++){
	$blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){
		$edit_post_date    = $blog[2];
		break;
	}
}

				if(!empty($banner)){
					
					// create random image file name
					$string = '0123456789';
					$file = preg_replace("/\s+/", "_", $_FILES['banner']['name']);
					$function = new functions;
					$img = $function->get_random_string($string, 4)."-".date("Y-m-d").".".$extension;
				
					// delete previous image
					$delete = unlink('assets/img/equipe/'."$edit_post_date");
					
					// upload new image
					$upload = move_uploaded_file($_FILES['banner']['tmp_name'], 'assets/img/equipe/'.$img);
	  
	}else{

		$img = $edit_post_date;
	}
				

	if ($_POST['off_comments'] == 1 ) { 
		$off_comments = 1;

	} else { 
		$off_comments = 0; 
	}

	for ($i = 0; $i < $no_of_posts; $i++) {
		$blog = explode("|", $line[$i]);

		if ($blog[0] == $id) {	
			$new_data .=  $id ."|0|". $img ."|". $name ."|". $cargo. "|". $descricao. "|". $facebook. "|". $instagram. "|". $twitter. "|". $whatsapp."\n";

		} else {
			$new_data .= $line[$i] . "\n";
		}
	}

	$file    = @fopen($opFile,"w") or die($lang_erro_leitura); 
	$success = fwrite($file, $new_data);
	fclose($file);

	if ($success == true) { 
		$_SESSION["saved"] = true;
	}

	header("Location: index.php?p=edit-equipe&post_id=".$id);
	die();
}

for ($i = 0; $i < $no_of_posts; $i++){
	$blog = explode("|", $line[$i]);
	
	if ($blog[0] != $id) continue;
	
	if ($blog[0] == $id){
		$post_comment = $blog[1];
		$data_img = $blog[2];
		$data_name = $blog[3];
		$data_cargo = $blog[4];
		$data_descricao = $blog[5];
		$data_facebook = $blog[6];

		$data_instagram = $blog[7];
		$data_twitter = $blog[8];
		$data_whatsapp = $blog[9];

		break;
	}
}
?> 

<div class="col-md-12">
	<div id="panel-body">
		<br/>
		<a class="btn btn-primary" href = "index.php?p=manage-equipe"><i class="fa fa-chevron-circle-left"></i> <?php echo $lang_voltar; ?></a>
		<button onclick = "document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button>
		<a class = "btn btn-excluir" href="index.php?p=del-equipe&post_id=<?php echo $blog[0] ; ?>&img=<?php echo $blog[2] ; ?>"><i class="fa fa-trash"></i> <?php echo $lang_excluir; ?></a>
		<?php greenCheckmark();?>
	</div>
	<br/>
	<!-- Advanced Tables -->
	<div class="panel panel-default">
		<div class="panel-heading">
		<?php echo $lang_editar; ?>
		</div>
		<div class="panel-body">
			<div class="table-responsive">

				<div id = "" class = "max">

					<form class="editor" method="post" name="editor" enctype="multipart/form-data">

						<input type="hidden" name="post_id" value="<?php echo $id; ?>" />

						<input type="hidden" name="post_comment" value="<?php echo $post_comment; ?>" />

						<label><?php echo $lang_nome; ?></label>
						<input class="form-control" type="text" name="name" value="<?php echo $data_name; ?>" required>
						<br/>

						<label><?php echo $lang_cargo; ?></label>
						<input class="form-control" type="text" name="cargo" value="<?php echo $data_cargo; ?>">
						<br/>

						<label><?php echo $lang_descricao; ?></label>
						<textarea class="form-control"  name="descricao" rows="4"><?php echo $data_descricao; ?></textarea>
						<br/>

						<label><?php echo $lang_foto; ?></label>
						<img id="output" src="assets/img/equipe/<?php echo $data_img; ?>" width="209" height="auto" />
						<br/><small><?php echo $lang_tamanho_recomendado; ?>: 215x215 pixels.</small>
						<input type="file" name="banner" value="" accept="image/*" class="default" onchange="loadFile(event)" required>

						<script>
							var loadFile = function(event) {
								var output = document.getElementById('output');
								output.src = URL.createObjectURL(event.target.files[0]);
							};
						</script>
						<br>
						<label>Facebook</label>
						<input class="form-control" type="text" name="facebook" placeholder="URL Facebook" value="<?php echo $data_facebook ?>">
						<small><?php echo $lang_branco_desativar; ?></small>

						<br><br>

						<label>Instagram</label>
						<input class="form-control" type="text" name="instagram" placeholder="URL Instagram" value="<?php echo $data_instagram?>">
						<small><?php echo $lang_branco_desativar; ?></small>

						<br><br>

						<label>Twitter</label>
						<input class="form-control" type="text" name="twitter" placeholder="URL Twitter" value="<?php echo $data_twitter ?>">
						<small><?php echo $lang_branco_desativar; ?></small>

						<br><br>

						<label>Whatsapp</label>
						<input class="form-control" type="text" name="whatsapp" placeholder="Nº Whatsapp. EX: 5585988888888" value="<?php echo $data_whatsapp ?>">
						<small><?php echo $lang_info_whats; ?> <?php echo $lang_branco_desativar; ?>.</small>


					</form>
				</div>                            </div>

			</div>
		</div>
		<!--End Advanced Tables -->
	</div>