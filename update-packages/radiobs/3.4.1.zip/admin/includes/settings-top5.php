<div class="col-md-12">
    <br/>
    <h2><?php echo $lang_Top5; ?></h2>
    <br/>
</div>

<div class="col-md-6">


    <form role="form" action = "index.php?p=settings-top5" method = "post" enctype="multipart/form-data">

        <?php
        require_once("login.php");

        if ($_POST["status"] == 1) {

           if (isset($_SESSION["token"])
            && isset($_SESSION["token_time"])
            && isset($_POST["token"])
            && $_SESSION["token"] == $_POST["token"]) {

            $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

           foreach ($_POST as $var => $key) {
             $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");

         }

         $config_top5 = '<?php
         $artista_top1 = "'. $artista_top1 .'";
         $musica_top1 = "'. $musica_top1 .'";

         $artista_top2 = "'. $artista_top2 .'";
         $musica_top2 = "'. $musica_top2 .'";

         $artista_top3 = "'. $artista_top3 .'";
         $musica_top3 = "'. $musica_top3 .'";

         $artista_top4 = "'. $artista_top4 .'";
         $musica_top4 = "'. $musica_top4 .'";

         $artista_top5 = "'. $artista_top5 .'";
         $musica_top5 = "'. $musica_top5 .'";

         $top_5 = "'. $top_5 .'";
         ?>';

         if ($fp = fopen("bd/top5.php", "w")) {
            fwrite($fp, $config_top5, strlen($config_top5));

            $_SESSION["saved"]=true;
            header("Location: index.php?p=settings-top5");
            die();

        } else {
            echo "<p class=\"errorMsg\">$lang_config_gravavel</p>";
        }
    }
}
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
 $_SESSION["token_time"] = time();
}


if (!isset($_POST["status"])) {
    ?>
    <div class="form-group">
       <label><?php echo $lang_ativar; ?> / <?php echo $lang_desativar; ?> - <?php echo $lang_Top5; ?></label>
       <select class="form-control" name="top_5">

           <?php
           $top_5_options = array(
            array($lang_ativar,'1'),
            array($lang_desativar,'0')
        );

           foreach ($top_5_options as $top_5_option) {

            ?><option value = "<?php echo $top_5_option[1]; ?>"<?php echo $top_5 == $top_5_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($top_5_option[0]); ?></option><?php
        } ?>
    </select>
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 
</div>


<!--   Basic Table  -->
<div class="panel panel-default">
    <div class="panel-heading">
     1º <?php echo $lang_lugar; ?>
 </div>
 <div class="panel-body">
    <div class="table-responsive">
        <div class="form-group">                
            <label><?php echo $lang_foto_artista; ?></label>
            <br/>
            <img id="output" src="assets/img/artistas/artista1.png?img=<?php echo urlencode($cache_today); ?>" width="220" height="auto" />
            <br/><?php echo $lang_tamanho_recomendado; ?>: 220x130 pixels.
            <script>
                var loadFile = function(event) {
                    var output = document.getElementById('output');
                    output.src = URL.createObjectURL(event.target.files[0]);
                };
            </script>
            <br/>
            <a class="btn btn-default" href="index.php?p=artista1" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_editar_foto; ?></a>
        </div>      


        <div class="form-group">
           <label><?php echo $lang_nome_artista; ?></label>
           <input class="form-control" type="text" name="artista_top1" value="<?php echo $artista_top1; ?>" />
       </div>

       <div class="form-group">
           <label><?php echo $lang_nome_musica; ?></label>
           <input class="form-control" type="text" name="musica_top1" value="<?php echo $musica_top1; ?>" />
       </div>

       <div class="form-group">
            <a class="btn btn-default" href="index.php?p=top1" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_up_musica; ?></a>
       </div>
       



<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 

</div>
</div>
</div> 

<!--   Basic Table  -->
<div class="panel panel-default">
    <div class="panel-heading">
     2º <?php echo $lang_lugar; ?>
 </div>
 <div class="panel-body">
    <div class="table-responsive">
        <div class="form-group">                
            <label><?php echo $lang_foto_artista; ?></label>
            <br/>
            <img id="output" src="assets/img/artistas/artista2.png?img=<?php echo urlencode($cache_today); ?>" width="220" height="auto" />
            <br/><?php echo $lang_tamanho_recomendado; ?>: 220x130 pixels.
            <script>
                var loadFile = function(event) {
                    var output = document.getElementById('output');
                    output.src = URL.createObjectURL(event.target.files[0]);
                };
            </script>
            <br/>
            <a class="btn btn-default" href="index.php?p=artista2" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_editar_foto; ?></a>
        </div> 

        <div class="form-group">
           <label><?php echo $lang_nome_artista; ?></label>
           <input class="form-control" type="text" name="artista_top2" value="<?php echo $artista_top2; ?>" />
       </div>

       <div class="form-group">
           <label><?php echo $lang_nome_musica; ?></label>
           <input class="form-control" type="text" name="musica_top2" value="<?php echo $musica_top2; ?>" />
       </div>
       <div class="form-group">
            <a class="btn btn-default" href="index.php?p=top2" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_up_musica; ?></a>
       </div>

<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 


</div>
</div>
</div>

<!--   Basic Table  -->
<div class="panel panel-default">
    <div class="panel-heading">
     3º <?php echo $lang_lugar; ?>
 </div>
 <div class="panel-body">
    <div class="table-responsive">
        <div class="form-group">                
            <label><?php echo $lang_foto_artista; ?></label>
            <br/>
            <img id="output" src="assets/img/artistas/artista3.png?img=<?php echo urlencode($cache_today); ?>" width="220" height="auto" />
            <br/><?php echo $lang_tamanho_recomendado; ?>: 220x130 pixels.
            <script>
                var loadFile = function(event) {
                    var output = document.getElementById('output');
                    output.src = URL.createObjectURL(event.target.files[0]);
                };
            </script>
            <br/>
            <a class="btn btn-default" href="index.php?p=artista3" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_editar_foto; ?></a>
        </div> 
        <div class="form-group">
           <label><?php echo $lang_nome_artista; ?></label>
           <input class="form-control" type="text" name="artista_top3" value="<?php echo $artista_top3; ?>" />
       </div>

       <div class="form-group">
           <label><?php echo $lang_nome_musica; ?></label>
           <input class="form-control" type="text" name="musica_top3" value="<?php echo $musica_top3; ?>" />
       </div>
        <div class="form-group">
            <a class="btn btn-default" href="index.php?p=top3" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_up_musica; ?></a>
       </div>
<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 


</div>
</div>
</div>

<!--   Basic Table  -->
<div class="panel panel-default">
    <div class="panel-heading">
     4º <?php echo $lang_lugar; ?>
 </div>
 <div class="panel-body">  
    <div class="table-responsive">
        <div class="form-group">                
            <label><?php echo $lang_foto_artista; ?></label>
            <br/>
            <img id="output" src="assets/img/artistas/artista4.png?img=<?php echo urlencode($cache_today); ?>" width="220" height="auto" />
            <br/><?php echo $lang_tamanho_recomendado; ?>: 220x130 pixels.
            <script>
                var loadFile = function(event) {
                    var output = document.getElementById('output');
                    output.src = URL.createObjectURL(event.target.files[0]);
                };
            </script>
            <br/>
            <a class="btn btn-default" href="index.php?p=artista4" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_editar_foto; ?></a>
        </div> 

        <div class="form-group">
           <label><?php echo $lang_nome_artista; ?></label>
           <input class="form-control" type="text" name="artista_top4" value="<?php echo $artista_top4; ?>" />
       </div>

       <div class="form-group">
           <label><?php echo $lang_nome_musica; ?></label>
           <input class="form-control" type="text" name="musica_top4" value="<?php echo $musica_top4; ?>" />
       </div>
       <div class="form-group">
            <a class="btn btn-default" href="index.php?p=top4" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_up_musica; ?></a>
       </div>
<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 


</div>
</div>
</div>

<!--   Basic Table  -->
<div class="panel panel-default">
    <div class="panel-heading">
     5º <?php echo $lang_lugar; ?>
 </div>
 <div class="panel-body">
    <div class="table-responsive">

        <div class="form-group">                
            <label><?php echo $lang_foto_artista; ?></label>
            <br/>
            <img id="output" src="assets/img/artistas/artista5.png?img=<?php echo urlencode($cache_today); ?>" width="220" height="auto" />
            <br/><?php echo $lang_tamanho_recomendado; ?>: 220x130 pixels.
            <script>
                var loadFile = function(event) {
                    var output = document.getElementById('output');
                    output.src = URL.createObjectURL(event.target.files[0]);
                };
            </script>
            <br/>
            <a class="btn btn-default" href="index.php?p=artista5" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_editar_foto; ?></a>
        </div> 

        <div class="form-group">
           <label><?php echo $lang_nome_artista; ?></label>
           <input class="form-control" type="text" name="artista_top5" value="<?php echo $artista_top5; ?>" />
       </div>

       <div class="form-group">
           <label><?php echo $lang_nome_musica; ?></label>
           <input class="form-control" type="text" name="musica_top5" value="<?php echo $musica_top5; ?>" />
       </div>
       <div class="form-group">
            <a class="btn btn-default" href="index.php?p=top5" ><i class="fa fa-pencil-square-o"></i> <?php echo $lang_up_musica; ?></a>
       </div>
<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> <?php echo $lang_salvar; ?></button> 


</div>
</div>
</div>


<?php greenCheckmark();?>
</form>



<?php } ?>
</div>