<?php include ("config.php");  ?>
<?php include("admin/includes/lang/$pulse_lang.php"); ?>
<?php include ("admin/bd/stream.php");  ?>
<?php include ("admin/bd/locutores.php");  ?>
<?php include ("admin/bd/mural.php");  ?>
<?php include ("admin/bd/top5.php");  ?>
<?php include ("admin/bd/anunciantes.php");  ?>
<?php include ("admin/bd/theme.php"); ?>
<?php $version = file_get_contents("version.txt"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title><?php echo $page_title; ?> - <?php echo $lang_menu_fotos; ?></title>
	<meta name="description" content="<?php echo $page_desc; ?>">
	<meta name="keywords" content="<?php echo $page_words; ?>" />
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<meta content="yes" name="apple-mobile-web-app-capable" />
	<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
	<link rel="icon" href="admin/assets/img/favicon.jpg">
	<link rel="shortcut icon" href="admin/assets/img/favicon.jpg" />
	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="admin/plugins/albuns/css/gridGallery.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/jquery.vegas.css">
	<link rel="stylesheet" href="assets/css/<?php echo $theme; ?>?v=<?php echo $version; ?>">
	<link rel="stylesheet" type="text/css" href="assets/css/<?php echo $corsite; ?>.css?v=<?php echo $version; ?>">
	<script async  src="assets/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
	<script src="admin/plugins/albuns/js/jquery-1.9.1.min.js"></script>
</head>
<body>

<?php include 'menu.php'; ?>

<div id="ajaxArea">
	<div class="pageContentArea">
		<section class="breadcrumb">
			 <div class="container">
				  <div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-6">
						  <h1><?php echo $lang_menu_fotos; ?></h1>
						  <h5><?php echo $lang_sub_fotos; ?></h5>
					  </div>
				  </div>
			 </div>
		</section>

		<div class="clearfix"></div>

		<section id="recent-albums">
			<div class="container">
				<div class="recent-album-list">
					<!-- PUT THIS HTML MARKUP WHERE YOU WANT THE GALLERY IN YOUR PAGE-->
					<div id="grid" data-directory="admin/data/img/albuns"></div>
				</div>
			</div>
		</section>
  </div>
</div>

<?php include ("anuncios.php");  ?>
<?php include ("rodape.php");  ?>

	<script defer  src="assets/js/bootstrap.min.js?v=<?php echo $version; ?>"></script>
	<script defer  src="assets/js/jquery.carouFredSel-6.2.1-packed.js?v=<?php echo $version; ?>"></script> 
	<script defer  src="assets/js/jquery.vegas.min.js?v=<?php echo $version; ?>"></script> 
	<script defer  src="assets/js/main.js?v=<?php echo $version; ?>"></script>
	<!-- Script galeria  -->
	<script src="admin/plugins/albuns/js/rotate-patch.js"></script>
	<script src="admin/plugins/albuns/js/waypoints.min.js"></script> <!-- if you wont use the Lazy Load feature erase this line -->
	<script src="admin/plugins/albuns/js/autoAlbums.min.js"></script>
	<script>
	  $(function(){
			//INITALIZE THE PLUGIN
			$('#grid').grid({
				  imagesOrder: 'byName', //byDate, byDateReverse, byName, byNameReverse, random
				  albumsOrder: 'none', //byDate, byDateReverse, byName, byNameReverse, random, none
				  folderCoverRandom: true, //If there is no folderCover image then get a random image
				  foldersAtTop: true, //If you want the folders to be always first and then the images
				  showNumFolder: true, //If you want to show the number of folders inside a folder
				  showNumImages: true, //If you want to show the number of images inside a folder
				  autoHideNumFolder: true, //If there is no folders inside a folder then don't show the number of folders
				  autoHideNumImages: false, //If there is no images inside a folder then don't show the number of images
				  isFitWidth: true, //Nedded to be true if you wish to center the gallery to its container
				  lazyLoad: true, //If you wish to load more images when it reach the bottom of the page
				  showNavBar: true, //Show the navigation bar?
				  imagesToLoadStart: 15, //The number of images to load when it first loads the grid
				  imagesToLoad: 5, //The number of images to load when you click the load more button
				  horizontalSpaceBetweenThumbnails: 5, //The space between images horizontally
				  verticalSpaceBetweenThumbnails: 5, //The space between images vertically
				  columnWidth: 240, //The width of each columns, if you set it to 'auto' it will use the columns instead
				  columns: 5, //The number of columns when you set columnWidth to 'auto'
				  columnMinWidth: 195, //The minimum width of each columns when you set columnWidth to 'auto'
				  isAnimated: true, //Animation when resizing or filtering with the nav bar
				  caption: true, //Show the caption in mouse over
				  captionType: 'grid', // 'grid', 'grid-fade', 'classic' the type of caption effect
				  lightBox: true, //Do you want the lightbox?
				  lightboxKeyboardNav: true, //Keyboard navigation of the next and prev image
				  lightBoxSpeedFx: 500, //The speed of the lightbox effects
				  lightBoxZoomAnim: true, //Do you want the zoom effect of the images in the lightbox?
				  lightBoxText: true, //If you wish to show the text in the lightbox
				  lightboxPlayBtn: true, //Show the play button?
				  lightBoxAutoPlay: false, //The first time you open the lightbox it start playing the images
				  lightBoxPlayInterval: 4000, //The interval in the auto play mode 
				  lightBoxShowTimer: true, //If you wish to show the timer in auto play mode
				  lightBoxStopPlayOnClose: false, //Stop the auto play mode when you close the lightbox?
				  hashTag: true, //Change the HasTag each time you navigate through albums (so you can share a single album)
			});
	  });
	</script>

	<script src="admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', '<?php echo $analytics_id; ?>');
	</script>

</body>
</html>