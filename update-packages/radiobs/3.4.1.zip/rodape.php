<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-sitemap"></span><?php echo $lang_menu; ?></h4>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6">
						<ul class="sitemap">
							<li><a href="home"><?php echo $lang_menu_home; ?></a></li>
							<li><a href="sobre"><?php echo $lang_menu_sobre; ?></a></li>
							<li><a href="noticias"><?php echo $lang_menu_noticias; ?></a></li>
					  		<?php if ($mural == 1) {echo "<li><a href='mural'>$lang_menu_mural</a></li>";}?>
					  		<li><a href="programacao"><?php echo $lang_menu_programacao; ?></a></li>
						</ul>
					</div>

					<div class="col-lg-6 col-md-6 col-sm-6">
						<ul class="sitemap">
							<li><a href="eventos"><?php echo $lang_menu_eventos; ?></a></li>
							<li><a href="fotos"><?php echo $lang_menu_fotos; ?></a></li>
							<li><a href="videos"><?php echo $lang_menu_videos; ?></a></li>
							<li><a href="equipe"><?php echo $lang_menu_equipe; ?></a></li>
							<li><a href="contato"><?php echo $lang_menu_contato; ?></a></li>
						</ul>
					</div>
				</div>
	  		</div>
	  
	  		<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-info-circle"></span><?php echo $lang_info; ?></h4>
				<p><?php echo $page_title; ?></p>
				<p><?php echo $page_desc; ?></p>
	 		</div>
	  
			<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-umbrella"></span><?php echo $lang_previsao_tempo; ?></h4>
				<?php include_once("admin/data/pages/previsao-do-tempo.html"); ?>   
			</div>
	  
			<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-envelope"></span><?php echo $lang_menu_contato; ?></h4>

				 <i class="fa fa-envelope-o fa-2x"></i> <?php echo $email_contact; ?>
				 <br/><br/>
				 <i class="fa fa-whatsapp fa-2x"></i> <a href="https://api.whatsapp.com/send?phone=<?php echo $nub_whatsapp; ?>" target="_blank">WhatsApp</a>
			</div>
	  	</div>   

		<ul class="social">
			<hr> 
			<?php if($visitas_select == 1 || $visitas_select == ""){include 'visitas.php';}  ?>
			<br>
			<?php if (!empty($facebook_url)) { ?>
				<li><a href="<?php echo $facebook_url; ?>" target="_bank" title="Facebook"><span class="fa fa-facebook"></span></a></li>
			<?php } ?>
			<?php if (!empty($twitter_url)) { ?>
				<li><a href="<?php echo $twitter_url; ?>" target="_bank" title="Twitter"><span class="fa fa-twitter"></span></a></li>
			<?php } ?>
			<?php if (!empty($pinterest_url)) { ?>
				<li><a href="<?php echo $pinterest_url; ?>" target="_bank" title="Pinterest"><span class="fa fa-pinterest"></span></a></li>
			<?php } ?>
			<?php if (!empty($linkedin_url)) { ?>
				<li><a href="<?php echo $linkedin_url; ?>" target="_bank" title="Linkedin"><span class="fa fa-linkedin"></span></a></li>
			<?php } ?>
			<?php if (!empty($flickr_url)) { ?>
				<li><a href="<?php echo $flickr_url; ?>" target="_bank" title="Flickr"><span class="fa fa-flickr"></span></a></li>
			<?php } ?>
			<?php if (!empty($youtube_url)) { ?>
				<li><a href="<?php echo $youtube_url; ?>" target="_bank" title="Youtube"><span class="fa fa-youtube"></span></a></li>
			<?php } ?>
			<?php if (!empty($google_url)) { ?>
				<li><a href="<?php echo $google_url; ?>" target="_bank" title="Google Plus"><span class="fa fa-google-plus"></span></a></li>
			<?php } ?>
			<?php if (!empty($instagram_url)) { ?>
				<li><a href="<?php echo $instagram_url; ?>" target="_bank" title="Instagram"><span class="fa fa-instagram"></span></a></li>
			<?php } ?>
		</ul>
		<p class="text-center"><?php echo $page_title; ?> © <?php echo date(Y); ?>  - <?php echo $lang_copyright; ?></p>
	</div>
</footer>

		