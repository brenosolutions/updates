<?php include ("admin/bd/player.php");  ?>
<?php include("admin/includes/lang/$pulse_lang.php"); ?>
<?php include ("config.php");  ?>
<?php $version = file_get_contents("version.txt"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta content="yes" name="apple-mobile-web-app-capable" />
	<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
	<style type="text/css">
  		#audio-player {width: 100%;border-top: #e62948 solid 2px;border-bottom: #e62948 solid 2px;bottom: 0;z-index: 9999;}
	</style>
	<link rel="stylesheet" type="text/css" href="assets/css/<?php echo $corsite; ?>.css?v=<?php echo $version; ?>">
	<?php 
		if ($pos_player == "fixed") {
			echo "<style> #audio-player{border-top: none;}</style>";
		}else{
			echo "<style> #audio-player{border-top: none;}</style>";
		} 
	?>
</head>
<body>
	<section id="audio-player">
	  <?php include_once("admin/data/pages/player-proprio.html"); ?>
	</section>
</body>
</html>
