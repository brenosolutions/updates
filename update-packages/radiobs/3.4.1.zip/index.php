<?php include ("config.php");  ?>
<?php include("admin/includes/lang/$pulse_lang.php"); ?>
<?php include ("admin/bd/player.php");  ?>
<?php include ("admin/bd/stream.php");  ?>
<?php include ("admin/bd/locutores.php");  ?>
<?php include ("admin/bd/top5.php");  ?>
<?php include ("admin/bd/anunciantes.php");  ?>
<?php $version = file_get_contents("version.txt"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title><?php echo $page_title; ?></title>
	<meta name="description" content="<?php echo $page_desc; ?>">
	<meta name="keywords" content="<?php echo $page_words; ?>" />

	<meta property="og:type" content="website">
	<meta property="og:title" content="<?php echo $page_title; ?>">
	<meta property="og:description" content="<?php echo $page_desc; ?>">
	<meta property="og:image:width" content="600">
	<meta property="og:image:height" content="600"> 
	<meta property="og:image" content="<?php if(empty($http_https)){echo 'http';}else{echo $http_https;} ?>://<?php echo $_SERVER['SERVER_NAME'] ?>/admin/assets/img/logo.png">
	<meta property="og:url" content="<?php if(empty($http_https)){echo 'http';}else{echo $http_https;} ?>://<?php echo $_SERVER['SERVER_NAME'] ?>">
	<meta content="yes" name="apple-mobile-web-app-capable" />
	<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />

	<link rel="icon" href="admin/assets/img/favicon.jpg">
	<link rel="shortcut icon" href="admin/assets/img/favicon.jpg" />

	<?php  
		if ($player_on == 1) {
		}else{
			echo "<style>
			html body {width: 100%;height: 100%;padding: 0px;overflow: hidden;font-family: arial;color: #6e6e6e;background-color: #000;margin: 0px;} #preview-frame {width: 100%;background-color: #fff;}
				#audio-player{font-size: 0px;}
			</style>";
		}
	?>
</head>
<body>

<?php  
	if ($player_on == 1) {
		include ("player.php");
	}else{
		include ("player-proprio.php");
	}
?>

	<iframe id="preview-frame" src="home.php" name="preview-frame" frameborder="0" noresize="noresize"></iframe>

	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script>
		var calcHeight = function() {
			$('#preview-frame').height($(window).height());
		}

		$(document).ready(function() {
			calcHeight();
		}); 

		$(window).resize(function() {
			calcHeight();
		}).load(function() {
			calcHeight();
		});
	</script>
		
	<script src="admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', '<?php echo $analytics_id; ?>');
	</script>

</body>
</html>