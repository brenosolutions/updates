// settings
// var jaxJquerySRCURL = 'http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js';
// var jaxJquerySRCURL = 'chat/js/jquery.min.js'; // using local jquery instance
var jaxResourceURL = ''; // root url where all resources are hosted, leave empty for relative URL

var jaxFontSize = '16px';
var jaxSkin = 'bs';
var refreshSeconds = 3;
var refreshTimeoutSeconds = 5;
var timeoutRetryAttempts = 3;
var showNamesColumn = true;
