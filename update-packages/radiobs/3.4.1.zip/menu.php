<header>
  <nav class="navbar yamm navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle fa fa-navicon"></button>
        <a class="navbar-brand" href="home">
            <img src="admin/assets/img/logo.png" alt="logo" />
        </a>
      </div>
      <div class="nav_wrapper">
        <div class="nav_scroll">
          <ul class="nav navbar-nav">
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/home.php"){ echo 'class="active"';}; ?>><a href="home"><?php echo $lang_menu_home; ?></a></li>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/sobre.php"){ echo 'class="active"';}; ?>><a href="sobre"><?php echo $lang_menu_sobre; ?></a></li>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/noticias.php"){ echo 'class="active"';}; ?>><a href="noticias"><?php echo $lang_menu_noticias; ?></a></li>
            <?php  if ($mural == 1) { ?>
              <li <?php if($_SERVER['SCRIPT_NAME'] == "/mural.php"){ echo 'class="active"';}; ?>><a href='mural'><?php echo $lang_menu_mural; ?></a></li>
            <?php } ?>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/programacao.php"){ echo 'class="active"';}; ?>><a href="programacao"><?php echo $lang_menu_programacao; ?></a></li>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/eventos.php"){ echo 'class="active"';}; ?>><a href="eventos"><?php echo $lang_menu_eventos; ?></a></li>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/fotos.php"){ echo 'class="active"';}; ?>><a href="fotos"><?php echo $lang_menu_fotos; ?></a></li>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/videos.php"){ echo 'class="active"';}; ?>><a href="videos"><?php echo $lang_menu_videos; ?></a></li>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/equipe.php"){ echo 'class="active"';}; ?>><a href="equipe"><?php echo $lang_menu_equipe; ?></a></li>
            <li <?php if($_SERVER['SCRIPT_NAME'] == "/contato.php"){ echo 'class="active"';}; ?>><a href="contato"><?php echo $lang_menu_contato; ?></a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
</header>

<ul class="vegas-slides hidden">
  <?php $gallery ="Bg"; include "admin/includes/gallery-bg.php"; ?> 
</ul>