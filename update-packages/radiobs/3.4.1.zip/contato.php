<?php include ("config.php");  ?>
<?php include("admin/includes/lang/$pulse_lang.php"); ?>
<?php include ("admin/bd/stream.php");  ?>
<?php include ("admin/bd/locutores.php");  ?>
<?php include ("admin/bd/mural.php");  ?>
<?php include ("admin/bd/top5.php");  ?>
<?php include ("admin/bd/anunciantes.php");  ?>
<?php include ("admin/bd/theme.php"); ?>
<?php $version = file_get_contents("version.txt"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title><?php echo $page_title; ?> - <?php echo $lang_menu_contato; ?></title>
	<meta name="description" content="<?php echo $page_desc; ?>">
	<meta name="keywords" content="<?php echo $page_words; ?>" />
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<meta content="yes" name="apple-mobile-web-app-capable" />
	<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
	<link rel="icon" href="admin/assets/img/favicon.jpg">
	<link rel="shortcut icon" href="admin/assets/img/favicon.jpg" />
	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css?">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/jquery.vegas.css">
	<link rel="stylesheet" href="assets/css/<?php echo $theme; ?>?v=<?php echo $version; ?>">
	<link rel="stylesheet" type="text/css" href="assets/css/<?php echo $corsite; ?>.css?v=<?php echo $version; ?>">
	<script async  src="assets/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
	<script defer  src="assets/js/jquery.js"></script>
</head>
<body>

<?php include 'menu.php'; ?>

<div id="ajaxArea">
	<div class="pageContentArea">
		<section class="breadcrumb">
			 <div class="container">
				  <div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-6">
						  <h1><?php echo $lang_menu_contato; ?></h1>
						  <h5><?php echo $lang_entre_contato; ?></h5>
					  </div>
				  </div>
			 </div>
		</section>
		<div class="clearfix"></div>
	  
		<section id="contact">
			<div class="container">
				<div class="row">
					<div class="col-lg-9 col-md-9 col-sm-9">
					  	<form id="contactform" action="assets/php/submit.php" method="post">
					  		<div class="row">
					  			<div class="col-lg-5 col-md-5 col-sm-5">
					  				<h5><?php echo $lang_nome; ?>:</h5>
					  				<input type="text" id="name" />
					  			</div>
					  			<div class="col-lg-5 col-md-5 col-sm-5">
					  				<h5><?php echo $lang_email; ?>:</h5>
					  				<input type="text" name="email" id="email" />
					  			</div>
					  		</div>
					  		<div class="row">
					  			<div class="col-lg-10 col-md-10 col-sm-10">
					  				<h5><?php echo $lang_mensagem; ?>:</h5>
					  				<textarea name="message" id="message"></textarea>
					  				<div class="text-center"><button id="submit1" type="submit"><?php echo $lang_enviar; ?></button></div><br><br>
					  			</div>
					  		</div>
					  	</form>
						<div id="valid-issue" style="display:none;"> <?php echo $lang_info_validas; ?></div>   
					</div>
				  
					<div class="col-lg-3 col-md-3 col-sm-3">
						<h3><?php echo $lang_info; ?></h3>
						<i class="fa fa-whatsapp fa-2x"></i>
						<p><a href="https://api.whatsapp.com/send?phone=<?php echo $nub_whatsapp; ?>" target="_blank">WhatsApp</a></p>
						<b class=" fa fa-envelope"></b>
						<p><?php echo $email_contact; ?></p>
						<br/>

						<?php if (!empty($facebook_url)) { ?>
							<a href="<?php echo $facebook_url; ?>" target="_bank" title="Facebook"><i class="fa fa-facebook fa-2x"></i></a>
						<?php } ?>
						<?php if (!empty($twitter_url)) { ?>
							<a href="<?php echo $twitter_url; ?>" target="_bank" title="Twitter"><i class="fa fa-twitter fa-2x"></i></a> 
						<?php } ?>
						<?php if (!empty($youtube_url)) { ?>
							<a href="<?php echo $youtube_url; ?>" target="_bank" title="Youtube"><i class="fa fa-youtube fa-2x"></i></a> 
						<?php } ?>
						<?php if (!empty($google_url)) { ?>
							<a href="<?php echo $google_url; ?>" target="_bank" title="Google Plus"><i class="fa fa-google-plus fa-2x"></i></a>
						<?php } ?>
						<?php if (!empty($instagram_url)) { ?>
							<a href="<?php echo $instagram_url; ?>" target="_bank" title="Instagram"><i class="fa fa-instagram fa-2x"></i></a>
						<?php } ?>

						
						
						 
						
				  </div>
			  </div>
		  </div>
	  </section>
  </div>
</div> 

<?php include ("anuncios.php");  ?>
<?php include ("rodape.php");  ?>

	<script defer src="assets/js/bootstrap.min.js?v=<?php echo $version; ?>"></script>
	<script defer src="assets/js/jquery.carouFredSel-6.2.1-packed.js?v=<?php echo $version; ?>"></script> 
	<script defer src="assets/js/jquery.vegas.min.js?v=<?php echo $version; ?>"></script> 
	<script defer src="assets/js/main.js?v=<?php echo $version; ?>"></script>  
	<script src="admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', '<?php echo $analytics_id; ?>');
	</script>

</body>
</html>
