﻿<!-- /. NAV Dashboard  -->
<li>
    <a <?php active('dashboard', '', 'active-menu');  ?> href="index.php?p=dashboard"><i class="fa fa-dashboard fa-2x"></i> <?php echo $lang_dashboard; ?></a>
</li>
<!-- /. NAV páginas  -->
<?php if($user_nivel == 1 && $perm_loc_page_sobre == 1 || $user_nivel == 2){ ?>
<li <?php active('manage-blocks', '', 'active'); active('manage-photo&g=Equipe', '', 'active');?>>
    <a  href="#"><i class="fa fa-file-text fa-2x"></i> <?php echo $lang_paginas; ?><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        <li>
            <a <?php active('manage-blocks', '', 'active-menu'); ?> href="index.php?p=manage-blocks"><i class="fa fa-pencil-square-o"></i><?php echo $lang_sobre; ?></a>
        </li>
    </ul>
  </li>
<?php } ?>

<!-- /. NAV Blog  -->
<?php if($user_nivel == 1 && $perm_loc_pub_slider == 1 || $user_nivel == 1 && $perm_loc_pub_anuncios == 1 || $user_nivel == 1 && $perm_loc_pub_equipe == 1 || $user_nivel == 1 && $perm_loc_pub_videos == 1 || $user_nivel == 1 && $perm_loc_pub_fotos == 1 || $user_nivel == 1 && $perm_loc_pub_noticias == 1 || $user_nivel == 1 && $perm_loc_pub_eventos == 1 || $user_nivel == 1 && $perm_loc_pub_widgets == 1 && $perm_loc_pub_podcasts == 1  || $user_nivel == 2){ ?>
<li <?php active('manage-photo&g=Slider', '', 'active'); active('manage-anuncios', '', 'active');active('manage-videos', '', 'active');active('gerenciar-albuns', '', 'active');active('manage-news', '', 'active');active('manage-eventos', '', 'active');active('manage-pages', '', 'active'); active('manage-equipe', '', 'active'); active('manage-podcasts', '', 'active');?>>
    <a href="#"><i class="fa fa-newspaper-o fa-2x"></i> <?php echo $lang_publicidade; ?><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">

        <?php if($user_nivel == 1 && $perm_loc_pub_podcasts == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-podcasts', '', 'active-menu');?> href="index.php?p=manage-podcasts"><i class="fa fa-microphone"></i><?php echo $lang_gerenciar_podcasts; ?></a>
        </li>
        <?php } ?>

        <?php if($user_nivel == 1 && $perm_loc_pub_slider == 1 || $user_nivel == 2){ ?>
         <li>
            <a <?php active('manage-photo&g=Slider', '', 'active-menu');?> href="index.php?p=manage-photo&g=Slider"><i class="fa fa-file-image-o"></i><?php echo $lang_gerenciar_slider; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_pub_anuncios == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-anuncios', '', 'active-menu');?> href="index.php?p=manage-anuncios"><i class="fa fa-bullhorn"></i><?php echo $lang_gerenciar_anuncios; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_pub_equipe == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-equipe', '', 'active-menu'); ?> href="index.php?p=manage-equipe"><i class="fa fa-group"></i><?php echo $lang_gerenciar_equipe; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_pub_videos == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-videos', '', 'active-menu');?> href="index.php?p=manage-videos"><i class="fa fa-film"></i></i><?php echo $lang_gerenciar_videos; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_pub_fotos == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('gerenciar-albuns', '', 'active-menu');?> href="index.php?p=gerenciar-albuns"><i class="fa fa-camera"></i></i><?php echo $lang_gerenciar_fotos; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_pub_noticias == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-news', '', 'active-menu');?> href="index.php?p=manage-news"><i class="fa fa-file-text-o"></i></i><?php echo $lang_gerenciar_noticias; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_pub_eventos == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-eventos', '', 'active-menu');?> href="index.php?p=manage-eventos"><i class="fa fa-calendar"></i></i><?php echo $lang_gerenciar_eventos; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_pub_widgets == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-pages', '', 'active-menu');?> href="index.php?p=manage-pages"><i class="fa fa-star-o"></i></i><?php echo $lang_gerenciar_widgets; ?></a>
        </li>
        <?php } ?>

    </ul>
  </li>
  <?php } ?>

  <?php if($user_nivel == 1 && $perm_loc_msg_pedido == 1 || $user_nivel == 1 && $perm_loc_msg_papo == 1 || $user_nivel == 1 && $perm_loc_msg_mural == 1 || $user_nivel == 2){ ?>
   <li <?php active('settings-chat', '', 'active'); active('pedidos', '', 'active'); active('manage-mural', '', 'active');?>>
    <a  href="#"><i class="fa fa-envelope-o fa-2x"></i> <?php echo $lang_mensagens; ?><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        <?php if($user_nivel == 1 && $perm_loc_msg_pedido == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('pedidos', '', 'active-menu');  ?> href="index.php?p=pedidos"><i class="fa fa-gavel"></i> <?php echo $lang_pedido_de_musicas; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_msg_papo == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-chat', '', 'active-menu');  ?> href="index.php?p=settings-chat"><i class="fa fa-comments-o"></i> <?php echo $lang_bate_papo_chat; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_msg_mural == 1 || $user_nivel == 2){ ?>
         <li>
            <a <?php active('manage-mural', '', 'active-menu');  ?> href="index.php?p=manage-mural"><i class="fa fa-quote-right"></i><?php echo $lang_mural_recados; ?></a>
        </li>
        <?php } ?>
    </ul>
  </li>
  <?php } ?>


<?php if($user_nivel == 1 && $perm_loc_aut_prog == 1 || $user_nivel == 1 && $perm_loc_aut_config == 1 || $user_nivel == 2){ ?>
<li <?php active('manage-programacao', '', 'active');active('settings-automacao', '', 'active'); ?>>
	<a href="#"><i class="fa fa-history fa-2x"></i> <?php echo $lang_automacao; ?><span class="fa arrow"></span></a>

	<ul class="nav nav-second-level">

        <?php if($user_nivel == 1 && $perm_loc_news_aut == 1 || $user_nivel == 2){ ?>
        <?php } ?>

        <?php if($user_nivel == 1 && $perm_loc_aut_prog == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('manage-programacao', '', 'active-menu');  ?> href="index.php?p=manage-programacao"><i class="fa fa-calendar"></i><?php echo $lang_programacao; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_aut_config == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-automacao', '', 'active-menu');  ?> href="index.php?p=settings-automacao"><i class="fa fa-cog"></i><?php echo $lang_configuracoes; ?></a>
        </li>
        <?php } ?>
        <li>
    </ul>
</li>
<?php } ?>

<?php if($user_nivel == 2){ ?>
<li <?php active('manage-users', '', 'active');active('settings-users', '', 'active'); ?>>
	<a href="#"><i class="fa fa-users fa-2x"></i> <?php echo $lang_usuarios; ?><span class="fa arrow"></span></a>

	<ul class="nav nav-second-level">
		<li>
            <a <?php active('manage-users', '', 'active-menu');  ?> href="index.php?p=manage-users"><i class="fa fa-headphones"></i><?php echo $lang_gerenciar_usuario; ?></a>
        </li>

        <li>
            <a <?php active('settings-users', '', 'active-menu');  ?> href="index.php?p=settings-users"><i class="fa fa-cog"></i><?php echo $lang_permissoes; ?></a>
        </li>
        <li>
    </ul>
</li>
<?php } ?>

<!-- /. NAV Configurações  -->
<?php if($user_nivel == 1 && $perm_loc_config_site == 1 || $user_nivel == 1 && $perm_loc_config_tema == 1 || $user_nivel == 1 && $perm_loc_config_play == 1 || $user_nivel == 1 && $perm_loc_config_stream == 1 || $user_nivel == 1 && $perm_loc_config_cam == 1 || $user_nivel == 1 && $perm_loc_config_top == 1 || $user_nivel == 1 && $perm_loc_config_enquete == 1 || $user_nivel == 1 && $perm_loc_config_recados == 1 || $user_nivel == 1 && $perm_loc_config_ouvinte == 1 || $user_nivel == 1 && $perm_loc_config_doacao == 1 || $user_nivel == 2){ ?>
<li <?php active('settings', '', 'active');active('settings-theme', '', 'active');active('settings-perfil', '', 'active');active('settings-player', '', 'active');active('settings-stream', '', 'active');active('settings-tv', '', 'active');active('settings-top5', '', 'active');active('settings-enquete', '', 'active');active('settings-mural', '', 'active');active('settings-ouvinte', '', 'active');active('settings-doacao', '', 'active'); ?>>
    <a href="#"><i class="fa fa-wrench fa-2x"></i> <?php echo $lang_configuracoes; ?><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        <?php if($user_nivel == 1 && $perm_loc_config_site == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings', '', 'active-menu');  ?> href="index.php?p=settings"><i class="fa fa-cog"></i><?php echo $lang_header_site; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_tema == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-theme', '', 'active-menu');  ?> href="index.php?p=settings-theme"><i class="fa fa-desktop"></i><?php echo $lang_tema; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_play == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-player', '', 'active-menu');  ?> href="index.php?p=settings-player"><i class="fa fa-play-circle"></i><?php echo $lang_player; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_stream == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-stream', '', 'active-menu');  ?> href="index.php?p=settings-stream"><i class="fa fa-volume-up"></i><?php echo $lang_streaming; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_cam == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-tv', '', 'active-menu');  ?> href="index.php?p=settings-tv"><i class="fa fa-video-camera"></i><?php echo $lang_camera_estudio; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_top == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-top5', '', 'active-menu');  ?> href="index.php?p=settings-top5"><i class="fa fa-music"></i><?php echo $lang_Top5; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_enquete == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-enquete', '', 'active-menu');  ?> href="index.php?p=settings-enquete"><i class="fa fa-check-circle"></i><?php echo $lang_enquete; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_recados == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-mural', '', 'active-menu');  ?> href="index.php?p=settings-mural"><i class="fa fa-comments-o"></i><?php echo $lang_mural_recados; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_ouvinte == 1 || $user_nivel == 2){ ?>
         <li>
            <a <?php active('settings-ouvinte', '', 'active-menu');  ?> href="index.php?p=settings-ouvinte"><i class="fa fa-star"></i><?php echo $lang_ouvinte_do_mes; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_config_doacao == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('settings-doacao', '', 'active-menu');  ?> href="index.php?p=settings-doacao"><i class="fa fa-money"></i><?php echo $lang_doacao; ?></a>
        </li>
        <?php } ?>
    </ul>
  </li>
  <?php } ?>

  <!-- /. NAV Ajuda  -->
<?php if($user_nivel == 1 && $perm_loc_ajuda_update == 1 || $user_nivel == 1 && $perm_loc_ajuda_license == 1 || $user_nivel == 1 && $perm_loc_ajuda_soft == 1 || $user_nivel == 2){ ?>
<li <?php active('sobre', '', 'active'); active('key-info', '', 'active');?>>
    <a href="#"><i class="fa fa-info-circle fa-2x"></i> <?php echo $lang_ajuda; ?><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        <?php if($user_nivel == 1 && $perm_loc_ajuda_update == 1 || $user_nivel == 2){ ?>
        <li>
            <a href="includes/update.php"><i class="fa fa-refresh"></i><?php echo $lang_atualizacoes; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_ajuda_license == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('key-info', '', 'active-menu');  ?> href="index.php?p=key-info"><i class="fa fa-key"></i><?php echo $lang_info_licenca; ?></a>
        </li>
        <?php } ?>
        <?php if($user_nivel == 1 && $perm_loc_ajuda_soft == 1 || $user_nivel == 2){ ?>
        <li>
            <a <?php active('sobre', '', 'active-menu');  ?> href="index.php?p=sobre"><i class="fa fa-question-circle"></i><?php echo $lang_sobre_software; ?></a>
        </li>
        <?php } ?>
    </ul>
  </li>
  <?php } ?>