<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-sitemap"></span><?php echo $lang_menu; ?></h4>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6">
						<ul class="sitemap">
							<li><a href="home"><?php echo $lang_menu_home; ?></a></li>
							<li><a href="sobre"><?php echo $lang_menu_sobre; ?></a></li>
							<li><a href="news"><?php echo $lang_menu_noticias; ?></a></li>
					  		<?php if ($mural == 1) {echo "<li><a href='mural'>$lang_menu_mural</a></li>";}?>
					  		<li><a href="programacao"><?php echo $lang_menu_programacao; ?></a></li>
						</ul>
					</div>

					<div class="col-lg-6 col-md-6 col-sm-6">
						<ul class="sitemap">
							<li><a href="eventos"><?php echo $lang_menu_eventos; ?></a></li>
							<li><a href="fotos"><?php echo $lang_menu_fotos; ?></a></li>
							<li><a href="videos"><?php echo $lang_menu_videos; ?></a></li>
							<li><a href="equipe"><?php echo $lang_menu_equipe; ?></a></li>
							<li><a href="contato"><?php echo $lang_menu_contato; ?></a></li>
						</ul>
					</div>
				</div>
	  		</div>
	  
	  		<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-info-circle"></span><?php echo $lang_info; ?></h4>
				<p><?php echo $page_title; ?></p>
				<p><?php echo $page_desc; ?></p>
	 		</div>
	  
			<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-umbrella"></span><?php echo $lang_previsao_tempo; ?></h4>
				<?php include_once("admin/data/pages/previsao-do-tempo.html"); ?>   
			</div>
	  
			<div class="col-lg-3 col-md-3 col-sm-3">
				<h4><span class="fa fa-envelope"></span><?php echo $lang_menu_contato; ?></h4>

				 <i class="fa fa-envelope-o fa-2x"></i> <?php echo $email_contact; ?>
				 <br/><br/>
				 <?php if (!empty($nub_whatsapp)) { ?>
				 <i class="fa fa-whatsapp fa-2x"></i> <a class="no-ajaxy" href="https://api.whatsapp.com/send?phone=<?php echo $nub_whatsapp; ?>" target="_blank">WhatsApp</a>
				 <?php } ?>
			</div>
	  	</div>   

		<ul class="social">
			<hr> 
			<?php if($visitas_select == 1 || $visitas_select == ""){include 'inc/visitas.php';}  ?>
			<br><br>

			<?php if (!empty($instagram_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $instagram_url; ?>" target="_bank" title="Instagram"><span class="fa fa-instagram"></span></a></li>
			<?php } ?>

			<?php if (!empty($nub_whatsapp)) { ?>
				<li><a class="no-ajaxy" href="https://api.whatsapp.com/send?phone=<?php echo $nub_whatsapp; ?>" target="_bank" title="WhatsApp"><span class="fa fa-whatsapp"></span></a></li>
			<?php } ?>

			<?php if (!empty($telegram_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $telegram_url; ?>" target="_bank" title="Telegram"><span class="fa fa-telegram"></span></a></li>
			<?php } ?>

			<?php if (!empty($youtube_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $youtube_url; ?>" target="_bank" title="Youtube"><span class="fa fa-youtube"></span></a></li>
			<?php } ?>

			<?php if (!empty($facebook_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $facebook_url; ?>" target="_bank" title="Facebook"><span class="fa fa-facebook"></span></a></li>
			<?php } ?>

			<?php if (!empty($twitter_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $twitter_url; ?>" target="_bank" title="Twitter"><span class="fa fa-twitter"></span></a></li>
			<?php } ?>

			<?php if (!empty($soundcloud_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $soundcloud_url; ?>" target="_bank" title="SoundCloud"><span class="fa fa-soundcloud"></span></a></li>
			<?php } ?>

			<?php if (!empty($tiktok_url)) { ?>
			<li><a class="no-ajaxy" href="<?php echo $tiktok_url; ?>" target="_bank" title="TikTok"><svg width="16pt" height="16pt" viewBox="0 0 512 512" ><path d="m432.734375 112.464844c-53.742187 0-97.464844-43.722656-97.464844-97.464844 0-8.285156-6.714843-15-15-15h-80.335937c-8.28125 0-15 6.714844-15 15v329.367188c0 31.59375-25.707032 57.296874-57.300782 57.296874s-57.296874-25.703124-57.296874-57.296874c0-31.597657 25.703124-57.300782 57.296874-57.300782 8.285157 0 15-6.714844 15-15v-80.335937c0-8.28125-6.714843-15-15-15-92.433593 0-167.632812 75.203125-167.632812 167.636719 0 92.433593 75.199219 167.632812 167.632812 167.632812 92.433594 0 167.636719-75.199219 167.636719-167.632812v-145.792969c29.851563 15.917969 63.074219 24.226562 97.464844 24.226562 8.285156 0 15-6.714843 15-15v-80.335937c0-8.28125-6.714844-15-15-15zm0 0"/></svg></a></li>
			<?php } ?>

			<?php if (!empty($pinterest_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $pinterest_url; ?>" target="_bank" title="Pinterest"><span class="fa fa-pinterest"></span></a></li>

			<?php } ?>
			
			<?php if (!empty($linkedin_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $linkedin_url; ?>" target="_bank" title="Linkedin"><span class="fa fa-linkedin"></span></a></li>
			<?php } ?>

			<?php if (!empty($flickr_url)) { ?>
				<li><a class="no-ajaxy" href="<?php echo $flickr_url; ?>" target="_bank" title="Flickr"><span class="fa fa-flickr"></span></a></li>
			<?php } ?>

		</ul>
		<p class="text-center"><?php echo $page_title; ?> © <?php echo date('Y'); ?>  - <?php echo $lang_copyright; ?></p>
	</div>
</footer>

		