<?php

if (isset($_POST)){
	$arquivo = "../admin/bd/pedidos.php";

	$name = htmlspecialchars(strip_tags(stripslashes($_POST['nome'])));
	$email = strip_tags(stripslashes($_POST['email']));
	$message = htmlspecialchars(strip_tags(stripslashes($_POST['message'])));

	$newline = 
	"<tr><th>". $name.
	"</th><th>". $email.
	"</th><th width='600px'>". $message.
	"</th><th>". date("d/m/Y - H:i:s").
	"</th></tr>";
	$open = fopen($arquivo,"a+");
	$write = fwrite($open,$newline);
}