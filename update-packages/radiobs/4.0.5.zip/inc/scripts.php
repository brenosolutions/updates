<!-- <script async src="assets/js/modernizr-2.6.2-respond-1.1.0.min.js"></script> -->
<script defer src="assets/js/jquery.js"></script>
<script defer src="assets/js/ajaxify.min.js"></script>
<script defer src="assets/js/bootstrap.min.js?v=<?php echo $version; ?>"></script>
<?php if(!empty($scripts)){ foreach ($scripts as $value) {echo '<script defer src="'.$value.'?v='.$version.'"></script>';}} ?>
<script defer src="assets/js/jquery.carouFredSel-6.2.1-packed.js?v=<?php echo $version; ?>"></script>
<script defer src="assets/js/jquery.vegas.min.js?v=<?php echo $version; ?>"></script>
<script defer src="assets/js/jquery.flexslider-min.js?v=<?php echo $version; ?>"></script>
<?php if ($enquete == 1) { ?>
<script defer src="assets/enquete/ajax-poll.php?v=2"></script>
<?php } ?>
<script defer src="assets/jPlayer/jquery.jplayer.min.js"></script>
<script defer src="assets/jPlayer/add-on/jplayer.playlist.min.js"></script>
<?php if ($top_5 == 1 || $top_5 == 2){ ?>
<script src="https://www.youtube.com/player_api"></script>
<?php } ?>
<script defer src="assets/js/main.min.js?v=<?php echo $version; ?>"></script>
<script defer src="admin/includes/tracker.js?uri=<?php echo isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/index.php'; ?>&ref=<?php echo isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : ''; ?>"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?php echo $analytics_id; ?>');
</script>