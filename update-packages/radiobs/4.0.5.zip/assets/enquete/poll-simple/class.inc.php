<?php

class CTClass extends CTClassBase
{
	function setupPoll( $poll ) {
		$vote_input = null;
		$vote_block = null;
		$vote_cookies_time = null;

		//-- Poll Title
		include ("../../admin/bd/enquete.php");

		$poll->attr( "title", "$pergunta_enquete" );

		//-- Poll Options

		$poll->addItem("$resposta1");
		$poll->addItem("$resposta2");

		if (!empty($resposta3)) {
			$poll->addItem("$resposta3");
		}

		if (!empty($resposta4)) {
			$poll->addItem("$resposta4");
		}

		if (!empty($resposta5)) {
			$poll->addItem("$resposta5");
		}

		if (!empty($resposta6)) {
			$poll->addItem("$resposta6");
		}

		if (!empty($resposta7)) {
			$poll->addItem("$resposta7");
		}

		if (!empty($resposta8)) {
			$poll->addItem("$resposta8");
		}

		if (!empty($resposta9)) {
			$poll->addItem("$resposta9");
		}

		if (!empty($resposta10)) {
			$poll->addItem("$resposta10");
		}

		if (!empty($resposta11)) {
			$poll->addItem("$resposta11");
		}

		if (!empty($resposta12)) {
			$poll->addItem("$resposta12");
		}
		if (!empty($resposta13)) {
			$poll->addItem("$resposta13");
		}
		if (!empty($resposta14)) {
			$poll->addItem("$resposta14");
		}
		if (!empty($resposta15)) {
			$poll->addItem("$resposta15");
		}


		//-- Text used in polls
		$poll->attr( "msg-vote", "Votar" );
		$poll->attr( "msg-select-one", "Selecione uma opção" );
		$poll->attr( "msg-already-voted", "Você já votou!" );
		$poll->attr( "msg-view-result", "Resultados" );
		$poll->attr( "msg-thank-you", "Obrigado por votar!" );
		$poll->attr( "msg-return", "Voltar" );
		$poll->attr( "msg-total", "Total" );
		$poll->attr( "msg-reset-block", "Redefinir IP e bloco de cookies" );
		$poll->attr( "msg-not-started", "A votação ainda não começou." );
		$poll->attr( "msg-ended", "A votação terminou, obrigado!" );

		//-- Display "Reset IP & Cookie Block" button
		//--	Show: true
		//--	Hide: false
		$poll->attr( "b-reset-block", false );

		//-- Single selection or multiple selection
		//--	single selection: "radio"
		//--	multiple selection: "checkbox"
		if (!empty($vote_input)) {
			$poll->attr( "vote-input", $vote_input );
		}else{
			$poll->attr( "vote-input", "radio" );
		}
		
		//-- Specify the time delay on tool tips in milliseconds
		$poll->attr( "tip-box-duration", 1000 );

		//-- Prevent users from voting more than once by IP address
		//--	"true" or "false"
		if (!empty($vote_block)) {
			if ($vote_block == 'ip') {
				$poll->attr( "enable-ip-block", true );
			}else{
				$poll->attr( "enable-ip-block", false );
			}
		}else{
			$poll->attr( "enable-ip-block", true );
		}

		//-- Prevent users from voting more than once by Cookie
		//--	"true" or "false"

		if (!empty($vote_block)) {
			if ($vote_block == 'cookies') {
				$poll->attr( "enable-cookie-block", true );
			}else{
				$poll->attr( "enable-cookie-block", false );
			}
		}else{
			$poll->attr( "enable-cookie-block", false );
		}
		

		//-- Specifiy the cookie's life span in seconds
		//--	(e.g.)　60*60*24 => One Day
		//--	(e.g.)　60*60*24*365 => One Year

		if (!empty($vote_cookies_time)) {
			$poll->attr("cookie-block-period", 60*$vote_cookies_time);
		}else{
			$poll->attr("cookie-block-period", 60*60*24);
		}
		

		//-- Specifiy Start and End Date&Time:
		//-- Enter an empty string ("") if you don't need to specify it.
		//--	(e.g.)　"2010-01-02"
		//--	(e.g.)　"2015-03-01 15:20"
		$poll->attr( "dt-start", "" );
		$poll->attr( "dt-end", "" );

		//-- end
		return true;
	}
}

?>