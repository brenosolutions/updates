<?php

	foreach (glob("admin/data/stats/sessions/sess_*") as $filename) {
	    if (filemtime($filename) + 240 < time()) {    
	      @unlink($filename);     
	    }
	}

	session_save_path("admin/data/stats/sessions");

	function getUsersOnline() { 
		$count  = 0; 
		$handle = opendir(session_save_path()); 
		
		if ($handle == false) { 
			return -1;
		} 
		
		while (($file = readdir($handle)) != false) { 
			
			if (preg_match("/^sess/", $file)) {
				$count++; 
			}
		} 
				
		closedir($handle); 
		return $count; 
	}


//calculating stats
$visitors  = array();
$show_date = date('m.d.y');

foreach ((glob("admin/data/stats/*.txt")) as $fl) {
	$file = null;
	$collection[] = $file;
	$file = basename($fl,".txt");
	//reading data
	$file_adr  = "admin/data/stats/$file.txt";
	$open      = fopen($file_adr,"r");
	$file_data = fread($open, filesize($file_adr));
	fclose($open);
				
	$conts = explode("\n", $file_data);	
			
	foreach ($conts as $visit) {
		$visit   = explode("|", $visit);
		$ip      = trim($visit[0]);
								
		//visitors
		if (!isset($visitors[$ip])) { 
		    $visitors[$ip] = 1;
		} else{ 
			$visitors[$ip]++;
		}		
	}

}
	
	$online = getUsersOnline();
	$visita_unica = count($visitors);

	echo "<span class=\"fa fa-info-circle\"> $lang_visitas: $visita_unica </span>   |   ";

	echo "<span class=\"fa fa-info-circle\"> $lang_online: $online</span>";

?>