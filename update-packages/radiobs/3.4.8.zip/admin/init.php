<?php

	include_once("../config.php");
	include_once("bd/player.php");
	include_once("bd/users.php");
	include_once("bd/doacao.php");
	include_once("bd/tv.php");
	include_once("bd/mural.php");
	include_once("bd/automacao.php");
	include_once("bd/stream.php");
	include_once("bd/theme.php");
	include_once("bd/top5.php");
	include_once("bd/enquete.php");
	include_once("bd/ouvinte.php");
	include_once("bd/chat.php");
	include_once("includes/path.php");
	include_once("includes/lang/$pulse_lang.php");
	include_once("includes/helpers/functions.php");
	include_once("includes/login.php");
	date_default_timezone_set("$fuso_horario");
	$startpage = "dashboard";
	$cache_today = date("F j, Y, g:i a s");
	$semana_atual = date('D');

	include_once("helpers/users_lib.php");
	$get_users = new show_Users; 
	foreach ($get_users->get_blog_users(150,'') as $users){
	    if($_SESSION['login_id'] == $users[0]){
	    	$user_foto = $users[1];
	    	$user_nome = $users[2];
	    	$user_email = $users[3];
	    	$user_nivel = $users[6];
	    }
	  }
?>
