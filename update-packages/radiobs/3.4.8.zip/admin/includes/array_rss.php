<?php

    $rss_servidor_select_options = array(
        array('G1 - Editorias','g1-editoriais'),
        array('G1 - Regiões','g1-regioes')
     );

	if ($rss_servidor_select == 'g1-editoriais') {
        $rss_select_options = array(
            array('G1 - Todas as notícias','http://g1.globo.com/dynamo/rss2.xml'),
            array('G1 - Brasil','http://g1.globo.com/dynamo/brasil/rss2.xml'),
            array('G1 - Carros','http://g1.globo.com/dynamo/carros/rss2.xml'),
            array('G1 - Ciência e Saúde','http://g1.globo.com/dynamo/ciencia-e-saude/rss2.xml'),
            array('G1 - Concursos e Emprego','http://g1.globo.com/dynamo/concursos-e-emprego/rss2.xml'),
            array('G1 - Economia','http://g1.globo.com/dynamo/economia/rss2.xml'),
            array('G1 - Educação','http://g1.globo.com/dynamo/educacao/rss2.xml'),
            array('G1 - Loterias','http://g1.globo.com/dynamo/loterias/rss2.xml'),
            array('G1 - Mundo','http://g1.globo.com/dynamo/mundo/rss2.xml'),
            array('G1 - Música','http://g1.globo.com/dynamo/musica/rss2.xml'),
            array('G1 - Natureza','http://g1.globo.com/dynamo/natureza/rss2.xml'),
            array('G1 - Planeta Bizarro','http://g1.globo.com/dynamo/planeta-bizarro/rss2.xml'),
            array('G1 - Política','http://g1.globo.com/dynamo/politica/mensalao/rss2.xml'),
            array('G1 - Pop & Arte','http://g1.globo.com/dynamo/pop-arte/rss2.xml'),
            array('G1 - Tecnologia e Games','http://g1.globo.com/dynamo/tecnologia/rss2.xml'),
            array('G1 - Turismo e Viagem','http://g1.globo.com/dynamo/turismo-e-viagem/rss2.xml'),
        );
    }elseif ($rss_servidor_select == 'g1-regioes') {
        $rss_select_options = array(
            array('G1 - Acre','http://g1.globo.com/dynamo/ac/acre/rss2.xml'),
            array('G1 - Alagoas','http://g1.globo.com/dynamo/al/alagoas/rss2.xml'),
            array('G1 - Amapá','http://g1.globo.com/dynamo/ap/amapa/rss2.xml'),
            array('G1 - Amazonas','http://g1.globo.com/dynamo/am/amazonas/rss2.xml'),
            array('G1 - Bahia','http://g1.globo.com/dynamo/bahia/rss2.xml'),
            array('G1 - Ceará','http://g1.globo.com/dynamo/ceara/rss2.xml'),
            array('G1 - Distrito Federal','http://g1.globo.com/dynamo/distrito-federal/rss2.xml'),
            array('G1 - Espírito Santo','http://g1.globo.com/dynamo/espirito-santo/rss2.xml'),
            array('G1 - Goiás','http://g1.globo.com/dynamo/goias/rss2.xml'),
            array('G1 - Maranhão','http://g1.globo.com/dynamo/ma/maranhao/rss2.xml'),
            array('G1 - Mato Grosso','http://g1.globo.com/dynamo/mato-grosso/rss2.xml'),
            array('G1 - Mato Grosso do Sul','http://g1.globo.com/dynamo/mato-grosso-do-sul/rss2.xml'),
            array('G1 - Minas Gerais','http://g1.globo.com/dynamo/minas-gerais/rss2.xml'),
            array('G1 - MG - Centro-Oeste','http://g1.globo.com/dynamo/mg/centro-oeste/rss2.xml'),
            array('G1 - MG - Grande Minas','http://g1.globo.com/dynamo/mg/grande-minas/rss2.xml'),
            array('G1 - MG - Sul de Minas','http://g1.globo.com/dynamo/mg/sul-de-minas/rss2.xml'),

            array('G1 - MG - Triângulo Mineiro','http://g1.globo.com/dynamo/minas-gerais/triangulo-mineiro/rss2.xml'),
            array('G1 - MG - Vales de Minas Gerais','http://g1.globo.com/dynamo/mg/vales-mg/rss2.xml'),
            array('G1 - MG - Zona da Mata','http://g1.globo.com/dynamo/mg/zona-da-mata/rss2.xml'),
            array('G1 - Pará','http://g1.globo.com/dynamo/pa/para/rss2.xml'),
            array('G1 - Paraíba','http://g1.globo.com/dynamo/pb/paraiba/rss2.xml'),
            array('G1 - Paraná','http://g1.globo.com/dynamo/pr/parana/rss2.xml'),
            array('G1 - PR - Campos Gerais e Sul','http://g1.globo.com/dynamo/pr/campos-gerais-sul/rss2.xml'),
            array('G1 - Oeste e Sudoeste','http://g1.globo.com/dynamo/pr/oeste-sudoeste/rss2.xml'),
            array('G1 - PR - Norte e Noroeste','http://g1.globo.com/dynamo/pr/norte-noroeste/rss2.xml'),
            array('G1 - Pernambuco','http://g1.globo.com/dynamo/pernambuco/rss2.xml'),
            array('G1 - PE - Caruaru e Região','http://g1.globo.com/dynamo/pe/caruaru-regiao/rss2.xml'),
            array('G1 - PE - Petrolina e Região','http://g1.globo.com/dynamo/pe/petrolina-regiao/rss2.xml'),
            array('G1 - Rio de Janeiro','http://g1.globo.com/dynamo/rio-de-janeiro/rss2.xml'),
            array('G1 - RJ - Região Serrana','http://g1.globo.com/dynamo/rj/regiao-serrana/rss2.xml'),
            array('G1 - RJ - Região dos Lagos','http://g1.globo.com/dynamo/rj/regiao-dos-lagos/rss2.xml'),
            array('G1 - RJ - Norte Fluminense','http://g1.globo.com/dynamo/rj/norte-fluminense/rss2.xml'),
            array('G1 - RJ - Sul e Costa Verde','http://g1.globo.com/dynamo/rj/sul-do-rio-costa-verde/rss2.xml'),
            array('G1 - Rio Grande do Norte','http://g1.globo.com/dynamo/rn/rio-grande-do-norte/rss2.xml'),
            array('G1 - Rio Grande do Sul ','http://g1.globo.com/dynamo/rs/rio-grande-do-sul/rss2.xml'),
            array('G1 - Rondônia','http://g1.globo.com/dynamo/ro/rondonia/rss2.xml'),
            array('G1 - Roraima','http://g1.globo.com/dynamo/rr/roraima/rss2.xml'),
            array('G1 - Santa Catarina','http://g1.globo.com/dynamo/sc/santa-catarina/rss2.xml'),
            array('G1 - São Paulo','http://g1.globo.com/dynamo/sao-paulo/rss2.xml'),
            array('G1 - SP - Bauru e Marília','http://g1.globo.com/dynamo/sp/bauru-marilia/rss2.xml'),
            array('G1 - SP - Campinas e região','http://g1.globo.com/dynamo/sp/campinas-regiao/rss2.xml'),
            array('G1 - SP - Itapetininga e região','http://g1.globo.com/dynamo/sao-paulo/itapetininga-regiao/rss2.xml'),
            array('G1 - SP - Mogi das Cruzes e Suzano','http://g1.globo.com/dynamo/sp/mogi-das-cruzes-suzano/rss2.xml'),
            array('G1 - SP - Piracicaba e região','http://g1.globo.com/dynamo/sp/piracicaba-regiao/rss2.xml'),
            array('G1 - SP - Prudente e região','http://g1.globo.com/dynamo/sp/presidente-prudente-regiao/rss2.xml'),
            array('G1 - SP - Ribeirão Preto e Franca','http://g1.globo.com/dynamo/sp/ribeirao-preto-franca/rss2.xml'),
            array('G1 - SP - Rio Preto e Araçatuba','http://g1.globo.com/dynamo/sao-paulo/sao-jose-do-rio-preto-aracatuba/rss2.xml'),
            array('G1 - SP - Santos e Região','http://g1.globo.com/dynamo/sp/santos-regiao/rss2.xml'),
            array('G1 - SP - São Carlos e Araraquara','http://g1.globo.com/dynamo/sp/sao-carlos-regiao/rss2.xml'),
            array('G1 - SP - Sorocaba e Jundiaí','http://g1.globo.com/dynamo/sao-paulo/sorocaba-jundiai/rss2.xml'),
            array('G1 - SP - Vale do Paraíba e região','http://g1.globo.com/dynamo/sp/vale-do-paraiba-regiao/rss2.xml'),
            array('G1 - Sergipe','http://g1.globo.com/dynamo/se/sergipe/rss2.xml'),
            array('G1 - Tocantins','http://g1.globo.com/dynamo/to/tocantins/rss2.xml'),
            array('G1 - VC no G1','http://g1.globo.com/dynamo/vc-no-g1/rss2.xml')
        );
    }

?>