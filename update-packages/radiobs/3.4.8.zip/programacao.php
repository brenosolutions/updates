<?php include ("config.php");  ?>
<?php include("admin/includes/lang/$pulse_lang.php"); ?>
<?php include ("admin/bd/stream.php");  ?>
<?php include ("admin/bd/automacao.php");  ?>
<?php include ("admin/bd/mural.php");  ?>
<?php include ("admin/bd/top5.php");  ?>
<?php include ("admin/bd/anunciantes.php");  ?>
<?php include ("admin/bd/theme.php"); ?>
<?php $version = file_get_contents("version.txt"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title><?php echo $page_title; ?> - <?php echo $lang_menu_programacao; ?></title>
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<meta name="description" content="<?php echo $page_desc; ?>">
	<meta name="keywords" content="<?php echo $page_words; ?>" />
	<meta content="yes" name="apple-mobile-web-app-capable" />
	<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
	<link rel="icon" href="admin/assets/img/favicon.jpg">
	<link rel="shortcut icon" href="admin/assets/img/favicon.jpg" />
	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/jquery.vegas.css">
	<link rel="stylesheet" href="assets/css/<?php echo $theme; ?>?v=<?php echo $version; ?>">
	<link rel="stylesheet" href="assets/css/tabs.css">
	<link rel="stylesheet" type="text/css" href="assets/css/<?php echo $corsite; ?>.css?v=<?php echo $version; ?>">
	<script async  src="assets/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
	<script defer  src="assets/js/jquery.js"></script>
</head>
<body>

<?php include 'menu.php'; ?>

<div id="ajaxArea">
	<div class="pageContentArea">
		<section class="breadcrumb">
			 <div class="container">
				  <div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-6">
						  <h1><?php echo $lang_menu_programacao; ?></h1>
						  <h5><?php echo $lang_sub_programacao; ?></h5>
					  </div>
				  </div>
			 </div>
		</section>
		<div class="clearfix"></div>

		<section id="updates">
			<div class="container">
				<div class="row">
					<div class="col-lg-9 col-md-9 col-sm-9">
					  <?php include_once("admin/includes/programacao-page.php"); ?>
					</div>

					<div class="col-lg-3 col-md-3 col-sm-3">
						<h1><?php echo $lang_aplicativos; ?></h1>
						<div class="banner-app">
							<?php include ("admin/bd/$apk_select"); ?>
							<?php include ("admin/bd/$ios_select"); ?>
						</div>

						<br/>

						<?php include 'admin/includes/pedido-page.php'; ?>
					</div>
				</div>
			</div>    
		</section>
	</div>
</div>  

<?php include ("anuncios.php");  ?>
<?php include ("rodape.php");  ?>

<script defer src="assets/js/bootstrap.min.js?v=<?php echo $version; ?>"></script>
<script defer src="assets/js/jquery.carouFredSel-6.2.1-packed.js?v=<?php echo $version; ?>"></script> 
<script defer src="assets/js/jquery.vegas.min.js?v=<?php echo $version; ?>"></script> 
<script defer src="assets/js/main.js?v=<?php echo $version; ?>"></script>  
<script src="admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>
<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());
	gtag('config', '<?php echo $analytics_id; ?>');
</script>

</body>
</html>
