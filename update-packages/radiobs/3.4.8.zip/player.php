<?php include ("config.php");  ?>

<?php include("admin/includes/lang/$pulse_lang.php"); ?>

<?php include ("admin/bd/player.php");  ?>

<?php include ("admin/bd/stream.php");  ?>

<?php include ("admin/bd/automacao.php");  ?>

<?php include ("admin/bd/top5.php");  ?>

<?php include ("admin/bd/anunciantes.php");  ?>

<?php include ("admin/bd/theme.php"); ?>

<?php $version = file_get_contents("version.txt"); ?>

<!DOCTYPE html>

<html lang="pt-br">

<head>

	<meta charset="utf-8">

	<meta content="yes" name="apple-mobile-web-app-capable" />

 	<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />

	<link rel="icon" href="admin/assets/img/favicon.jpg">

	<link rel="shortcut icon" href="admin/assets/img/favicon.jpg" />

	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

 	<link rel="stylesheet" href="assets/css/font-awesome.min.css">



	<style type="text/css">

		html body {width: 100%;height: 100%;padding: 0px;overflow: hidden;font-family: arial;font-size: 10px;color: #6e6e6e;background-color: #000;} #preview-frame {width: 100%;background-color: #fff;}

		#audio-player {

			position: <?php echo $pos_player ?>;

			width: 100%;

			height: 65px;

			left: -17px;

			border-top: #e62948 solid 2px;

			border-bottom: #e62948 solid 2px;

			bottom: 0;

			z-index: 9999;

			transition: all .2s ease-in-out;

			-webkit-transition: all .2s ease-in-out;

			-moz-transition: all .2s ease-in-out;

			-o-transition: all .2s ease-in-out;

			-ms-transition: all .2s ease-in-out;

			background: <?php echo $back_player ?>;

		}

		.rock-player .controls {

			z-index: 100;

		}



	</style>



	<link rel="stylesheet" href="assets/css/<?php echo $theme; ?>?v=<?php echo $version; ?>">

	<link rel="stylesheet" type="text/css" href="assets/css/<?php echo $corsite; ?>.css?v=<?php echo $version; ?>">

	<?php 

		if ($pos_player == "fixed") {

		  	echo "<style> #audio-player{border-bottom: none;}</style>";

		}else{

			echo "<style> #audio-player{border-top: none;}</style>";

		} 

	?>



  <script async  src="assets/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>

  <script src="assets/js/jquery.js"></script>

  

</head>

<body>



	<section id="audio-player">



		<div class="container">

			<div class="rock-player">

				<div class="playListTrigger">

					<!--<a href="#"><i class="fa fa-list"></i></a>-->

		  		</div>

		  		<div class="row">

					<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">

				  		<div class="row">



							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

					 			<div id="player-instance" class="jp-jplayer"></div>

								<div class="controls">

									<div class="play-pause jp-play"></div>

									<div class="play-pause jp-pause" style="display:none"></div>

									<div class="jp-volume-controls">

										<button class="jp-mute" role="button" tabindex="0">mute</button>

										<button class="jp-volume-max" role="button" tabindex="0">max volume</button>

										<div class="jp-volume-bar">

											<div class="jp-volume-bar-value"></div>

										</div>

									</div>

									

								  </div>

							</div>



							<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">

								<div class="player-status">

									<h5 class="audio-title"></h5>

									<div class="audio-timer">

										<span class="current-time jp-current-time">00:00</span> / <span class="total-time jp-duration">0:00</span>

									</div>

					  			</div>

							</div>



							<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">

								<div class="player-social">

									<?php include ("admin/bd/botoes/$bapk_select"); ?>

									<?php include ("admin/bd/botoes/$bios_select"); ?>

									<?php include ("admin/bd/botoes/$bwin_select"); ?>

									<?php include ("admin/bd/botoes/$bblack_select"); ?>

					  			</div>

							</div>



				  		</div>

					</div>

			

					<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">

						<div class="audio-list">

						

							<div class="jp-playlist"> 

								<ul class="hidden playlist-files">

									<li data-title="<?php echo $nome_stream; ?>" data-artist="<iframe style='width:100%' src='admin/includes/locutor/no-ar-player.php' scrolling='no' height='48px' framespacing='0' frameborder='no' border='0px' noresize></iframe>" data-mp3="<?php if(empty($http_https) || $http_https == 'http'){if (empty($proxy_stream) || $proxy_stream == 'off') {echo "http://$ip_stream:$port_stream$stream_mount";}else{echo $proxy_url_stream;}}else{if (empty($proxy_stream) || $proxy_stream == 'off') {echo "https://cdn.radioscast.com.br/bs/proxy/stream.php?ip=$ip_stream&port=$port_stream&mount=$stream_mount";}else{echo $proxy_url_stream;}} ?>"></li>

								</ul>


					  			<h5 class="no-ar"><?php echo $lang_no_ar_agora; ?>:</h5>

								<div class="audio-track">

									<ul>

										<li></li>

									</ul>

								</div>

							</div>

						</div>

					</div>

				</div>

			</div>

		</div>

	</section>



	



	<script defer src="assets/js/jquery.mCustomScrollbar.concat.min.js?v=<?php echo $version; ?>"></script> 

	<script defer src="assets/jPlayer/jquery.jplayer.min.js?v=<?php echo $version; ?>"></script> 

	<script defer src="assets/jPlayer/add-on/jplayer.playlist.min.js?v=<?php echo $version; ?>"></script> 

	<script defer src="assets/js/main.js?v=<?php echo $version; ?>"></script>  

	<script src="admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>

	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>

	<script>

		window.dataLayer = window.dataLayer || [];

		function gtag(){dataLayer.push(arguments);}

		gtag('js', new Date());

		gtag('config', '<?php echo $analytics_id; ?>');

	</script>

	

</body>

</html>

