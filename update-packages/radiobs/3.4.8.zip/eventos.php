<?php include ("config.php");  ?>
<?php include("admin/includes/lang/$pulse_lang.php"); ?>
<?php include ("admin/bd/mural.php");  ?>
<?php include ("admin/bd/stream.php");  ?>
<?php include ("admin/bd/automacao.php");  ?>
<?php include ("admin/bd/top5.php");  ?>
<?php include ("admin/bd/anunciantes.php");  ?>
<?php include ("admin/bd/theme.php"); ?>
<?php $version = file_get_contents("version.txt"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title><?php echo $page_title; ?> - <?php echo $lang_menu_eventos; ?></title>
	<meta name="description" content="<?php echo $page_desc; ?>">
	<meta name="keywords" content="<?php echo $page_words; ?>" />
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<meta content="yes" name="apple-mobile-web-app-capable" />
	<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
	<link rel="icon" href="admin/assets/img/favicon.jpg">
	<link rel="shortcut icon" href="admin/assets/img/favicon.jpg" />
	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/jquery.vegas.css">
	<link rel="stylesheet" href="assets/css/<?php echo $theme; ?>?v=<?php echo $version; ?>">
	<link rel="stylesheet" type="text/css" href="assets/css/<?php echo $corsite; ?>.css?v=<?php echo $version; ?>">
	<script async  src="assets/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
	<script defer  src="assets/js/jquery.js"></script>
</head>
<body>

<?php include 'menu.php'; ?>

<div id="ajaxArea">
	<div class="pageContentArea">
		<section class="breadcrumb">
			 <div class="container">
				  <div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-6">
						  <h1><?php echo $menu_eventos; ?></h1>
						  <h5><?php echo $lang_sub_evento; ?></h5>
					  </div>
				  </div>
			 </div>
		</section>
		<div class="clearfix"></div>
	  
		<section id="updates">
			<div class="container">
				<div class="row">
					<div class="col-lg-9 col-md-9 col-sm-9">
						<?php include_once("admin/includes/eventos2.php"); ?>
					</div>
				  
				  
					<div class="col-lg-3 col-md-3 col-sm-3">
		   				<h1><?php echo $lang_aplicativos; ?></h1>
						<div class="banner-app">
							<?php include ("admin/bd/$apk_select"); ?>
							<?php include ("admin/bd/$ios_select"); ?>
						</div>
						<br/>

						<h1><?php echo $lang_locutor_ar; ?></h1>
						<?php include 'admin/includes/locutor/no-ar-home.php'; ?>
			
						<?php include 'admin/includes/pedido-page.php'; ?>

						<?php if ($top_5 == 1 || $top_5 == ""){ ?>
						<h1><?php echo $lang_Top5; ?></h1>
						<div class="recent-post">
							<div class="top5-back">
								<img src="admin/assets/img/artistas/artista1.png" alt="top1" class="top5">
								<audio id="music" preload="true"><source src="admin/assets/audios/top5/top1.mp3?<?php echo urlencode($cache_today); ?>"></audio>
								<div class="aligButton">
									<button id="pButton" class="play" onclick="play()"></button>
								</div>
								<h5><strong class="top5-numero">1.</strong> <?php echo $artista_top1; ?></h5>
								<p><?php echo $musica_top1; ?></p>
							</div>
						</div>

						<div class="recent-post">
							<div class="top5-back">
								<img src="admin/assets/img/artistas/artista2.png" alt="top2" class="top5">
								<audio id="music1" preload="true"><source src="admin/assets/audios/top5/top2.mp3?<?php echo urlencode($cache_today); ?>"></audio>
								<div class="aligButton">
									<button id="pButton1" class="play" onclick="play1()"></button>
								</div>
								<h5><strong class="top5-numero">2.</strong> <?php echo $artista_top2; ?></h5>
								<p><?php echo $musica_top2; ?></p>
							</div>
						</div>

						<div class="recent-post">
							<div class="top5-back">
								<img src="admin/assets/img/artistas/artista3.png" alt="top3" class="top5">
								<audio id="music2" preload="true"><source src="admin/assets/audios/top5/top3.mp3?<?php echo urlencode($cache_today); ?>"></audio>
								<div class="aligButton">
									<button id="pButton2" class="play" onclick="play2()"></button>
								</div>
								<h5><strong class="top5-numero">3.</strong> <?php echo $artista_top3; ?></h5>
								<p><?php echo $musica_top3; ?></p>
							</div>
						</div>

						<div class="recent-post">
							<div class="top5-back">
								<img src="admin/assets/img/artistas/artista4.png" alt="top4" class="top5">
								<audio id="music3" preload="true"><source src="admin/assets/audios/top5/top4.mp3?<?php echo urlencode($cache_today); ?>"></audio>
								<div class="aligButton">
									<button id="pButton3" class="play" onclick="play3()"></button>
								</div>
								<h5><strong class="top5-numero">4.</strong> <?php echo $artista_top4; ?></h5>
								<p><?php echo $musica_top4; ?></p>
							</div>
						</div>

						<div class="recent-post">
							<div class="top5-back">
								<img src="admin/assets/img/artistas/artista5.png" alt="top5" class="top5">
								<audio id="music4" preload="true"><source src="admin/assets/audios/top5/top5.mp3?<?php echo urlencode($cache_today); ?>"></audio>
								<div class="aligButton">
									<button id="pButton4" class="play" onclick="play4()"></button>
								</div>
								<h5><strong class="top5-numero">5.</strong> <?php echo $artista_top5; ?></h5>
								<p><?php echo $musica_top5; ?></p>
							</div>
						</div>
						<?php } ?>
			  
					</div>
				</div>
			</div>    
		</section>
	</div>
</div>

<?php include ("anuncios.php");  ?>

<?php include ("rodape.php");  ?>

	<script defer  src="assets/js/playtop5.js?v=<?php echo $version; ?>"></script>
	<script defer  src="assets/js/bootstrap.min.js?v=<?php echo $version; ?>"></script>
	<script defer  src="assets/js/jquery.carouFredSel-6.2.1-packed.js?v=<?php echo $version; ?>"></script> 
	<script defer  src="assets/js/jquery.vegas.min.js?v=<?php echo $version; ?>"></script> 
	<script defer  src="assets/js/main.js?v=<?php echo $version; ?>"></script>  
	<script src="admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', '<?php echo $analytics_id; ?>');
	</script>

</body>
</html>
