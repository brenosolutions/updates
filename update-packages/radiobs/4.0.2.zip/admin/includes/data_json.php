<?php

	header('Content-type: application/json');
	$files = glob('../data/img/uploads/*.*');
	$arr   = array();

	foreach ($files as $file) {	
	    $file = basename($file);
	    $arr[] = array("thumb" => "/admin/data/img/uploads/".$file, 'image'=> "/admin/data/img/uploads/".$file);
	}

	exit(str_replace('\/','/',json_encode($arr)));