<?php

	if (isset($_FILES['file'])) {
		copy($_FILES['file']['tmp_name'], '../data/files/'.$_FILES['file']['name']);
							
		$array = array(
		    'filelink' => '/admin/data/files/'.$_FILES['file']['name'],
		    'filename' => $_FILES['file']['name']
		);
		 
		echo stripslashes(json_encode($array));	
	}