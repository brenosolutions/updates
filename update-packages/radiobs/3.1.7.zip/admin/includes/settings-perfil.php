<div class="col-md-12">
<br/>
<h2>Perfil</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá cadastrar seu perfil.</h5>
<br/>
</div>
<div class="col-md-6">
<div class="panel panel-default">
                        <div class="panel-heading">
                            Alterar foto do perfil
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<?php
/* VERIFICO SE HOUVE O ENVIO DE UM ARQUIVO  */
if(count($_FILES) > 0) {
	
	/* RECUPERO TODAS AS INFORMAÇÕES POSSÍVEIS DO ARQUIVO */		
	$nome      = 'usuario.png';
	$tamanho   = $_FILES['arquivo']['size'];
	$tipo      = $_FILES['arquivo']['type'];
	$nome_temp = $_FILES['arquivo']['tmp_name'];	
	
	$erros = array();
	  

	/* VERIFICO SE O ARQUIVO ENVIADO É DO TIPO IMAGEM */
	if($tipo == 'image/jpeg' || $tipo == 'image/png' || $tipo == 'image/jpg' || $tipo == 'image/gif' || $tipo == 'image/bmp') {
		/* 
		VERIFICO SE O TAMANHO NÃO ULTRAPASSA 2Mb 
		O CALCULO DEVE SER REALIZADO EM BYTES.
		*/
		
		if($tamanho <= 10097152) {
			$pasta = './assets/img/';
			/* VERIFICO SE A PASTA NÃO EXISTE, SE ELA NÃO EXISTIR, EU CRIO A PASTA */
			if(!file_exists($pasta)) {
				mkdir($pasta, 0777);
			}
			
			/* 
			TENTO ENVIAR O ARQUIVO PARA A PASTA arquivos QUE ESTÁ LOCALIZADA NA RAIZ DO MEU PROJETO 
			*/
			
			if(move_uploaded_file($nome_temp, $pasta.$nome)) {
				/* SE ESTIVER TUDO OK, REDIRECIONO PARA UMA PÁGINA DE SUCESSO */
				$erros['logo'] = 'Logo alterado com sucesso!';
			} else {
				$erros['pasta'] = 'Ocorreu um erro ao enviar o arquivo para a pasta correta';	
			}
		} else {
			$erros['tamanho'] = 'Esse arquivo é maior que o permitido, o tamanho máximo permitido é de: <strong>10Mb</strong>';		
		}
	} else {
		$erros['tipo'] = 'Esse arquivo não é um arquivo suportado pelo sistema, os tipos suportados são: <strong>png, jpg, jpeg, gif e bmp</strong>';	
	}
	
}
?>

<form id="upload" method="post" enctype="multipart/form-data" >

			<img id="output" src="assets/img/usuario.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
			<br/>Tamanho recomendado: 215x215 pixels.

            <input type="file" id="arquivo" name="arquivo" accept="image/*" onchange="loadFile(event)" />
			<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>

<br/>
        	<button class="btn btn-default" type="submit" id="enviar" value="Enviar"><i class="fa fa-refresh"></i> Alterar</button>

</form>

<?php if(isset($erros)) { ?>
<div id="erros">
<?php foreach($erros as $e) { ?>

    	<p><?php echo $e; ?></p>

<?php	
}
?>
</div><!-- #erros -->
<?php } ?>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Informações básicas
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form role="form" action = "index.php?p=settings-perfil" method = "post">

<?php
include ("../perfil.php");


if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_perfil = '<?php
$perfil_nome = "'. $perfil_nome .'";
$perfil_mail = "'. $perfil_mail .'";
$perfil_sexo = "'. $perfil_sexo .'";
$perfil_cidade = "'. $perfil_cidade .'";
$perfil_estado = "'. $perfil_estado .'";
$perfil_nascimento_dia = "'. $perfil_nascimento_dia .'";
$perfil_nascimento_mes = "'. $perfil_nascimento_mes .'";
$perfil_nascimento_ano = "'. $perfil_nascimento_ano .'";
$pulse_pass = "'. $password .'";
?>';

            if ($fp = fopen("bd/perfil.php", "w")) {
                fwrite($fp, $config_perfil, strlen($config_perfil));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-perfil");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="perfil_nome" value="<?php echo $perfil_nome; ?>" />
	</div>

	<div class="form-group">
	    <label>E-mail</label>
	    <input class="form-control" type="email" name="perfil_mail" value="<?php echo $perfil_mail; ?>" />
	</div>

	<div class="form-group">
	   <label>Sexo</label>
	   <select class="form-control" name="perfil_sexo">

	   <?php
	   $perfil_sexo_options = array(
	      array(Masculino,'Masculino'),
	   		array(Feminino,'Feminino')
	   		);

	   foreach ($perfil_sexo_options as $perfil_sexo_option) {

		?><option value = "<?php echo $perfil_sexo_option[1]; ?>"<?php echo $perfil_sexo == $perfil_sexo_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($perfil_sexo_option[0]); ?></option><?php
			  } ?>
	   </select>
	</div>

	<div class="form-group">
	    <label>Cidade</label>
	    <input class="form-control" type="text" name="perfil_cidade" value="<?php echo $perfil_cidade; ?>" />
	</div>

	<div class="form-group">
	   <label>Estado</label>
	   <select class="form-control" name="perfil_estado">

	   <?php
	   $perfil_estado_options = array(
	        array(Acre,'AC'),
	        array(Alagoas,'AL'),
	        array(Amapá,'AP'),
	        array(Amazonas,'AM'),
	        array(Bahia,'BA'),
	        array(Ceará,'CE'),
	        array(Distrito Federal,'DF'),
	        array(Espírito Santo,'ES'),
	        array(Goiás,'GO'),
	        array(Maranhão,'MA'),
	        array(Mato Grosso,'MT'),
	        array(Mato Grosso do Sul,'MS'),
	        array(Minas Gerais,'MG'),
	        array(Pará,'PA'),
	        array(Paraíba,'PB'),
	        array(Paraná,'PR'),
	        array(Piauí,'PI'),
	        array(Rio de Janeiro,'RJ'),
	        array(Rio Grande do Norte	,'RN'),
	        array(Rio Grande do Sul,'RS'),
	        array(Rondônia,'RO'),
	        array(Roraima,'RR'),
	        array(Santa Catarina,'SC'),
	        array(São Paulo,'SP'),
	        array(Sergipe,'SE'),
	   		array(Tocantins,'TO')
	   		);

	   foreach ($perfil_estado_options as $perfil_estado_option) {

		?><option value = "<?php echo $perfil_estado_option[1]; ?>"<?php echo $perfil_estado == $perfil_estado_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($perfil_estado_option[0]); ?></option><?php
			  } ?>
	   </select>
	</div>

	<div class="form-group">
		<div class="form-group">
			<label>Data de nascimento</label>
			<br/>
			<input type="text" name="perfil_nascimento_dia" size="2" maxlength="2" value="<?php echo $perfil_nascimento_dia; ?>"> 
			<input type="text" name="perfil_nascimento_mes" size="2" maxlength="2" value="<?php echo $perfil_nascimento_mes; ?>"> 
			<input type="text" name="perfil_nascimento_ano" size="4" maxlength="4" value="<?php echo $perfil_nascimento_ano; ?>">
		</div>
	</div>

	<div class="form-group">
	   <label><?php echo $lang_setting_password; ?> painel</label>
	   <input class="form-control" type="password" name="password" value="<?php echo $pulse_pass; ?>"/>
   </div>

    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>