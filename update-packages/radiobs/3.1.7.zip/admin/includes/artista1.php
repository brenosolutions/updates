<div class="col-md-12">
<br/>
<h2>Artista 1</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá alterar a foto do Artista.</h5>
<br/>
</div>
<div class="col-md-6">
<a class="btn btn-primary" href="index.php?p=settings-top5"><i class="fa fa-chevron-circle-left"></i> Voltar</a>
<br/>
<br/>
<div class="panel panel-default">
                        <div class="panel-heading">
                            Alterar foto do Artista
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<?php
/* VERIFICO SE HOUVE O ENVIO DE UM ARQUIVO  */
if(count($_FILES) > 0) {
	
	/* RECUPERO TODAS AS INFORMAÇÕES POSSÍVEIS DO ARQUIVO */		
	$nome      = 'artista1.png';
	$tamanho   = $_FILES['arquivo']['size'];
	$tipo      = $_FILES['arquivo']['type'];
	$nome_temp = $_FILES['arquivo']['tmp_name'];	
	
	$erros = array();
	  

	/* VERIFICO SE O ARQUIVO ENVIADO É DO TIPO IMAGEM */
	if($tipo == 'image/jpeg' || $tipo == 'image/png' || $tipo == 'image/jpg' || $tipo == 'image/gif' || $tipo == 'image/bmp') {
		/* 
		VERIFICO SE O TAMANHO NÃO ULTRAPASSA 2Mb 
		O CALCULO DEVE SER REALIZADO EM BYTES.
		*/
		
		if($tamanho <= 10097152) {
			$pasta = './assets/img/artistas/';
			/* VERIFICO SE A PASTA NÃO EXISTE, SE ELA NÃO EXISTIR, EU CRIO A PASTA */
			if(!file_exists($pasta)) {
				mkdir($pasta, 0777);
			}
			
			/* 
			TENTO ENVIAR O ARQUIVO PARA A PASTA arquivos QUE ESTÁ LOCALIZADA NA RAIZ DO MEU PROJETO 
			*/
			
			if(move_uploaded_file($nome_temp, $pasta.$nome)) {
				/* SE ESTIVER TUDO OK, REDIRECIONO PARA UMA PÁGINA DE SUCESSO */
				$erros['logo'] = 'Logo alterado com sucesso!';
			} else {
				$erros['pasta'] = 'Ocorreu um erro ao enviar o arquivo para a pasta correta';	
			}
		} else {
			$erros['tamanho'] = 'Esse arquivo é maior que o permitido, o tamanho máximo permitido é de: <strong>10Mb</strong>';		
		}
	} else {
		$erros['tipo'] = 'Esse arquivo não é um arquivo suportado pelo sistema, os tipos suportados são: <strong>png, jpg, jpeg, gif e bmp</strong>';	
	}
	
}
?>

<form id="upload" method="post" enctype="multipart/form-data" >

			<img id="output" src="assets/img/artistas/artista1.png?img=<?php echo urlencode($cache_today); ?>" width="220" height="auto" />
			<br/>Tamanho recomendado: 220x130 pixels.

            <input type="file" id="arquivo" name="arquivo" accept="image/*" onchange="loadFile(event)" />
			<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>

<br/>
        	<button class="btn btn-default" type="submit" id="enviar" value="Enviar"><i class=" fa fa-refresh "></i> Alterar</button>

</form>

<?php if(isset($erros)) { ?>
<div id="erros">
<?php foreach($erros as $e) { ?>

    	<p><?php echo $e; ?></p>

<?php	
}
?>
</div><!-- #erros -->
<?php } ?>
</div>
</div>
</div>
</div>
