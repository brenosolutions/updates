<div class="col-md-12">
	<br/>
	<h2>Anúncios</h2>   
	<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá criar, editar e excluir anúncios.</h5>
	<br/>
	<div id="panel-body">
		<a href = "index.php?p=anuncios" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Novo Anúncio</a>
	</div>

	<!-- Advanced Tables -->


	<div class="table-responsive">
	<table class="table table-bordered table-striped text-center">
			<thead>
				<tr>
					<th class="text-center">ID</th>
					<th class="text-center">Nome</th>
					<th class="text-center">Banner</th>
					<th class="text-center">Website</th>
					<th class="text-center">Ações</th>
				</tr>
			</thead>
			<tbody>
				<?php
				require_once("login.php");

				$opFile = "data/anuncios/anunciosfile.txt";
				$fp     = fopen($opFile,"r") or die("$lang_blog_error_reading"); 

				while (!feof($fp)) {
					$posts[] = fgets($fp);
				}

				fclose($fp); 
				$no_of_posts = count($posts)-1;
				$records     = $no_of_posts;

				if ($records) {
					$result_per_page = 5 ;
					$total_pages     = ceil($records / $result_per_page);

					$cur_page = $_GET[page] ? $_GET[page] : 1; 

					$start = $records - (($cur_page-1) * $result_per_page);
					$end   = $records - (($cur_page) * $result_per_page);

					for ($n = $start-1; $n >= $end; $n--) { 
						$blog = explode("|", $posts[$n]);
						$date = explode( ' ' , $blog[2]);
						$date = $date[2] . ' ' . $date[1]  . ' ' . $date[3];

						if (isset($blog[0]) && $blog[0] != '') {
							$post_id = $n + 1;		 

							echo "<tr>
							<td>$blog[0]</td>
							<td>$blog[3]</td>
							<td><img src=\"assets/img/anunciantes/$blog[2]\" width=\"100\"></td>
							<td><a href=\"$blog[4]\" target=\"_blank\">$blog[4]</a></td>
							<td><a href=\"index.php?p=edit-anuncios&post_id=" . $blog[0] . "\" class=\"btn btn-info\" title=\"Editar\"><i class=\"fa fa-pencil\"></i></a>

								<a href=\"index.php?p=del-anuncios&post_id=" . $blog[0] . "&img=$blog[2]\" class=\"btn btn-excluir\" title=\"Excluir\"><i class=\"fa fa-trash-o\"></i></a></td>
							</tr>
							";

						} else {
							continue;   
						}
					}  

					echo "<div class=\"clear\">&nbsp;</div>\n";
					echo "<div class=\"blog-pagination\">";

					if ($cur_page < $total_pages) {
						echo '<a class="btn pagin" href=index.php?p=manage-anuncios&page=' . ($cur_page+1) . '>< Anúncios antigos</a>' . '&nbsp;&nbsp;&nbsp;';
					}

					if ($cur_page > 1) {	
						echo  '<a class="btn pagin" href=index.php?p=manage-anuncios&page=' . ($cur_page-1) . '>Anúncios recentes ></a>';
					}

					echo "&nbsp;</div>";

				} else {
					echo "<p>Nenhum Anúncio encontrado</p>";

				}
				?>
			</tbody>
		</table>


		<div class = "clear"></div>


	</div>                            </div>

