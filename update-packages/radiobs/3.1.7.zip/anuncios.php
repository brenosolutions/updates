      <section id="albums">

      	<div class="container">
      		<h1>Anunciantes</h1>


      		<div class="albums-carousel">


      			<div id="foo1">

      			<?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/includes/anuncios-home.php"); ?>

      			</div>
      		</div>

      	</div>
      </section>