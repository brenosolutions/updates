<?php 
	session_start();
	$count_file = "contador.txt";
	$handle = fopen($count_file, 'r+');
	$count_total = fread($handle, 512);
	if (empty($_SESSION['visita'])) {
		$_SESSION['visita'] = 1;
		$visita = $count_total + 1;
	}else{
		$visita = $count_total;
	}
	echo "<span class=\"fa fa-info-circle\"> $lang_visitas: $visita </span>   |   ";
	fseek($handle,0);
	fwrite($handle, $visita);
	fclose($handle);
	
?>

<?php

	$gmtDate = gmdate("D, d M Y H:i:s");
	header("Expires: {$gmtDate} GMT");
	header("Last-Modified: {$gmtDate} GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	$timeExpire = 300;
	$fileName = "online.txt";
	if(!file_exists($fileName)) {
		$f = fopen($fileName, "w");
		fclose($f);
	}

	$ip = $_SERVER['REMOTE_ADDR'];
	$tempo = time();
	$stringUser = $ip . ":" . $tempo;
	$onlineNow = file_get_contents($fileName);
	$arrayNow = explode("|", $onlineNow);
	$newUsers = array();

	foreach($arrayNow as $an) {
		list($tIP, $tTime) = explode(":", $an);
		if($tIP != NULL && $tTime != NULL && $tIP != $ip && $tTime > $tempo - $timeExpire) {
			$newUsers[] = $tIP . ":" . $tTime;
		}
	}

	$newUsers[] = $stringUser;
	file_put_contents($fileName, implode("|", $newUsers));
	$online = count($newUsers);
	echo "<span class=\"fa fa-info-circle\"> $lang_online: $online</span>";

?>