
<?php 
	
$on = 'images'; 
require_once("login.php");

?>

<div class="col-md-12">
<h2>Álbuns de Fotos</h2>   
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá gerenciar os álbuns de fotos.</h5>
<br/>
<div id="panel-body">
	<a class="btn btn-primary" href ="index.php?p=new-album">Criar Novo Álbum</a> 
</div>
<br/>

                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Lista de Álbuns
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

	          
<?php 

$dir    = 'data/img/albuns/';
$handle = opendir($dir);
$nb     = 1;
	
while ($filename = readdir($handle)) {
	
     if ($filename != ".." 
         && $filename != "." 
         && is_dir($dir.$filename)) {
		 
	     echo '<div class="tab gallery">';
		 echo '<a href="index.php?p=gerenciar-fotos&g='. $filename  .'">'.  preg_replace("/-/", " ", $filename) .'</a>';
		 echo '</div>';
	
		 $albuns[$nb] = $filename;
		 $nb++; 
	  }
}			
	
if ($nb == 1) {
	echo "Não há álbum criado ainda.";
}
	
$_SESSION["albuns"] = $albuns;

?>	
</div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>