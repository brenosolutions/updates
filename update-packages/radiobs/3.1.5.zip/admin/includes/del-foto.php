<?php 
	
$on='images'; 

require_once("login.php");

?>

<div class="col-md-12">
<br/>
<div id="panel-body">
    <a class="btn btn-primary" href="index.php?p=gerenciar-fotos&g=<?php if(!empty($_GET["g"])) echo htmlentities($_GET["g"]); ?>"><i class="fa fa-chevron-circle-left"></i> Voltar</a>     
</div>

<div id="">
	
<?php 	
	if(!empty($_GET["f"]) && is_numeric($_GET["f"]) && !empty($_GET["g"])){
		$id = $_GET["f"];
		
		$albuns = strtr($_GET["g"], "../","/");
			
		$upload_dir = "./data/img/albuns/". $albuns ."/";

		$opFile =  ROOTPATH . "/data/img/albuns/". $albuns ."/fotos.txt";
		if($fp = fopen($opFile,"r")) {
            $data = @fread($fp, filesize($opFile));
            fclose($fp);

            $line = explode("\n", $data);
            $no_of_posts = count($line)-1;

		    for ($i=0; $i<$no_of_posts; $i++) {
                $image = explode("|", $line[$i]);
                
                if($image[1] == $albuns && $id == $image[0]) {
                    $filename = $image[2];
                } 
                	else {
                    	$new_data .= $image[0] ."|". $image[1]."|". $image[2] ."|". $image[3] ."|". $image[4] ."\n";
                }
            }	
		}
		          
		if(isset($_SESSION["token"]) && isset($_SESSION["token_time"]) && isset($_POST["token"]) && $_SESSION["token"] == $_POST["token"]){
			$timestamp_old = time() - (15*60);
		
			if($_SESSION["token_time"] >= $timestamp_old){
				                         
                    $fp = @fopen($opFile,"w") or die($lang_blog_error_reading); 
                    $success = fwrite($fp, $new_data);
                    fclose($fp);
                    
                    if(is_file($upload_dir.$filename)) {
				        unlink($upload_dir.$filename);
				        
				        $host  = $_SERVER['HTTP_HOST'];
						$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
						header("Location: http://$host$uri/index.php?p=gerenciar-fotos&g=$albuns");
						die();

				    
				    } else {
				    
				        echo "<p class=\"errorMsg\">$lang_gal_cant_find_file</p>";
				    }    
				
			} else {
			
				echo "<p class=\"errorMsg created\">$lang_gal_session_expired</p>";
			}	
					
		} else {
		
			$token = md5(uniqid(rand(), TRUE));
			$_SESSION["token"] = $token;
			$_SESSION["token_time"] = time();
			
			echo "<p>$lang_gal_sure_delete_file<b>" . $filename . "</b>?</p><br>";
			echo "<form action=\"index.php?p=del-foto&f=". $id ."&g=". $albuns ."\" method=\"post\">";
			echo "<p><input type=\"hidden\" name=\"token\" value=\"$token\" />";
			echo "<button class=\"btn btn-success\" value=\"Yes\" type=\"submit\" class=\"btn\"><i class=\"fa fa-thumbs-up\"></i> $lang_yes</button>";
			echo "&nbsp;&nbsp;&nbsp;<a <a class=\"btn btn-default\" href=\"index.php?p=gerenciar-fotos&g=". $albuns ."\" class=\"btn\"><i class=\"fa fa-thumbs-down\"></i> $lang_cancel</a>";
			echo "</form>";
		
		}	
			
	} else {
	
		echo "<p class=\"errorMsg\">$lang_gal_cant_find_file</p>";
	}
			
?>
</div></div>