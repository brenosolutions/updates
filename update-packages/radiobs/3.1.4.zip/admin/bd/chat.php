<?php
$chat = "1";
$nome_chat = "Bate-Papo";
$admin_chat = "Admin";

?>