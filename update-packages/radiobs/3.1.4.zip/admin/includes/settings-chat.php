<?php

include '../chat/jaxconfig.php';
include '../chat/class/JaxChat.php';


$jc = new JaxChat;

// determine if this is an AJAX method call
if( !empty($_GET['method']) && isset($_GET['password']) && $_GET['password'] === ADMIN_PASSWORD ) {
    $error = '';
    $message = '';
    $json = array();

    // process action
    switch($_GET['method']) {
        case 'getUsernames':
      $names = $jc->getNamesList();
      if ($names === FALSE) {
        $error = 'Falha ao obter nomes!';
      }
      else {
        $json['users'] = array('names' => $names->names, 'ids' => $names->ids, 'times' => $names->times, 'ips' => $names->ips);
      }
            
            break;
            
            
        case 'getUserBans':
            $bans = $jc->getBansList();
            $json['bannedUsers'] = array();
            
            if ($bans && count($bans->names) > 0) {
                $json['bannedUsers']['names'] = $bans->names;
            }
            
            if ($bans && count($bans->ips) > 0) {
                $json['bannedUsers']['ips'] = $bans->ips;
            }
            
            break;
            
            
        case 'deleteUser':
            if( $jc->deleteName($_GET['id']) === FALSE ) {
                $error = 'ERRO: ' . $jc->getError();
            }
            
            break;
            
            
        case 'banName':
            if( $jc->banName($_GET['id']) === FALSE ) {
                $error = 'ERRO: ' . $jc->getError();
            }
            
            break;
            
            
        case 'banIP':
            if( $jc->banIPAddress($_GET['id']) === FALSE ) {
                $error = 'ERROR: ' . $jc->getError();
            }
            
            break;
            
        
        case 'removeNameBan':
            if ($jc->removeNameBan($_GET['name']) === FALSE) {
                $error = 'ERRO: ' . $jc->getError();
            }

            break;
            
            
        case 'removeIPBan':
            if ($jc->removeIPAddressBan($_GET['ip']) === FALSE) {
                $error = 'ERRO: ' . $jc->getError();
            }
            
            break;
            
            
        case 'getMessages':
            $messages = $jc->getMessages();
            if ($messages && count($messages->messages) > 0) {
                $json['messages'] = $messages->messages;
            }
            
            break;
            
            
        case 'deleteMessage':
            if( $jc->deleteMessage($_GET['id']) === FALSE ) {
                $error = 'ERRO: ' . $jc->getError();
            }
            
            break;
            
            
        case 'sendMessage':
            $jc->writeMessage('','<img class="chat" src="../chat/images/dono.gif"/> <span style="color:#000;"><b>' . $admin_chat . ': </b></span>' . $_GET['message'], 'systemmessage');
            
            break;
        
        
        // ajax request unknown
        default:
            $error = 'Comando desconhecido! (' . $_GET['method'] . ')';
            break;
    }
    
    // make sure json is not cached
    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past

    $json['error'] = $error;
    $json['message'] = $message;
    echo json_encode($json);

    // finished when doing AJAX
    exit;
}
?>

<div class="col-md-12">

<br/>
<h2>Chat</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá configurar e gerenciar o chat.</h5>
<br/>
</div>

<script src="../chat/js/jquery.min.js"></script>
<script>

$(document).ready(function() {
    $(".tabs-menu a").click(function(event) {
        event.preventDefault();
        $(this).parent().addClass("current");
        $(this).parent().siblings().removeClass("current");
        var tab = $(this).attr("href");
        $(".tab-content").not(tab).css("display", "none");
        $(tab).fadeIn();
    });
    
    getUsernames();
    getUserBans();
    getMessageHistory();
});


function getUsernames() {
    ajaxMethod('getUsernames', {}, function(data) {
        if( data.error ) {
            showError(data.error);
        }
        
        var tableHTML = '<button onclick="getUsernames();" class="btn btn-primary"><i class="fa fa-refresh"></i> Atualizar</button><br>';
        
        if( data.users.names && data.users.names.length > 0 ) {
            tableHTML += '<br/><table class="table table-striped">';
            
            for( var ni = 0; ni < data.users.names.length; ni++ ) {
                joinTime = new Date(data.users.times[ni] * 1000);
                
                tableHTML += '<tr><td>' + data.users.names[ni] + '</td>' + 
                        '<td>' + joinTime.toLocaleString() + '</td>' +
                        '<td>' + data.users.ips[ni] + '</td>' +
                        '<td>' +
                        '<button onclick="deleteUser(\'' + data.users.ids[ni] + '\');" class="btn btn-info"><i class="fa fa-times" aria-hidden="true"></i> Kick</button>&nbsp;&nbsp;' + 
                        '<button onclick="banIP(\'' + data.users.ids[ni] + '\');"  class="btn btn-excluir"><i class="fa fa-ban" aria-hidden="true"></i> Ban IP</button>' + 
                        '</td></tr>';
            }
            
            tableHTML += '</table>';
        }
        else {
            tableHTML += 'Nenhum usuário.';
        }
        
        $('#usernames').html(tableHTML);
    });
}


function getUserBans() {
    ajaxMethod('getUserBans', {}, function(data) {
        if( data.error ) {
            showError(data.error);
        }
        
        var tableHTML = '<button onclick="getUserBans();" class="btn btn-primary"><i class="fa fa-refresh"></i> Atualizar</button><br>';
        
        if( data.bannedUsers.names && data.bannedUsers.names.length > 0 ) {
            tableHTML += '<br/><table class="table table-striped">';
            
            for( var ni = 0; ni < data.bannedUsers.names.length; ni++ ) {
                tableHTML += '<tr><td>' + data.bannedUsers.names[ni] + '</td>' + 
                        '<td>' +
                        '<button onclick="removeNameBan(\'' + data.bannedUsers.names[ni] + '\');" class="btn btn-excluir"><i class="fa fa-minus-circle" aria-hidden="true"></i> Remover Ban</button>' + 
                        '</td></tr>';
            }
            
            tableHTML += '</table>';
        }
        else {
            tableHTML += 'Nenhum banido.';
        }
        
        $('#namebans').html(tableHTML);
        
        
        tableHTML = '<button onclick="getUserBans();" class="btn btn-primary"><i class="fa fa-refresh"></i> Atualizar</button><br>';
        
        if( data.bannedUsers.ips && data.bannedUsers.ips.length > 0 ) {
            tableHTML += '<br/><table class="table table-striped">';
            
            for( var ni = 0; ni < data.bannedUsers.ips.length; ni++ ) {
                tableHTML += '<tr><td>' + data.bannedUsers.ips[ni] + '</td>' + 
                        '<td>' +
                        '<button onclick="removeIPBan(\'' + data.bannedUsers.ips[ni] + '\');" class="btn btn-excluir"><i class="fa fa-minus-circle" aria-hidden="true"></i> Remover Ban</button>' + 
                        '</td></tr>';
            }
            
            tableHTML += '</table>';
        }
        else {
            tableHTML += 'Nenhum banido.';
        }
        
        $('#ipbans').html(tableHTML);
    });
}


function getMessageHistory() {
    ajaxMethod('getMessages', {}, function(data) {
        if( data.error ) {
            showError(data.error);
        }
        
        var tableHTML = '<button onclick="getMessageHistory();" class="btn btn-primary"><i class="fa fa-refresh"></i> Atualizar</button><br>';
        
        if( data.messages && data.messages.length > 0) {
            tableHTML += '<br/><table class="table table-striped">';
            
            for( var ni = 0; ni < data.messages.length; ni++ ) {
                messageTime = new Date(data.messages[ni].time * 1000);
                
                tableHTML += '<tr><td>' + messageTime.toLocaleString() + '</td>' +
                        '<td>' + data.messages[ni].message + '</td>' +
                        '<td>' +
                        '<button onclick="deleteMessage(\'' + data.messages[ni].id + '\');" class="btn btn-excluir" ><i class="fa fa-trash"></i> Deletar</button>' + 
                        '</td></tr>';
            }
            
            tableHTML += '</table>';
        }
        else {
            tableHTML += 'Nenhum Mensagem.<br/>';
        }
        
        tableHTML += '<br/><div class="form-group"><label>Mensagem do Admin </label>' +
            '<input class="form-control" id="system_message" name="system_message" type="text" size="40" />' +
            '<br/><button class="btn btn-success" onclick="sendMessage();"><i class="fa fa-share-square-o" aria-hidden="true"></i> Enviar</button></div>';
    
        $('#messagehistory').html(tableHTML);
    });
}


function deleteMessage(id) {
    ajaxMethod('deleteMessage', {'id': id}, function(data) {
        if( data.error ) {
            showError(data.error);
        }

        getMessageHistory();
    });
}


function sendMessage() {
    ajaxMethod('sendMessage', {'message': $('#system_message').val()}, function(data) {
        if( data.error ) {
            showError(data.error);
        }

        $('#system_message').val('');
        getMessageHistory();
    });
}


function removeNameBan(bannedName) {
    ajaxMethod('removeNameBan', {'name': bannedName}, function(data) {
        if( data.error ) {
            showError(data.error);
        }

        getUserBans();
    });
}


function removeIPBan(bannedIP) {
    ajaxMethod('removeIPBan', {'ip': bannedIP}, function(data) {
        if( data.error ) {
            showError(data.error);
        }

        getUserBans();
    });
}


function deleteUser(id) {
    ajaxMethod('deleteUser', {'id': id}, function(data) {
        if( data.error ) {
            showError(data.error);
        }

        getUsernames();
    });
}


function banName(id) {
    ajaxMethod('banName', {'id': id}, function(data) {
        if( data.error ) {
            showError(data.error);
        }

        getUsernames();
        getUserBans();
    });
}


function banIP(id) {
    ajaxMethod('banIP', {'id': id}, function(data) {
        if( data.error ) {
            showError(data.error);
        }

        getUsernames();
        getUserBans();
    });
}


function ajaxMethod(method, data, callback) {
    var adminPassword = "admin";
    
  $.extend(data, {'password': adminPassword, 'method': method});
  
  $.ajax({
    url: 'index.php?p=settings-chat',
    data: data,
    dataType: "json",
    success: function (data, status) {
      if( callback ) {
        callback(data);
      }
    },
    error: function (data, status, e) {
            showError(e + ' (' + data.status + ')');
    }
  });
}

function showError(error) {
    $('#errors').append(error + '<br>');
}
</script>

<style>
#errors {
    color: red;
    font-weight: bold;
}
</style>


<div class="col-md-12">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Configurações do Chat
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
<form role="form" action = "index.php?p=settings-chat" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_chat = '<?php
$chat = "'. $chat .'";
$nome_chat = "'. $nome_chat .'";
$admin_chat = "'. $admin_chat .'";

?>';

            if ($fp = fopen("bd/chat.php", "w")) {
                fwrite($fp, $config_chat, strlen($config_chat));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-chat");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>

  </div>
    <div class="form-group">
     <label>Nome do Admin</label>
     <input class="form-control" type="text" name="admin_chat" value="<?php echo $admin_chat; ?>"/>
  </div>
  
  <div class="form-group">
     <label>Ativar / Desativar</label>
     <select class="form-control" name="chat">

     <?php
     $chat_options = array(
        array(Ativar Chat,'1'),
        array(Desativar Chat,'0')
        );

     foreach ($chat_options as $chat_option) {

    ?><option value = "<?php echo $chat_option[1]; ?>"<?php echo $chat == $chat_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($chat_option[0]); ?></option><?php
        } ?>
     </select>
  </div>

  <div class="form-group">
     <label>Box Nome</label>
     <input class="form-control" type="text" name="nome_chat" value="<?php echo $nome_chat; ?>"/
  </div>
<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <br/>
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
  </div>
    </form>


<?php } ?>
</div>
</div>
</div>
</div>

<div id="errors"></div>
<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Usuários Online
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        <div id="usernames">
        </div>
</div>
</div>
</div>
</div>


<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            IP Banidos
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
        
        <div id="ipbans">
        </div>
</div>
</div>
</div>
</div>

<div class="col-md-12">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Mensagens
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        <div id="messagehistory">
        </div>

</div>
</div>
</div>
</div>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-63118517-1', 'auto');
  ga('send', 'pageview');
</script>
