<?php if ($top_5 == 1 || $top_5 == 2){ ?>
	<?php if($top_5 == 1){ ?>
      <h1><?php echo $lang_Top5; ?></h1>
    <?php }elseif($top_5 == 2){ ?>
      <h1><?php echo $lang_Top10; ?></h1>
    <?php } ?>


   <audio id="music_top"></audio>
   <div id="top_muisc_youtube"></div>

	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top1)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top1; ?>/mqdefault.jpg" alt="top1" class="top5">
			<?php }else{ ?>
				<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista1.png')) {echo "admin/assets/img/artistas/artista1.png";}else{echo "assets/img/music.gif";} ?>" alt="top1" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top1)) {echo $link_youtube_top1;}else{if(file_exists("admin/assets/audios/top5/top1.mp3")) {echo "admin/assets/audios/top5/top1.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>" ></button>
			</div>
			
			<h5><strong class="top5-numero">1.</strong> <?php echo $musica_top1; ?></h5>
			<p><?php echo $artista_top1; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top2)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top2; ?>/mqdefault.jpg" alt="top2" class="top5">
			<?php }else{ ?>
				<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista2.png')) {echo "admin/assets/img/artistas/artista2.png";}else{echo "assets/img/music.gif";} ?>" alt="top2" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top2)) {echo $link_youtube_top2;}else{if(file_exists("admin/assets/audios/top5/top2.mp3")) {echo "admin/assets/audios/top5/top2.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">2.</strong> <?php echo $musica_top2; ?></h5>
			<p><?php echo $artista_top2; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top3)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top3; ?>/mqdefault.jpg" alt="top3" class="top5">
			<?php }else{ ?>
			<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista3.png')) {echo  "admin/assets/img/artistas/artista3.png";}else{echo "assets/img/music.gif";} ?>" alt="top3" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top3)) {echo $link_youtube_top3;}else{if(file_exists("admin/assets/audios/top5/top3.mp3")) {echo "admin/assets/audios/top5/top3.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">3.</strong> <?php echo $musica_top3; ?></h5>
			<p><?php echo $artista_top3; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top4)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top4; ?>/mqdefault.jpg" alt="top4" class="top5">
			<?php }else{ ?>
			<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista4.png')) {echo  "admin/assets/img/artistas/artista4.png";}else{echo "assets/img/music.gif";} ?>" alt="top4" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top4)) {echo $link_youtube_top4;}else{if(file_exists("admin/assets/audios/top5/top4.mp3")) {echo "admin/assets/audios/top5/top4.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">4.</strong> <?php echo $musica_top4; ?></h5>
			<p><?php echo $artista_top4; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top5)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top5; ?>/mqdefault.jpg" alt="top5" class="top5">
			<?php }else{ ?>
			<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista5.png')) {echo  "admin/assets/img/artistas/artista5.png";}else{echo "assets/img/music.gif";} ?>" alt="top5" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top5)) {echo $link_youtube_top5;}else{if(file_exists("admin/assets/audios/top5/top5.mp3")) {echo "admin/assets/audios/top5/top5.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">5.</strong> <?php echo $musica_top5; ?></h5>
			<p><?php echo $artista_top5; ?></p>
		</div>
	</div>

	<?php if($top_5 == 2){ ?>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top6)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top6; ?>/mqdefault.jpg" alt="top6" class="top5">
			<?php }else{ ?>
				<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista6.png')) {echo "admin/assets/img/artistas/artista6.png";}else{echo "assets/img/music.gif";} ?>" alt="top6" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top6)) {echo $link_youtube_top6;}else{if(file_exists("admin/assets/audios/top5/top6.mp3")) {echo "admin/assets/audios/top5/top6.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">6.</strong> <?php echo $musica_top6; ?></h5>
			<p><?php echo $artista_top6; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top7)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top7; ?>/mqdefault.jpg" alt="top7" class="top5">
			<?php }else{ ?>
			<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista7.png')) {echo  "admin/assets/img/artistas/artista7.png";}else{echo "assets/img/music.gif";} ?>" alt="top7" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top7)) {echo $link_youtube_top7;}else{if(file_exists("admin/assets/audios/top5/top7.mp3")) {echo "admin/assets/audios/top5/top7.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">7.</strong> <?php echo $musica_top7; ?></h5>
			<p><?php echo $artista_top7; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top8)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top8; ?>/mqdefault.jpg" alt="top8" class="top5">
			<?php }else{ ?>
			<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista8.png')) {echo  "admin/assets/img/artistas/artista8.png";}else{echo "assets/img/music.gif";} ?>" alt="top8" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top8)) {echo $link_youtube_top8;}else{if(file_exists("admin/assets/audios/top5/top8.mp3")) {echo "admin/assets/audios/top5/top8.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">8.</strong> <?php echo $musica_top8; ?></h5>
			<p><?php echo $artista_top8; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top9)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top9; ?>/mqdefault.jpg" alt="top9" class="top5">
			<?php }else{ ?>
			<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista9.png')) {echo  "admin/assets/img/artistas/artista9.png";}else{echo "assets/img/music.gif";} ?>" alt="top9" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top9)) {echo $link_youtube_top9;}else{if(file_exists("admin/assets/audios/top5/top9.mp3")) {echo "admin/assets/audios/top5/top9.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">9.</strong> <?php echo $musica_top9; ?></h5>
			<p><?php echo $artista_top9; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<?php if (!empty($link_youtube_top10)) { ?>
				<img loading="lazy" src="https://img.youtube.com/vi/<?php echo $link_youtube_top10; ?>/mqdefault.jpg" alt="top10" class="top5">
			<?php }else{ ?>
			<img loading="lazy" src="<?php if (file_exists('admin/assets/img/artistas/artista10.png')) {echo "admin/assets/img/artistas/artista10.png";}else{echo "assets/img/music.gif";} ?>" alt="top10" class="top5">
			<?php } ?>
			<div class="aligButton">
				<button id="pButton" class="play" audiotop="<?php if (!empty($link_youtube_top10)) {echo $link_youtube_top10;}else{if(file_exists("admin/assets/audios/top5/top10.mp3")) {echo "admin/assets/audios/top5/top10.mp3?".urlencode($cache_today);}else{echo "assets/audio.mp3";}}?>"></button>
			</div>
			<h5><strong class="top5-numero">10.</strong> <?php echo $musica_top10; ?></h5>
			<p><?php echo $artista_top10; ?></p>
		</div>
	</div>
	<br>
	<?php } ?>
<?php } ?>