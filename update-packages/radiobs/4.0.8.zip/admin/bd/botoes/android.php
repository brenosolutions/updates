<a class="no-ajaxy" href="<?php echo $bapk_url; ?>" target="_blank"><img loading="lazy" class="celularimg" src="assets/img/android.png" alt="Android"></a>
