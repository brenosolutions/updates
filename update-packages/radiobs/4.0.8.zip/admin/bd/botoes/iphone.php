<a class="no-ajaxy" href="<?php echo $bios_url; ?>" target="_blank"><img loading="lazy" class="celularimg"  src="assets/img/ios.png" alt="Iphone"></a>
