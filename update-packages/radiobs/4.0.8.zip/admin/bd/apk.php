<center>
	<a class="no-ajaxy" href="<?php echo $apk_url; ?>" target="_blank"><img loading="lazy" src="assets/img/apk.png" alt="App Android"></a>
</center> 