

<?php

error_reporting(0);

include_once("path.php");

include_once(ROOTPATH."../../config.php");

include_once("lang/$pulse_lang.php");

include_once("helpers/functions.php");

include_once("helpers/videos_lib.php");



// Get Conteudo

$get_videos = new show_Videos;

?>



<?php

echo "<div class='blog-wrap'> \n";

if ($get_videos->val_videos($_GET["d"]) == true) {	



} else{ 



// Show all posts

foreach ($get_videos->get_blog_videos(4, $lang_blog_more) as $videos) {

	echo "<div class='col-lg-6 col-md-6 col-sm-6'>";

	echo "<div class=''>";

	echo "<div class=''>";

    

	echo "<div class='embed-container'><iframe src=\"https://www.youtube.com/embed/$videos[4]\" frameborder=\"0\" allowfullscreen></iframe></div><br/>\n";

	echo "<h5>".date($order, strtotime($videos[2]))."</h5>";

		     

	echo "</div></div></div>\n";

}



// Pagination





echo '</div>';

echo '<br><div class="news-feed-btn">';

$nums = $get_videos->amount_pages_videos(4);

if ($nums[1] < $nums[0]) { echo "<a href=\"videos-page-".($nums[1]+1)."\">Vídeos Antigos ></a>"; }

if ($nums[1] > 1) { echo  "<a href=\"videos-page-".($nums[1]-1)."\">< Vídeos Recentes</a>"; }

echo '</div>';

}

// Fim



?>

