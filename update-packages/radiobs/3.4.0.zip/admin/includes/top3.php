<?php 
    // get image info
    $menu_image = $_FILES['to1_mp3']['name'];
    $image_error = $_FILES['to1_mp3']['error'];
    $image_type = $_FILES['to1_mp3']['type'];

    // common image file extensions
    $allowedExts = array("mp3");

    // get image file extension
    error_reporting(E_ERROR | E_PARSE);
    $extension = end(explode(".", $_FILES["to1_mp3"]["name"]));

    if($image_error > 0){
        $error['to1_mp3'] = "<span class='label label-danger'>Você não inseriu a imagens!</span>";
    }else if(!(($image_type == "audio/mp3") ||  
        ($image_type == "audio/mpeg")) &&
        !(in_array($extension, $allowedExts))){
        $error['to1_mp3'] = " <span class='label label-danger'>Imagem no formato jpg, jpeg, gif, ou png!</span>";
    }

    if(isset($menu_image)){
        // create random image file name
        $file = preg_replace("/\s+/", "_", $_FILES['to1_mp3']['name']);

        $delete = unlink('assets/audios/top5/top3.mp3');

        // upload new image
        $upload = move_uploaded_file($_FILES['to1_mp3']['tmp_name'], 'assets/audios/top5/top3.mp3');

    }

 ?>


<div class="col-md-12">
	<br/>
	<h2>Top 3 - Upload Música</h2>
	<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá alterar a música do Top 3.</h5>
	<br/>
</div>
<div class="col-md-6">
	<a class="btn btn-primary" href="index.php?p=settings-top5"><i class="fa fa-chevron-circle-left"></i> Voltar</a>
	<br/>
	<br/>
	<div class="panel panel-default">
		<div class="panel-heading">
			Música Top 3
		</div>
		<div class="panel-body">
			<div class="table-responsive">


				<form id="upload" method="post" enctype="multipart/form-data" >
					<audio id="output" controls>
						<source  src="assets/audios/top5/top3.mp3?<?php echo urlencode($cache_today); ?>" type="audio/mp3">
						Seu nevegador não suporta o elemento audio.
					</audio>
										
					<input type="file" name="to1_mp3" value="" accept="audio/mp3" class="default" onchange="loadFile(event)">

					<script>
						var loadFile = function(event) {
							var output = document.getElementById('output');
							output.src = URL.createObjectURL(event.target.files[0]);
						};
					</script>

					<br>
					<button class="btn btn-default" type="submit" id="enviar" value="Enviar"><i class=" fa fa-refresh "></i> Alterar Música</button>

				</form>


			</div>

		</div>
	</div>
</div>

