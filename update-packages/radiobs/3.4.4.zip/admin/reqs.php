<?php

function my_ini_get($name) {        
	$setting = (ini_get($name));        
	$setting = ($setting==1 || $setting=='On') ? 'On' : 'Off';
	return $setting;
	}

?>

<html>
<head>
<style type="text/css">

body {
	font-size: 12px;
	font-family: sans-serif;
}

.label {
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	clear: left;
	float: left;
	width: 125px;
	background-color: #ddd;
}

.label-top {
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	clear: left;
	float: left;
	width: 125px;
	background-color: #999999;
}

.value {
	float: left;
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	background-color: #6699cc;
	width: 125px;
}

.value-top {
	float: left;
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	padding: 9px;
	background-color: #496e92;
	width: 125px;
}

.req {
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	background-color: #ddd;
	padding: 9px;
	float: left;
	width: 300px;
}

.req-top {
	color: white;
	margin-left: 0px;
	margin-bottom: 1px;
	margin-right: 1px;
	margin-top: 0px;
	background-color: #999999;
	padding: 9px;
	float: left;
	width: 300px;
}

</style>

<title>Requerimento</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body>

<h1>Requisitos do servidor</h1>

<p class="label-top">Especificação</p> 
<p class="value-top">Seu Servidor</p> <p class="req-top">Exigência</p><br>

<p class="label">Tipo de servidor:</p> 
<p class="value"><?php print $_SERVER['SERVER_SOFTWARE']; ?> </p>   <p class="req">Apache</p>  <br>    
         
<p class="label">PHP Versão:</p> 
<p class="value"><?php print phpversion()?></p><p class="req">PHP 5.6 a 7.0</p> <br>
                         
<p class="label">File Uploads:</p> 
<p class="value"><?php print my_ini_get('file_uploads'); ?></p> <p class="req">Ativado(On)</p><br>
                               
<p class="label">Safe Mode</p> 
<p class="value"><?php print my_ini_get('safe_mode'); ?></p>  <p class="req">Desativado(Off)</p><br>

<p class="label">Magic Quotes:</p> 
<p class="value"><?php if(get_magic_quotes_gpc()) echo "On"; else echo "Off"; ?></p>  <p class="req">Desativado(Off)</p><br>

<p class="label">GD Suporte:</p>

<?php 
if(!function_exists("gd_info")) 
print "<p class=\"value\">Off</p>"; 
else
if(function_exists("gd_info")) print "<p class=\"value\">On</p>"; 
?>

<p class="req">Ativado(On)</p>



<p class="label">IonCube Loader:</p>

<?php
	if(extension_loaded("IonCube Loader")) {
		echo "<p class=\"value\">On</p>";
	}
	else {
		echo "<p class=\"value\">Off</p>";
	}
?>

<p class="req">Ativado(On)</p>

<p class="label">IonCube Version:</p>

<?php echo "<p class=\"value\">".ioncube_loader_version()."</p>"; ?>

<p class="req">Versão 10.2 ou superior</p>

<p class="label">Allow url fopen:</p>
<?php 
	if( ini_get('allow_url_fopen') ) {
  		 echo "<p class=\"value\">On</p>";
	}else{
		echo "<p class=\"value\">Off</p>";
	}  
?>

<p class="req">Ativado(On)</p>


<br>
      
</body>
</html>