﻿<!-- /. NAV Dashboard  -->
                    <li>
                        <a <?php active('dashboard', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=dashboard"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <!-- /. NAV páginas  -->
                    <li <?php active('manage-blocks', '', 'active'); active('manage-photo&g=Equipe', '', 'active');?>>
                        <a  href="#"><i class="fa fa-file-text fa-3x"></i> Páginas<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a <?php active('manage-blocks', '', 'active-menu'); ?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-blocks"><i class="fa fa-pencil-square-o"></i>Sobre</a>
                            </li>
                            

                        </ul>
                      </li>

                    <!-- /. NAV Blog  -->
                    <li <?php active('manage-photo&g=Slider', '', 'active'); active('manage-anuncios', '', 'active');active('manage-videos', '', 'active');active('gerenciar-albuns', '', 'active');active('manage-news', '', 'active');active('manage-eventos', '', 'active');active('manage-pages', '', 'active'); active('manage-equipe', '', 'active');?>>
                        <a href="#"><i class="fa fa-newspaper-o fa-3x"></i> Publicidade<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a <?php active('manage-photo&g=Slider', '', 'active-menu');?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-photo&g=Slider"><i class="fa fa-file-image-o"></i>Gerenciar Slider</a>
                            </li>
                            <li>
                                <a <?php active('manage-anuncios', '', 'active-menu');?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-anuncios"><i class="fa fa-bullhorn"></i>Gerenciar Anúncios</a>
                            </li>

                            <li>
                                <a <?php active('manage-equipe', '', 'active-menu'); ?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-equipe"><i class="fa fa-group"></i>Gerenciar Equipe</a>
                            </li>
  
                            <li>
                                <a <?php active('manage-videos', '', 'active-menu');?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-videos"><i class="fa fa-film"></i></i>Gerenciar Vídeos</a>
                            </li>
                            <li>
                                <a <?php active('gerenciar-albuns', '', 'active-menu');?> href="http://<?php echo $o; ?>/admin/index.php?p=gerenciar-albuns"><i class="fa fa-camera"></i></i>Gerenciar Fotos</a>
                            </li>
                            <li>
                                <a <?php active('manage-news', '', 'active-menu');?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-news"><i class="fa fa-file-text-o"></i></i>Gerenciar Notícias</a>
                            </li>
                            <li>
                                <a <?php active('manage-eventos', '', 'active-menu');?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-eventos"><i class="fa fa-calendar"></i></i>Gerenciar Eventos</a>
                            </li>
                            <li>
                                <a <?php active('manage-pages', '', 'active-menu');?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-pages"><i class="fa fa-star-o"></i></i>Gerenciar Widgets</a>
                            </li>

                        </ul>
                      </li>

                    <li>
                        <a <?php active('pedidos', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=pedidos"><i class="fa fa-envelope-o fa-3x"></i> Pedidos</a>
                    </li>

                    <li>
                        <a <?php active('settings-chat', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-chat"><i class="fa fa-commenting-o fa-3x"></i> Chat</a>
                    </li>

          
                    <li <?php active('manage-locutores', '', 'active');active('manage-programacao', '', 'active');active('settings-locutores', '', 'active'); ?>>
                    	<a href="#"><i class="fa fa-history fa-3x"></i> Automação<span class="fa arrow"></span></a>

                    	<ul class="nav nav-second-level">
                    		<li>
                                <a <?php active('manage-locutores', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-locutores"><i class="fa fa-headphones"></i>Gerenciar Locutores</a>
                            </li>
                            <li>
                                <a <?php active('manage-programacao', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=manage-programacao"><i class="fa fa-calendar"></i>Programação</a>
                            </li>
                            <li>
                                <a <?php active('settings-locutores', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-locutores"><i class="fa fa-cog"></i>Configurações</a>
                            </li>
                            <li>
                        </ul>

                    </li>

                    <!-- /. NAV Configurações  -->
                    <li <?php active('settings', '', 'active');active('settings-theme', '', 'active');active('settings-perfil', '', 'active');active('settings-player', '', 'active');active('settings-stream', '', 'active');active('settings-tv', '', 'active');active('settings-top5', '', 'active');active('settings-enquete', '', 'active');active('settings-mural', '', 'active');active('settings-ouvinte', '', 'active');active('settings-doacao', '', 'active'); ?>>
                        <a href="#"><i class="fa fa-wrench fa-3x"></i> Configurações<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a <?php active('settings', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings"><i class="fa fa-cog"></i>Site</a>
                            </li>
                            <li>
                                <a <?php active('settings-theme', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-theme"><i class="fa fa-desktop"></i>Tema</a>
                            </li>
                            <li>
                                <a <?php active('settings-perfil', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-perfil"><i class="fa fa-user"></i>Perfil</a>
                            </li>
                            <li>
                                <a <?php active('settings-player', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-player"><i class="fa fa-play-circle"></i>Player</a>
                            </li>

                            <li>
                                <a <?php active('settings-stream', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-stream"><i class="fa fa-volume-up"></i>Streaming</a>
                            </li>
                            <li>
                                <a <?php active('settings-tv', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-tv"><i class="fa fa-video-camera"></i>Câmera Estúdio</a>
                            </li>
                            <li>
                                <a <?php active('settings-top5', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-top5"><i class="fa fa-music"></i>Top 5</a>
                            </li>
                            <li>
                                <a <?php active('settings-enquete', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-enquete"><i class="fa fa-check-circle"></i>Enquete</a>
                            </li>
                            <li>
                                <a <?php active('settings-mural', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-mural"><i class="fa fa-comments-o"></i>Mural de Recados</a>
                            </li>
                             <li>
                                <a <?php active('settings-ouvinte', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-ouvinte"><i class="fa fa-star"></i>Ouvinte do Mês</a>
                            </li>
                            <li>
                                <a <?php active('settings-doacao', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=settings-doacao"><i class="fa fa-money"></i>Doação</a>
                            </li>


                        </ul>
                      </li>
 
                      <!-- /. NAV Ajuda  -->
                    <li <?php active('sobre', '', 'active'); active('key-info', '', 'active');?>>
                        <a href="#"><i class="fa fa-info-circle fa-3x"></i> Ajuda<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/includes/update.php"><i class="fa fa-refresh"></i>Atualizações</a>
                            </li>
                            <li>
                                <a <?php active('key-info', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=key-info"><i class="fa fa-key"></i>Informações da Licença</a>
                            </li>
                            <li>
                                <a <?php active('sobre', '', 'active-menu');  ?> href="http://<?php echo $o; ?>/admin/index.php?p=sobre"><i class="fa fa-question-circle"></i>Sobre o Software</a>
                            </li>
                        </ul>
                      </li>