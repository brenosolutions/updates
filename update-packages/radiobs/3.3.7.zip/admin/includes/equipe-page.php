<?php

	error_reporting(0);
	include_once("path.php");
	include_once(ROOTPATH."../../config.php");
	include_once("helpers/functions.php");
	include_once("helpers/equipe_lib.php");

	$get_equipe = new show_Equipe; 
?>
<style type="text/css">
	.equipe-img{
		height: 200px;
		width: 200px;
		border-radius: 15px;
		padding-bottom: 5px;
		
	}

	.equipe-content {
	    border-width: 1px;
	    border-style: solid;
	    overflow: hidden;
	    background: rgba(255, 255, 255, 0.4);;
	    padding: 10px;
	    border-radius: 3px;
	    border-color: rgba(0,0,0,0.2) !important;
	}
	.equipe-info{
		text-align: center;

	}
	.equipe-text{
		text-overflow: ellipsis;
    	white-space: nowrap;
    	overflow: hidden;
    	 font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    	 line-height: 0.8;
	}
	.equipe{
		padding: 5px;
	}
	.fix-equipe{
		padding-left: 0px;
    	padding-right: 0px;
	}
</style>
<div class="row">
	<div class="col-lg-12">
		<?php foreach ($get_equipe->get_blog_equipes(999) as $equipe) { ?>
			
			<div class="col-sm-3 fix-equipe">
				<div class="equipe">
					<div class="equipe-content">
						<center>
							<img class="equipe-img" src="admin/assets/img/equipe/<?php echo $equipe[2]; ?>">
						</center>
						<div class="equipe-info">
							<div class="equipe-text h4"><?php echo $equipe[3]; ?></div>
							<h5 class="equipe-text"><?php echo $equipe[4]; ?></h5>
							<marquee direction="left" >
								<?php echo $equipe[5]; ?>
							</marquee>
							<br>
							
							<?php if (!empty($equipe[6])) { ?>
								<a href="<?php echo $equipe[6]; ?>" target="_blank"><img src="assets/img/social/facebook.gif" alt="facebook"></a>
							<?php } ?>

							<?php if (!empty($equipe[7])) { ?>
								<a href="<?php echo $equipe[7]; ?>" target="_blank"><img src="assets/img/social/instagram.gif" alt="instagram"></a>
							<?php } ?>

							<?php if (!empty($equipe[8])) { ?>
								<a href="<?php echo $equipe[8]; ?>" target="_blank"><img src="assets/img/social/twitter.gif" alt="twitter"></a>
							<?php } ?>

							<?php if (!empty($equipe[9])) { ?>
								<a href="https://api.whatsapp.com/send?phone=<?php echo $equipe[9]; ?>" target="_blank"><img src="assets/img/social/whatsapp.gif" alt="whatsapp"></a>
							<?php } ?>

							
							
						</div>
					</div>
				</div>
			</div>

		<?php } ?>
	</div>
</div>