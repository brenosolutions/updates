<?php 
$on = 'equipe'; 

require_once("login.php");

?>
<div class="col-md-12">
<br/>
<div id="panel-body">
	<a class="btn btn-primary" href = "index.php?p=manage-equipe"><i class="fa fa-chevron-circle-left"></i> Voltar</a>
</div>

<div id = "">
<?php 

$img = $_GET["img"];


if (isset($_SESSION["token"]) 
    && isset($_SESSION["token_time"]) 
    && isset($_POST["token"]) 
    && $_SESSION["token"] == $_POST["token"]) {

	
	unlink("assets/img/equipe/$img");

	    
	$timestamp_old = time() - (15*60);

    if ($_SESSION["token_time"] >= $timestamp_old) {

		
		if (!empty($_GET['post_id']) && empty($_GET['comment_id'])) {


		    $post_id = $_GET['post_id']; 
			$opFile  = "data/equipe/equipefile.txt";
			$fp      = fopen($opFile,"r") or die($lang_blog_error_reading); 
			$data    = @fread($fp, filesize($opFile));
            fclose($fp);
            
            

            $line = explode("\n", $data);
			
			$no_of_posts = count($line)-1;
            
			for ( $i = 0; $i < $no_of_posts; $i++) {
	            $blog = explode("|", $line[$i]);
	            
	            if ($blog[0] == $post_id) continue;
				
				$posts .= $line[$i]. "\n";
			}
               
			$file    = fopen($opFile,"w") or die($lang_blog_error_reading); 
			$success = fwrite($file, $posts);
			fclose($file); 
			
			$filename = "data/equipe/equipe.txt";
			$fp = fopen($filename,"r") or die($lang_blog_error_reading); 

			while (!feof($fp)) {
			    $comments[] = fgets($fp);
			}
			fclose($fp); 

			$no_of_comments = count($comments)-1;
		    
			for ($i = 0; $i < $no_of_comments; $i++) {			
			    $comment = explode("|", $comments[$i]);
				
				if ($comment[0] != $post_id) {			  
			   		$comments_new .=  $comments[$i];
		 	    }	
			}

			$file    = fopen($filename, "w") or die($lang_blog_error_reading); 
			$success = fwrite($file, $comments_new);
			fclose($file);

		} elseif (!empty($_GET['comment_id'])) {
			$comment_id = $_GET['comment_id']-1; 
			$post_id    = $_GET['post_id'];
			$opFile     = "data/equipe/equipe.txt";

			$fp = fopen($opFile,"r") or die($lang_blog_error_reading); 

			while (!feof($fp)) {
			    $posts[] = fgets($fp);
			}
			fclose($fp); 

			$no_of_posts = count($posts)-1;

			for ($i = 0; $i < $no_of_posts; $i++){

				if ($i == $comment_id) {
					$delete = 1;
				} else {
			 		$new_data .= $posts[$i];
			 	}	
			}

			$file    = fopen($opFile,"w") or die("$lang_blog_error_reading"); 
			$success = fwrite($file, $new_data);
			fclose($file);

			if ($delete == 1) {
				
				$opFile = "data/equipe/equipefile.txt";
				$fp     = fopen($opFile,"r") or die("$lang_blog_error_reading");
				$data   = fread($fp, filesize($opFile));
				fclose($fp); 

				$line = explode("\n", $data);
				$nb   = count($line);
               
				for ($i = 0; $i < $nb; $i++) { 
					$blog = explode("|", $line[$i]);
					
					if ($blog[0] == $post_id) {			  
					   	 $blog[1]--;
					   	 $posts_new .=  $blog[0]. "|" . $blog[1] ."|".$blog[2]."|".$blog[3]."|".$blog[4]."|".$blog[5]."\n";
					   	
					} elseif($blog[0] != "") {
						 $posts_new .=  $blog[0]. "|" . $blog[1] ."|".$blog[2]."|".$blog[3]."|".$blog[4]."|".$blog[5]."\n";
					}
				}

				$file    = fopen($opFile,"w") or die("$lang_blog_error_reading"); 
				$success = fwrite($file, $posts_new);
				fclose($file); 
			}
		}

		$host  = $_SERVER['HTTP_HOST'];
		$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		header("Location: http://$host$uri/index.php?p=manage-equipe");
		die();
		
	} else {
		echo "<p class=\"errorMsg created\">$lang_blog_session_expire</p>";
	}
				
} else {
	
	if (!empty($_GET['post_id']) || !empty($_GET['comment_id'])) {
	    $post_id = $_GET['post_id']; 
		$token   = md5(uniqid(rand(), TRUE));
		$_SESSION["token"] = $token;
		$_SESSION["token_time"] = time();
		
		echo "<p>$lang_blog_sure_delete</p><br>";
		
		if (!empty($_GET['comment_id'])) {
			$comment_id = $_GET['comment_id']; 
			echo "<form action=\"index.php?p=del-equipe&post_id=". $post_id ."&comment_id=". $comment_id ."\" method=\"post\">";
			
		} else {
			echo "<form action=\"index.php?p=del-equipe&post_id=$post_id&img=$img\" method=\"post\">";
		}
		echo "<p><input type=\"hidden\" name=\"token\" value=\"$token\" />";
		echo "<button class=\"btn btn-success\" value=\"Yes\" type=\"submit\" class=\"btn\"><i class=\"fa fa-thumbs-up\"></i> $lang_yes</button>";
		echo "&nbsp;&nbsp;&nbsp;<a class=\"btn btn-default\" href=\"index.php?p=manage-equipe\" class=\"btn\"><i class=\"fa fa-thumbs-down\"></i> $lang_cancel</a>";
		echo "</form>";
		
	} else {
		echo "<p class=\"errorMsg\">Não é possível localizar</p>";
	}
}								
?>
</div></div>