<?php
require_once("login.php");
require_once("helpers/img.php");


$on = 'equipe';

if (!empty($_POST)) {
	$filename = "data/equipe/equipefile.txt";

	if (isset($_POST['name'])) {
		$name = $_POST['name'];
		$cargo = $_POST['cargo'];
		$descricao = $_POST['descricao'];
		$facebook = $_POST['facebook'];
		$instagram = $_POST['instagram'];
		$twitter = $_POST['twitter'];
		$whatsapp = $_POST['whatsapp'];

		$banner = $_FILES['banner']['name'];
		$image_error = $_FILES['banner']['error'];
		$image_type = $_FILES['banner']['type'];
// common image file extensions
		$allowedExts = array("gif", "jpeg", "jpg", "png");
		
			// get image file extension
		error_reporting(E_ERROR | E_PARSE);
		$extension = end(explode(".", $_FILES["banner"]["name"]));
		
		if($image_error > 0){
			$error['banner'] = " <span class='label label-danger'>Você não inseriu a imagens!</span>";
		}else if(!(($image_type == "image/gif") || 
			($image_type == "image/jpeg") || 
			($image_type == "image/jpg") || 
			($image_type == "image/x-png") ||
			($image_type == "image/png") || 
			($image_type == "image/pjpeg")) &&
		!(in_array($extension, $allowedExts))){
			
			$error['banner'] = " <span class='label label-danger'>Imagem no formato jpg, jpeg, gif, ou png!</span>";
		}
		
		if(!empty($banner) && empty($error['banner'])){
			
				// create random image file name
			$string = '0123456789';
			$file = preg_replace("/\s+/", "_", $_FILES['banner']['name']);
			$function = new functions;
			$banner = $function->get_random_string($string, 4)."-".date("Y-m-d").".".$extension;
			
				// upload new image
			$upload = move_uploaded_file($_FILES['banner']['tmp_name'], 'assets/img/equipe/'.$banner);
		}


		$fp   = fopen($filename,"r") or die($lang_blog_error_reading); 
		$data = @fread($fp, filesize($filename));
		fclose($fp);
		
		$line = explode("\n", $data);
		$no_of_posts = count($line)-1;
		
		
		for ($i=0; $i<$no_of_posts; $i++) {
			$blog = explode("|", $line[$i]);
			$posts[$i] = $blog[0];
		}
		
		if(count($posts) > 0) {
			$no_of_posts = max($posts)+1;
		} else {
			$no_of_posts = 1;
		}
		

		$blog = $no_of_posts ."|0|". $banner ."|". $name ."|". $cargo. "|". $descricao. "|". $facebook. "|". $instagram. "|". $twitter. "|". $whatsapp."\n";

		$data = fopen($filename, "a");
		fwrite($data, $blog);
		fclose($data);
		
		$host  = $_SERVER['HTTP_HOST'];
		$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		header("Location: http://$host$uri/index.php?p=manage-equipe");
		die();
	}
}

?>
<div class="col-md-12">

	<div id="panel-body">
		<br/>
		<a class="btn btn-primary" href="index.php?p=manage-equipe"><i class="fa fa-chevron-circle-left"></i> Voltar</a>
		<button onclick="document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_blocks_save; ?></button>
	</div>
	<br />


	<!-- Advanced Tables -->
	<div class="panel panel-default">
		<div class="panel-heading">
			Novo
		</div>
		<div class="panel-body">
			<div class="table-responsive">
				<div id="" class="max">

					<form class="editor" name="editor" action="" method="post" enctype="multipart/form-data">
						<label>Nome</label>
						<input class="form-control" type="text" name="name"  value="" required>
						<br/>

						<label>Cargo</label>
						<input class="form-control" type="text" name="cargo"  value="">
						<br/>

						<label>Descrição</label>
						<textarea class="form-control"  name="descricao" rows="4"></textarea>
						<br/>

						<br>
						<label>Foto</label>
						<img id="output" src="" width="209" height="auto" />
						<br/>Tamanho recomendado: 215x215 pixels.
						<input type="file" name="banner" value="" accept="image/*" class="default" onchange="loadFile(event)" required>

						<script>
							var loadFile = function(event) {
								var output = document.getElementById('output');
								output.src = URL.createObjectURL(event.target.files[0]);
							};
						</script>
						<br>
						<label>Facebook</label>
						<input class="form-control" type="text" name="facebook" placeholder="URL Facebook" value="">
						<small>Deixe em branco para desativar.</small>

						<br><br>

						<label>Instagram</label>
						<input class="form-control" type="text" name="instagram" placeholder="URL Instagram" value="">
						<small>Deixe em branco para desativar.</small>

						<br><br>

						<label>Twitter</label>
						<input class="form-control" type="text" name="twitter" placeholder="URL Twitter" value="">
						<small>Deixe em branco para desativar.</small>

						<br><br>

						<label>Whatsapp</label>
						<input class="form-control" type="text" name="whatsapp" placeholder="Número Whatsapp. EX: 5585988888888" value="">
						<small>Codigo do país + DDD + Número do telefone. Deixe em branco para desativar.</small>

					</form>
				</div>
			</div>
			
		</div>
	</div>
	<!--End Advanced Tables -->
</div>