<?php
	include_once("admin/bd/locutores.php");


	date_default_timezone_set("$fuso_horario");
	error_reporting(0);
	include_once("admin/includes/path.php");
	include_once("admin/includes/helpers/programacao_lib.php");
	include_once("admin/includes/helpers/locutores_lib.php");

	$cache_today = date("F j, Y, g:i a s");
	$semana_atual = date('D');
	$hora_atual = date('H:i');
	// Get Conteudo
	$get_programacao = new show_Programacao;
	$get_locutores = new show_Locutores; 
?>
<?php foreach ($get_programacao->get_blog_programacao(999,'') as $programa) { ?>
	<?php if($programa[4] == $semana_atual && $programa[7] == 'ativo'){   ?>
		<?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6]) {  ?>
			<?php 
				foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
					if ($locutor[3] == $programa[3]) {
						$facebook_locutor = $locutor[4];
						$foto_locutor = 'admin/assets/img/locutores/'.$locutor[2]; 
					}
				}
			?>
			<center>
				<a href="<?php echo $facebook_locutor; ?>" target="_blank" >
					<img src="<?php echo $foto_locutor; ?>" />
				</a>
			
				<div class='event-feed'>
					<h5><?php echo $programa[3]; ?></h5>
					<p style="margin: 0 0 0;"><?php echo $programa[2]; ?></p>
					<i><?php echo $programa[5]; ?> - <?php echo $programa[6];?></i>
				</div>
			</center>
			<?php $vazio = $programa[5]; ?>
		<?php } ?>
	<?php } ?>
<?php } ?>
<?php if(empty($vazio)){ ?>
	<center>
		<img src='admin/assets/img/locutores/padrao.png?img=<?php echo urlencode($cache_today); ?>' />
		<div class='event-feed'>
			<h5><?php echo $locutor1_nome; ?></h5>
			<p><?php echo $programa1_nome; ?></p>
		</div>
	</center>
<?php } ?>