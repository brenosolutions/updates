<?php

error_reporting(0);
date_default_timezone_set("$fuso_horario");

include_once("path.php");
include_once(ROOTPATH."../../config.php");
include_once("helpers/functions.php");
include_once("helpers/programacao_lib.php");
include_once("helpers/locutores_lib.php");
$semana_atual = date('D');
$hora_atual = date('H:i');

// Get Conteudo
$get_programacao = new show_Programacao;
$get_locutores = new show_Locutores; 
?>
<h4>
	<ul class="nav nav-tabs">
	  <li <?php if($semana_atual == "Mon"){ echo 'class="active"';} ?>><a data-toggle="tab" href="#seg">Segunda</a></li>
	  <li <?php if($semana_atual == "Tue"){ echo 'class="active"';} ?>><a data-toggle="tab" href="#ter">Terça</a></li>
	  <li <?php if($semana_atual == "Wed"){ echo 'class="active"';} ?>><a data-toggle="tab" href="#qua">Quarta</a></li>
	  <li <?php if($semana_atual == "Thu"){ echo 'class="active"';} ?>><a data-toggle="tab" href="#qui">Quinta</a></li>
	  <li <?php if($semana_atual == "Fri"){ echo 'class="active"';} ?>><a data-toggle="tab" href="#sex">Sexta</a></li>
	  <li <?php if($semana_atual == "Sat"){ echo 'class="active"';} ?>><a data-toggle="tab" href="#sab">Sábado</a></li>
	  <li <?php if($semana_atual == "Sun"){ echo 'class="active"';} ?>><a data-toggle="tab" href="#dom">Domingo</a></li>
	</ul>
</h4>

<style type="text/css">
	.centralizar_table{
		vertical-align:middle !important;
	}
</style>


<div class="tab-content">


	<div id="seg" class="tab-pane fade <?php if($semana_atual == "Mon"){ echo 'in active';} ?>">
		<div class="table-responsive">
			<table class="table table-bordered table-striped text-center">
				<thead>
					<tr>
						<th class="text-center">Programa</th>
						<th class="text-center">Apresentador</th>
						<th class="text-center">Horário</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($get_programacao->get_blog_programacao(999) as $programa) { ?>
						<?php if($programa[4] == 'Mon' && $programa[7] == 'ativo'){   ?>
							<?php 
								foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
									if ($locutor[3] == $programa[3]) {
										$facebook_locutor = $locutor[4];
										$foto_locutor = '/admin/assets/img/locutores/'.$locutor[2]; 
									}
								}
							?>
							<tr>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Mon") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Mon") {echo "<strong style='font-size:18px;'>Agora no Ar:</strong><br>"; } ?> <?php echo $programa[2]; ?></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Mon") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[3]; ?><br><a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="60px" height="60px" /></a></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Mon") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[5]; ?> - <?php echo $programa[6]; ?></td>
							</tr>
						<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

	<div id="ter" class="tab-pane fade <?php if($semana_atual == "Tue"){ echo 'in active';} ?>">
		<div class="table-responsive">
			<table class="table table-bordered table-striped text-center">
				<thead>
					<tr>
						<th class="text-center">Programa</th>
						<th class="text-center">Apresentador</th>
						<th class="text-center">Horário</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($get_programacao->get_blog_programacao(999) as $programa) { ?>
						<?php if($programa[4] == 'Tue' && $programa[7] == 'ativo'){   ?>
							<?php 
								foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
									if ($locutor[3] == $programa[3]) {
										$facebook_locutor = $locutor[4];
										$foto_locutor = '/admin/assets/img/locutores/'.$locutor[2]; 
									}
								}
							?>
							<tr>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Tue") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Tue") {echo "<strong style='font-size:18px;'>Agora no Ar:</strong><br>"; } ?> <?php echo $programa[2]; ?></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Tue") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[3]; ?><br><a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="60px" height="60px" /></a></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Tue") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[5]; ?> - <?php echo $programa[6]; ?></td>
							</tr>
						<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

	<div id="qua" class="tab-pane fade <?php if($semana_atual == "Wed"){ echo 'in active';} ?>">
		<div class="table-responsive">
			<table class="table table-bordered table-striped text-center">
				<thead>
					<tr>
						<th class="text-center">Programa</th>
						<th class="text-center">Apresentador</th>
						<th class="text-center">Horário</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($get_programacao->get_blog_programacao(999) as $programa) { ?>
						<?php if($programa[4] == 'Wed' && $programa[7] == 'ativo'){   ?>
							<?php 
								foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
									if ($locutor[3] == $programa[3]) {
										$facebook_locutor = $locutor[4];
										$foto_locutor = '/admin/assets/img/locutores/'.$locutor[2]; 
									}
								}
							?>
							<tr>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Wed") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Wed") {echo "<strong style='font-size:18px;'>Agora no Ar:</strong><br>"; } ?> <?php echo $programa[2]; ?></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Wed") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[3]; ?><br><a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="60px" height="60px" /></a></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Wed") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[5]; ?> - <?php echo $programa[6]; ?></td>
							</tr>
						<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

	<div id="qui" class="tab-pane fade <?php if($semana_atual == "Thu"){ echo 'in active';} ?>">
		<div class="table-responsive">
			<table class="table table-bordered table-striped text-center">
				<thead>
					<tr>
						<th class="text-center">Programa</th>
						<th class="text-center">Apresentador</th>
						<th class="text-center">Horário</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($get_programacao->get_blog_programacao(999) as $programa) { ?>
						<?php if($programa[4] == 'Thu' && $programa[7] == 'ativo'){   ?>
							<?php 
								foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
									if ($locutor[3] == $programa[3]) {
										$facebook_locutor = $locutor[4];
										$foto_locutor = '/admin/assets/img/locutores/'.$locutor[2]; 
									}
								}
							?>
							<tr>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Thu") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Thu") {echo "<strong style='font-size:18px;'>Agora no Ar:</strong><br>"; } ?> <?php echo $programa[2]; ?></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Thu") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[3]; ?><br><a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="60px" height="60px" /></a></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Thu") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[5]; ?> - <?php echo $programa[6]; ?></td>
							</tr>
						<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

	<div id="sex" class="tab-pane fade <?php if($semana_atual == "Fri"){ echo 'in active';} ?>">
		<div class="table-responsive">
			<table class="table table-bordered table-striped text-center">
				<thead>
					<tr>
						<th class="text-center">Programa</th>
						<th class="text-center">Apresentador</th>
						<th class="text-center">Horário</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($get_programacao->get_blog_programacao(999) as $programa) { ?>
						<?php if($programa[4] == 'Fri' && $programa[7] == 'ativo'){   ?>
							<?php 
								foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
									if ($locutor[3] == $programa[3]) {
										$facebook_locutor = $locutor[4];
										$foto_locutor = '/admin/assets/img/locutores/'.$locutor[2]; 
									}
								}
							?>
							<tr>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Fri") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Fri") {echo "<strong style='font-size:18px;'>Agora no Ar:</strong><br>"; } ?> <?php echo $programa[2]; ?></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Fri") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[3]; ?><br><a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="60px" height="60px" /></a></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Fri") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[5]; ?> - <?php echo $programa[6]; ?></td>
							</tr>
						<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

	<div id="sab" class="tab-pane fade <?php if($semana_atual == "Sat"){ echo 'in active';} ?>">
		<div class="table-responsive">
			<table class="table table-bordered table-striped text-center">
				<thead>
					<tr>
						<th class="text-center">Programa</th>
						<th class="text-center">Apresentador</th>
						<th class="text-center">Horário</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($get_programacao->get_blog_programacao(999) as $programa) { ?>
						<?php if($programa[4] == 'Sat' && $programa[7] == 'ativo'){   ?>
							<?php 
								foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
									if ($locutor[3] == $programa[3]) {
										$facebook_locutor = $locutor[4];
										$foto_locutor = '/admin/assets/img/locutores/'.$locutor[2]; 
									}
								}
							?>
							<tr>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sat") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sat") {echo "<strong style='font-size:18px;'>Agora no Ar:</strong><br>"; } ?> <?php echo $programa[2]; ?></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sat") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[3]; ?><br><a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="60px" height="60px" /></a></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sat") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[5]; ?> - <?php echo $programa[6]; ?></td>
							</tr>
						<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

	<div id="dom" class="tab-pane fade <?php if($semana_atual == "Sun"){ echo 'in active';} ?>">
		<div class="table-responsive">
			<table class="table table-bordered table-striped text-center">
				<thead>
					<tr>
						<th class="text-center">Programa</th>
						<th class="text-center">Apresentador</th>
						<th class="text-center">Horário</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($get_programacao->get_blog_programacao(999) as $programa) { ?>
						<?php if($programa[4] == 'Sun' && $programa[7] == 'ativo'){   ?>
							<?php 
								foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {
									if ($locutor[3] == $programa[3]) {
										$facebook_locutor = $locutor[4];
										$foto_locutor = '/admin/assets/img/locutores/'.$locutor[2]; 
									}
								}
							?>
							<tr>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sun") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sun") {echo "<strong style='font-size:18px;'>Agora no Ar:</strong><br>"; } ?> <?php echo $programa[2]; ?></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sun") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[3]; ?><br><a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="60px" height="60px" /></a></td>
								<td class="centralizar_table" <?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6] && $semana_atual == "Sun") {echo "style='background: #3f5865;color: #fff;'"; } ?>><?php echo $programa[5]; ?> - <?php echo $programa[6]; ?></td>
							</tr>
						<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>



</div>

