<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php $set_title = $lang_menu_equipe.' | '.$page_title; ?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">
    <section class="breadcrumb">
       <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
              <h1><?php echo $lang_menu_equipe; ?></h1>
              <h5><?php echo $lang_nossa_equipe; ?></h5>
            </div>
          </div>
       </div>
    </section>

    <div class="clearfix"></div>
    <section id="updates">
      <div class="container">
        <div class="row">
          <br>
          <?php include 'admin/includes/equipe-page.php'; ?>
        </div>
      </div>
    </section>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
