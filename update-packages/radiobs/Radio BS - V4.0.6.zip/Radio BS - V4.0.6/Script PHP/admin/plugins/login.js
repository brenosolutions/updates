/*=============================================================

	Desenvolvido por: Breno Costa

	Breno Solutions
	www.brenosolutions.com
	
  ========================================================  */
  
$('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});