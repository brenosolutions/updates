<?php
	$doacao = "0";
	$email_pagseguro = "contato@brenosolutions.com";
	$msg_doacao = "Ajude a Rádio BS se manter no ar";