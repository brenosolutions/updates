<?php
	$artista_top1 = "Gabriela Gomes";
	$musica_top1 = "Deus Proverá";
	$link_youtube_top1 = "1i1673ILdVI";

	$artista_top2 = "Kemuel, Lukas Agustinho";
	$musica_top2 = "Algo Novo";
	$link_youtube_top2 = "rV6GetJS0RM";

	$artista_top3 = "Ministério Zoe";
	$musica_top3 = "Aquieta Minh&#039;alma";
	$link_youtube_top3 = "ANfpF0pNob4";

	$artista_top4 = "Casa Worship";
	$musica_top4 = "A Casa É Sua";
	$link_youtube_top4 = "5QHF5OQeFOs";

	$artista_top5 = "Preto No Branco";
	$musica_top5 = "Ninguém explica Deus";
	$link_youtube_top5 = "LYsaKn8FRhc";

	$artista_top6 = "Davi Sacer";
	$musica_top6 = "Deus de Promessas";
	$link_youtube_top6 = "meiqsELWxNs";

	$artista_top7 = "Soraya Moraes";
	$musica_top7 = "Caminho no Deserto";
	$link_youtube_top7 = "AAvjEp7u9tA";

	$artista_top8 = "Midian Lima";
	$musica_top8 = "Jó";
	$link_youtube_top8 = "X3tK1cpP7YU";

	$artista_top9 = "Gabriela Rocha";
	$musica_top9 = "Lugar Secreto";
	$link_youtube_top9 = "YnrN0o0lubM";

	$artista_top10 = "Aurelina Dourado";
	$musica_top10 = "A Vitória Chegou";
	$link_youtube_top10 = "bjVvUDXqU74";

	$top_5 = "2";