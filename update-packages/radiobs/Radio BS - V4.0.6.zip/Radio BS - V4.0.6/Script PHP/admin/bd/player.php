<?php
	$color_bg_player = "#0059b8";
	$color_text_player = "#ffffff";
	$nome_stream = "Rádio BS - V4.0.5";
	$pos_player = "relative";
	$player_on = "default";