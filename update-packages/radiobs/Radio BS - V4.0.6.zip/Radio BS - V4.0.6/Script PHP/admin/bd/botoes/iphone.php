<a class="no-ajaxy" href="<?php echo $bios_url; ?>" target="_blank"><img class="celularimg"  src="assets/img/ios.png" title="Iphone"></a>
