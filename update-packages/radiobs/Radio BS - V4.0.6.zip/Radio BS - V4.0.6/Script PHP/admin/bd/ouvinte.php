<?php
	$ouvinte_nome = "DJ BS";
	$ouvinte_facebook = "https://www.facebook.com/brenosolutions";
	$ouvinte_instagram = "https://www.facebook.com/brenosolutions";
	$ouvinte_twitter = "https://twitter.com/brenosolutions";
	$ouvinte_mes = "1";

	$ouvinst_select = "inst.php";
	$ouvface_select = "fb.php";
	$ouvtw_select = "tw.php";