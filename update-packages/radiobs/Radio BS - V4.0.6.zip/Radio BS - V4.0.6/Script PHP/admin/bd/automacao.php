<?php
	$pedido_select = "1";
	$msg_offline = "No momento todos os nossos apresentadores estão offline, tente novamente mais tarde, obrigado!";
	$locutor1_nome = "AutoDJ";
	$programa1_nome = "Piloto Automático";
	$fuso_horario = "America/Fortaleza";
	$noticias_auto = "1";
	$rss_servidor_select = "3";
	$rss_select = "https://guiame.com.br/musica/feed";