<?php
	$proxy_stream = "off";
	$proxy_url_stream = "https://ssl.xcast.com.br:10894/stream";
	$ip_stream = "stm4.hostfive.com.br";
	$port_stream = "10894";
	$stream_mount = "/stream";
	$proto_stream = "shoutcast";