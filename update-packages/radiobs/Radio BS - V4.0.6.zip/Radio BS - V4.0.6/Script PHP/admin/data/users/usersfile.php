0|<?php exit(); ?>|no_value||||1
1|3046-2019-07-24.gif|Administrador|admin@admin.com|admin|admin|2
2|5419-2020-12-12.png|Locutor|teste@test.com|locutor|locutor|1
