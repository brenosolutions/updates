<?php
	$pulse_lang_options = array(
        array('Português (Brasil)','PT_BR'),
        array('English','EN')
     );
?>