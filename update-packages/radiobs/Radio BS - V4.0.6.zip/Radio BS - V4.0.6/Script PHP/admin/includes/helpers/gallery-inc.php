<?php include_once("include-jquery.php");?>

<link rel="stylesheet" href="plugins/flex/flexslider.css" />
<script src="plugins/flex/jquery.flexslider.js"></script>