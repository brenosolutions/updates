<!--
Desenvolvido por: Breno Costa

Breno Solutions
www.brenosolutions.com
-->

<?php session_start(); ?>

<?php include_once("../config.php"); ?>

<style>
body {
	font-family: sans-serif;
	line-height:1.4;
	padding: 20px;
	color: #333;
}
</style>

<h1>Ferramenta de diagnóstico</h1>

<hr>

<h2>Requisitos do sistema</h2>

<p>Requisitos básicos do sistema são um servidor Apache com PHP5 instalado.</p>

<?php

function my_ini_get($name) {        
	$setting = (ini_get($name));        
	$setting = ($setting==1 || $setting=='On') ? 'On' : 'Off';
	return $setting;
	}

?>
<p><b>Tipo de servidor:</b> <?php print $_SERVER['SERVER_SOFTWARE']; ?><br> 
<b>PHP Versão:</b> <?php print phpversion()?><br>
<b>Uploads de Arquivos:</b> <?php print my_ini_get('file_uploads'); ?><br>
<b>Modo Seguro:</b> <?php print my_ini_get('safe_mode'); ?><br>
<b>Magic Quotes:</b> <?php if(get_magic_quotes_gpc()) echo "On"; else echo "Off"; ?><br>
<b>Suporte GD:</b> <?php 

	if(!function_exists("gd_info")){ 
		print "Off";
		} 
	else{
		if(function_exists("gd_info")){ 
			print "On"; 
			}
		}	
?><br>
<b>Extensão Zip:</b> <?php if (extension_loaded('zip')) { echo "On"; } else{ echo "Off"; } ?></p> 

<hr>

<h2>Verifique permissões</h2>

<p>As pastas deve ter pelo menos 755 e 644 arquivos de permissões.</p>

<?php clearstatcache(); ?>

data - <?php echo substr(sprintf('%o', fileperms('data')), -4); ?><br>
data/blocks - <?php echo substr(sprintf('%o', fileperms('data/blocks')), -4); ?><br>
data/blog - <?php echo substr(sprintf('%o', fileperms('data/blog')), -4); ?><br>
data/img - <?php echo substr(sprintf('%o', fileperms('data/img')), -4); ?><br>
data/files - <?php echo substr(sprintf('%o', fileperms('data/files')), -4); ?><br>
data/logs - <?php echo substr(sprintf('%o', fileperms('data/logs')), -4); ?><br>
data/pages - <?php echo substr(sprintf('%o', fileperms('data/pages')), -4); ?><br>
data/stats - <?php echo substr(sprintf('%o', fileperms('data/stats')), -4); ?><br>
config.php - <?php echo substr(sprintf('%o', fileperms('../config.php')), -4); ?><br><br>

<hr>

<h2>Configuração de Pasta</h2>

<p>Este é o nome da sua pasta de admin. Se você renomeá-lo, ele deve ser alterado nas configurações. Se você tem isso em uma pasta sub que também deve ser refletido nas configurações. Ex: domain.com/sub/admin seria definida como sub/admin nas configurações.</p>

<p><b>Nome da pasta:</b> <?php echo $pulse_dir; ?></p>

<hr>

<h2>.Htaccess Verificar</h2>

<p>O arquivo .htaccess é necessário para admin funcionar corretamente. Se o arquivo estiver ausente, use o arquivo sample.htaccess. Basta remover a parte da amostra e colocá-lo fora da pasta admin.</p>

<p><?php
$filename = '../.htaccess';

if (file_exists($filename)) {
    echo "<b>O arquivo .htaccess existe.</b>";
} else {
    echo "<b>O arquivo .htaccess não existe.</b>";
}
?></p>

<hr>

<h2>Manipulação de Sessão</h2>

<p>Se as sessões não estão funcionando corretamente, pode causar problemas com o login e visualização de blocos, etc.</p>

<?
if($_GET["test"] == '1'){
	
	if($_SESSION['atest'] == 'yes'){
	
		echo('<b>Sua hospedagem suporta sessões</b>');
		
		} else echo('<b>Sua hospedagem não suporta sessões</b>');
		
	} else {
			
			$_SESSION['atest'] = 'yes';
			echo '
				<head>
				<script>
					<!--
					function delayer(){
						window.location = "'.$_SERVER['PHP_SELF'].'?test=1";
					}
					//-->
				</script>
				</head>
				<body onLoad="setTimeout(\'delayer()\', 2000)">
				<br><br>
                 Por favor, aguarde...
				</body>
				';
		}
?>
<br><br><br><br>