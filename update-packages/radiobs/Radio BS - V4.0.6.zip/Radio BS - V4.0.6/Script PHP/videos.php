<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<?php 
  $current_page = (isset($_GET['page']))?' - Página '.$_GET['page'] : '';
  $set_title = $lang_menu_videos.$current_page.' | '. $page_title; 
?>

<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">
    <section class="breadcrumb">
        
       <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
              <h1><?php echo $lang_menu_videos; ?></h1>
              <h5><?php echo $lang_h_videos; ?></h5>
            </div>                  
          </div>
       </div>
    </section>

    <div class="clearfix"></div>

    <section id="updates">
      <div class="container">
        <?php include_once("admin/includes/videos2.php"); ?>
      </div>    
    </section>
    <div class="clearfix"></div>

    <!-- youtube player modal -->
    <div class="modal fade" id="youtube-player" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><span id="youtube-title"></span></h4>
                </div>
                <div class="modal-body">
                    <div class="embed-container"><div id="youtube-embed"></div></div>
                </div>
          </div>
      </div>
    </div>
    
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
