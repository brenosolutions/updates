<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php $set_title = $lang_menu_programacao.' | '. $page_title; ?>
<?php $stylesheet = array('assets/css/tabs.css');?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">
    <section class="breadcrumb">
       <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
              <h1><?php echo $lang_menu_programacao; ?></h1>
              <h5><?php echo $lang_sub_programacao; ?></h5>
            </div>
          </div>
       </div>
    </section>
    <div class="clearfix"></div>

    <section id="updates">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-9 col-sm-9">
            <?php include_once("admin/includes/programacao-page.php"); ?>
          </div>

          <div class="col-lg-3 col-md-3 col-sm-3">
            <h1><?php echo $lang_aplicativos; ?></h1>
            <div class="banner-app">
              <?php include ("admin/bd/$apk_select"); ?>
              <?php include ("admin/bd/$ios_select"); ?>
            </div>

            <br/>

            <?php include 'admin/includes/pedido-page.php'; ?>
          </div>
        </div>
      </div>    
    </section>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
