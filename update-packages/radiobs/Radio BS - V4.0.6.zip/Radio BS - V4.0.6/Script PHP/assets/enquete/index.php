<?php  include ("../../admin/bd/theme.php"); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
<style type="text/css">
	body{
		background: rgb(255 255 255 / 0%);
	}
	<?php if ($theme == "light.css"){ ?>
    .poll-simple .poll-title {color: #000 !important;}
    .poll-simple .poll-table td {color: #000 !important;}
    .poll-simple .poll-input-cont {background-color: #696969 !important;}
    .poll-simple .poll-inner{color: #000 !important;}
    <?php } ?>
</style>
</head>
<body>
<div class='ajax-poll' tclass='poll-simple' style='width:100%;'></div>
<script type="text/javascript" src="/assets/enquete/jquery.js"></script>
<script type="text/javascript" src="/assets/enquete/ajax-poll.php"></script>
</body>
</html>