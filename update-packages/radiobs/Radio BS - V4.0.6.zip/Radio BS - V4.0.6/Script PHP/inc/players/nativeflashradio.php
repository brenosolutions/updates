<style type="text/css">
  .player{border: none !important;}
</style>
<div class="navbar-fixed-top player-sticky">
  <section class="player" id="audio-player">
    <div id="native-flash-radio" style="width:100%; height:60px;"></div>
  </section>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="inc/players/assets/js/nativeflashradiov4.js"></script>
<script>
  $("#native-flash-radio").flashradio({
    token: "",
    userinterface: "small",
    backgroundcolor: "",
    themecolor: "<?php if(!empty($color_bg_player)){ echo $color_bg_player; }else{echo "#1167ae";}; ?>", 
    themefontcolor: "<?php if(!empty($color_text_player)){ echo $color_text_player; }else{echo "#ffffff";}; ?>", 
    startvolume: "100", 
    radioname: "<?php echo $nome_stream; ?>", 
    scroll: "auto", 
    autoplay: "true", 
    useanalyzer: "real", 
    analyzertype: "4", 
    usecover: "true", 
    usestreamcorsproxy: "false", 
    affiliatetoken: "", 
    debug: "false", 
    ownsongtitleurl: "<?php echo $now_playing_url; ?>", 
    radiocover: "", 
    songgooglefontname: "", 
    songfontname: "", 
    titlegooglefontname: "", 
    titlefontname: "", 
    corsproxy: "", 
    streamprefix: "", 
    mountpoint: "", 
    radiouid: "", 
    apikey: "",
    radiojar: "",  
    streamid: "1", 
    streampath: "", 
    streamtype: "<?php echo $proto_stream; ?>2", 
    streamurl: "<?php echo $url_player_stream; ?>", 
    songinformationinterval: "60000", 
  });
</script>