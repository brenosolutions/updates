<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php 
  include_once("admin/includes/path.php");
  include_once("admin/includes/helpers/functions.php");
  include_once("admin/includes/helpers/eventos_lib.php");


  $get_eventos = new show_Blogs;

  $id_post  = super_clean($_GET["d"]);
  $evento_post_content = $get_eventos->get_blog_post($id_post);
  $news_list = substr($evento_post_content[4], 0, 180);
  $news_txt = trim(strip_tags($news_list, ''));


  //page dados
  $set_title = $evento_post_content[6].' | '. $page_title; 
  $page_desc = $news_txt.'...';
  $set_img = BASE_URL."/admin/assets/img/eventos/$evento_post_content[7]";


?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>
<div id="ajaxArea">
    <div class="pageContentArea">
    <section id="updates">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-9 col-sm-9">
            
            <?php include_once("admin/includes/eventos2.php"); ?>
          </div>

          <div class="col-lg-3 col-md-3 col-sm-3">
            <h1><?php echo $lang_aplicativos; ?></h1>
            <div class="banner-app">
              <?php include ("admin/bd/$apk_select"); ?>
              <?php include ("admin/bd/$ios_select"); ?>
            </div>
            <br/>

            <h1><?php echo $lang_locutor_ar; ?></h1>
            <span id="no-ar-home"></span>
            <?php include 'admin/includes/pedido-page.php'; ?>
            <?php include 'inc/top-musica.php'; ?>
          </div>

        </div>
      </div>    
    </section>
  </div><!--pageContent-->
</div><!--ajaxwrap--> 

<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
