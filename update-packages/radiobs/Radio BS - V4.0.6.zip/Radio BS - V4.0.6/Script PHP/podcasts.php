<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php 
  $current_page = (isset($_GET['page']))?' - Página '.$_GET['page'] : '';
  $set_title = $lang_podcasts.$current_page.' | '. $page_title; 
?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>
<style type="text/css">
  .card_panel{border:none;height:120px}
  .card_panel .content{color:#000;padding-left:130px;padding-top:10px;padding-right:10px}
  .card_panel h3{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:16px;font-weight:400;margin:0;padding-bottom:15px}
  .card_panel a{text-decoration:none}
  .card_panel .image{float:left;position:absolute}
  .card_panel .image:before{font-family:FontAwesome;content:"\f04b";position:absolute!important;background:rgb(0 0 0 / 60%);text-align:center;border-radius:50%;top:50%;margin-top:-28px;margin-left:-28px;left:50%;height:57px;width:57px;color:#fff;line-height:57px;font-size:26px}
  .card_panel .image:hover:before{background:rgb(0 0 0 / 100%);font-size:32px}
  .card_panel .data{padding-bottom:5px;font-size:12px;margin:0}
  .card_panel .local{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding-bottom:5px;font-size:12px;margin:0}
  .card_panel i{font-size:16px}
  .status span{font-size:16px}
  .card_panel img{width:120px;height:120px;border-bottom-left-radius:4px;border-top-left-radius:4px}
</style>

<div id="ajaxArea">
    <div class="pageContentArea">

        <section class="breadcrumb">
             <div class="container">
                  <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6">
                          <h1><?php echo $lang_podcasts; ?></h1>
                          
                      </div>

                  </div>
             </div>
        </section>

        <div class="clearfix"></div>
      
    <section id="updates">
          <div class="container">
              <div class="row">

                <br>
                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php include_once("admin/includes/podcasts-home.php"); ?>
                  </div>
                 
               
              </div>
          </div>    
      </section>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
