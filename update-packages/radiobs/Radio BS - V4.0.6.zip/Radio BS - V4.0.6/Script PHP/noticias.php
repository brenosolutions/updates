<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php 
  $current_page = (isset($_GET['page']))?' - Página '.$_GET['page'] : '';
  $set_title = $lang_menu_noticias.$current_page.' | '. $page_title; 
?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">

        <section class="breadcrumb">
             <div class="container">
                  <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6">
                          <h1><?php echo $lang_menu_noticias; ?></h1>
                          <h5><?php echo $lang_sub_noticias; ?></h5>
                      </div>
                  </div>
             </div>
        </section>

        <div class="clearfix"></div>
      
    <section id="updates">
          <div class="container">
              <div class="row">
                  <div class="col-lg-9 col-md-9 col-sm-9">
                    <?php 
                      if($noticias_auto == 1){ 
                        include_once("admin/includes/noticias-auto-page.php");
                        }else{
                          include_once("admin/includes/news2.php");
                        } 
                      ?>
                  </div>
                 
                <div class="col-lg-3 col-md-3 col-sm-3">
                  <h1><?php echo $lang_aplicativos; ?></h1>
                  <div class="banner-app">
                    <?php include ("admin/bd/$apk_select"); ?>
                    <?php include ("admin/bd/$ios_select"); ?>
                  </div>
                  <br/>

                  <h1><?php echo $lang_locutor_ar; ?></h1>
                  <span id="no-ar-home"></span>

                  <?php include 'admin/includes/pedido-page.php'; ?>
                
                  <?php include 'inc/top-musica.php'; ?>
                </div>
              </div>
          </div>    
      </section>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
