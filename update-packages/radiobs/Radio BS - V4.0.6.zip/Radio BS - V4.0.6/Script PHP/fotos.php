<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php $set_title = $lang_menu_fotos.' | '. $page_title; ?>

<?php $stylesheet = array('admin/plugins/albuns/css/gridGallery.css');?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>




<div id="ajaxArea">
    <div class="pageContentArea">
    <section class="breadcrumb">
       <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
              <h1><?php echo $lang_menu_fotos; ?></h1>
              <h5><?php echo $lang_sub_fotos; ?></h5>
            </div>
          </div>
       </div>
    </section>
    
    <div class="clearfix"></div>
    
    <section id="updates">
      <div class="container">
        <div class="row">
          <!-- PUT THIS HTML MARKUP WHERE YOU WANT THE GALLERY IN YOUR PAGE-->
          <div id="grid" data-directory="../admin/data/img/albuns"></div>
        </div>
      </div>
    </section>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
<!-- Script galeria  -->
  <script defer src="admin/plugins/albuns/js/rotate-patch.js"></script>
  <script defer src="admin/plugins/albuns/js/waypoints.min.js"></script> <!-- if you wont use the Lazy Load feature erase this line -->
  <script defer src="admin/plugins/albuns/js/autoAlbums.min.js?v=<?php echo $version; ?>"></script>
  <script>
    function fotos(time) {
      setTimeout(function() {
        $('#grid').grid({
          imagesOrder: 'byName', //byDate, byDateReverse, byName, byNameReverse, random
          albumsOrder: 'none', //byDate, byDateReverse, byName, byNameReverse, random, none
          folderCoverRandom: true, //If there is no folderCover image then get a random image
          foldersAtTop: true, //If you want the folders to be always first and then the images
          showNumFolder: true, //If you want to show the number of folders inside a folder
          showNumImages: true, //If you want to show the number of images inside a folder
          autoHideNumFolder: true, //If there is no folders inside a folder then don't show the number of folders
          autoHideNumImages: false, //If there is no images inside a folder then don't show the number of images
          isFitWidth: true, //Nedded to be true if you wish to center the gallery to its container
          lazyLoad: true, //If you wish to load more images when it reach the bottom of the page
          showNavBar: true, //Show the navigation bar?
          imagesToLoadStart: 15, //The number of images to load when it first loads the grid
          imagesToLoad: 5, //The number of images to load when you click the load more button
          horizontalSpaceBetweenThumbnails: 5, //The space between images horizontally
          verticalSpaceBetweenThumbnails: 5, //The space between images vertically
          columnWidth: 240, //The width of each columns, if you set it to 'auto' it will use the columns instead
          columns: 5, //The number of columns when you set columnWidth to 'auto'
          columnMinWidth: 195, //The minimum width of each columns when you set columnWidth to 'auto'
          isAnimated: true, //Animation when resizing or filtering with the nav bar
          caption: true, //Show the caption in mouse over
          captionType: 'grid-fade', // 'grid', 'grid-fade', 'classic' the type of caption effect
          lightBox: true, //Do you want the lightbox?
          lightboxKeyboardNav: true, //Keyboard navigation of the next and prev image
          lightBoxSpeedFx: 500, //The speed of the lightbox effects
          lightBoxZoomAnim: true, //Do you want the zoom effect of the images in the lightbox?
          lightBoxText: true, //If you wish to show the text in the lightbox
          lightboxPlayBtn: false, //Show the play button?
          lightBoxAutoPlay: false, //The first time you open the lightbox it start playing the images
          lightBoxPlayInterval: 4000, //The interval in the auto play mode 
          lightBoxShowTimer: true, //If you wish to show the timer in auto play mode
          lightBoxStopPlayOnClose: false, //Stop the auto play mode when you close the lightbox?
          hashTag: true, //Change the HasTag each time you navigate through albums (so you can share a single album)
        });
      }, time);
    }
    fotos(700);
  </script>
</body>
</html>
