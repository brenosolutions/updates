<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php $set_title = $page_title; ?>
<?php $stylesheet = array('inc/chat/js/emoji/style.css','assets/css/flexslider.css');?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">
      <section id="home-slider">
        <div class="container">
          <div class="home-inner">
            <div id="homeSliderNav" class="slider-nav"> 
              <a id="home-prev" href="#" class="prev fa fa-chevron-left"></a>
              <a id="home-next" href="#" class="next fa fa-chevron-right"></a>
            </div>
            <div id="flex-home" class="flexslider" data-animation="slide" data-animationSpeed="1000" data-autoPlay="true" data-slideshowSpeed="7000">
              <ul class="slides">
                <?php $gallery = "Slider"; include("admin/includes/gallery.php"); ?>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <div class="rockPlayerHolder"></div>
      <div class="clearfix"></div>

      <section id="updates">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3">
              <h1><?php echo $lang_locutor_ar; ?></h1>
              <span id="no-ar-home"></span>
              <?php include 'admin/includes/pedido-page.php'; ?>
              
              <?php if ($ouvinte_mes == 1 || $ouvinte_mes == ""){ ?>
              <h1><?php echo $lang_ouvinte_do_mes; ?></h1>  
              <div class="event-feed">
                <h5><?php echo $ouvinte_nome; ?></h5>
              </div>
              <center>
                <img src="admin/assets/img/ouvinte.png" alt="<?php echo $ouvinte_nome; ?>"/>
              </center>
              <center>
                <?php include ("admin/bd/botoes/$ouvface_select"); ?>
                <?php include ("admin/bd/botoes/$ouvtw_select"); ?>
                <?php include ("admin/bd/botoes/$ouvinst_select"); ?>
              </center>
              <?php } ?>

              <?php if ($enquete == 1) { ?>
                <h1><?php echo $lang_enquete; ?></h1>
                <style type="text/css">
                  <?php if ($theme == "light.css"){ ?>
                    .poll-simple .poll-title {color: #000 !important;}
                    .poll-simple .poll-table td {color: #000 !important;}
                    .poll-simple .poll-input-cont {background-color: #696969 !important;}
                    .poll-simple .poll-inner{color: #000 !important;}
                    <?php } ?>
                </style>
                <div class='ajax-poll' tclass='poll-simple' style='width:100%;'></div>
              <?php } ?>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">
              <?php if ($chat == 1) { ?>
                <h1><?php echo $nome_chat; ?></h1>
                <div class="chat-borda" style="width:100%; height:320px;">
                  <span id="ChatBS"></span>
                </div>
                
              <?php } ?>
              <?php if ($tv == 1) { ?>
                <h1><?php echo $nome_tv; ?></h1>
                <center>
                  <?php include_once("admin/data/pages/camera-estudio.html"); ?>
                </center>
              <?php } ?>

              <h1><?php echo $lang_h_noticias; ?></h1>
              <?php include_once("admin/includes/news-list.php"); ?>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3">
              <h1><?php echo $lang_aplicativos; ?></h1>
              <div class="banner-app">
                <?php include ("admin/bd/$apk_select"); ?>
                <?php include ("admin/bd/$ios_select"); ?>
              </div>
             
              <h1><?php echo $lang_ouca_celular; ?></h1>
              <center>
                <?php include ("admin/bd/botoes/$bapk_select"); ?>
                <?php include ("admin/bd/botoes/$bios_select"); ?>
                <?php include ("admin/bd/botoes/$bwin_select"); ?>
                <?php include ("admin/bd/botoes/$bblack_select"); ?>
              </center>
              
              <?php include 'inc/top-musica.php'; ?>
              <?php  
              if ($mural == 1) {echo "<h1>$lang_h_recado</h1>";
              include_once("admin/includes/recados/recados-home.php");
                }
              ?>
            <?php if ($doacao == 1) { ?>
              <h1><?php echo $lang_doacao; ?></h1>
              <center><?php echo $msg_doacao; ?>
              <form target="_blank" action="https://pagseguro.uol.com.br/checkout/v2/donation.html" method="post">
                <input type="hidden" name="receiverEmail" value="<?php echo $email_pagseguro ?>" />
                <input type="hidden" name="currency" value="BRL" />
                <input type="hidden" name="iot" value="button" />
                <input type="image" src="assets/img/pagseguro.png" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" />
              </form>
              </center>
            <?php } ?>
          </div>
        </div>
          <h1><?php echo $lang_h_videos; ?></h1>
              <div class="text-center">
                  <?php include_once("admin/includes/videos-home.php"); ?>
              </div>
      </div>
    </section>
    <!-- youtube player modal -->
    <div class="modal fade" id="youtube-player" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><span id="youtube-title"></span></h4>
                </div>
                <div class="modal-body">
                    <div class="embed-container"><div id="youtube-embed"></div></div>
                </div>
          </div>
      </div>
    </div>
    </div><!--pageContent-->
</div><!--ajaxwrap-->
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php// $scripts = array('');?>
<?php include ("inc/scripts.php");  ?>
<?php if ($chat == 1) { ?>
<script defer src="inc/chat/jaxinit.js?<?php echo $cache; ?>"></script>
<?php } ?>
</body>
</html>
