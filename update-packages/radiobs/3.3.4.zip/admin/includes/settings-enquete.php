<div class="col-md-12">
<br/>
<h2>Enquete</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá configurar o enquete.</h5>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Configurações Enquete
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
<form action="" method="post">
	<?php
	 if (isset($_POST['limpar'])){
		 unset($linhas);
		 $cria = fopen("../assets/enquete/app.data/poll-simple.def/votes.txt","w+");
		 fclose($cria);

		 $cria2 = fopen("../assets/enquete/app.data/poll-simple.def/ip-block.txt","w+");
		 fclose($cria2);

		 echo "<p>Resetado!</p> <META http-equiv='refresh' content='1'> ";
	}
	?>

	<button class="btn btn-excluir" name="limpar"><i class="fa fa-eraser"></i> Resetar Resultados</button>
</form>

<br/>
<form role="form" action = "index.php?p=settings-enquete" method = "post">

<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
<br><br>

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_enquete = '<?php
$enquete = "'. $enquete .'";
$pergunta_enquete = "'. $pergunta_enquete  .'";
$resposta1 = "'. $resposta1 .'";
$resposta2 = "'. $resposta2 .'";
$resposta3 = "'. $resposta3 .'";
$resposta4 = "'. $resposta4 .'";
$resposta5 = "'. $resposta5 .'";
$resposta6 = "'. $resposta6 .'";
$resposta7 = "'. $resposta7 .'";
$resposta8 = "'. $resposta8 .'";
$resposta9 = "'. $resposta9 .'";
$resposta10 = "'. $resposta10 .'";
?>';

            if ($fp = fopen("bd/enquete.php", "w")) {
                fwrite($fp, $config_enquete, strlen($config_enquete));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-enquete");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


  <div class="form-group">
     <label>Ativar / Desativar</label>
     <select class="form-control" name="enquete">

     <?php
     $enquete_options = array(
        array(Ativar Enquete,'1'),
        array(Desativar Enquete,'0')
        );

     foreach ($enquete_options as $enquete_option) {

    ?><option value = "<?php echo $enquete_option[1]; ?>"<?php echo $enquete == $enquete_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($enquete_option[0]); ?></option><?php
        } ?>
     </select>
  </div>


    <div class="form-group">
      <label>Pergunta</label>
      <input required class="form-control" type="text" name="pergunta_enquete" value="<?php echo $pergunta_enquete; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 1</label>
      <input required class="form-control" type="text" name="resposta1" value="<?php echo $resposta1; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 2</label>
      <input required class="form-control" type="text" name="resposta2" value="<?php echo $resposta2; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 3 (opcional)</label>
      <input class="form-control" type="text" name="resposta3" value="<?php echo $resposta3; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 4 (opcional)</label>
      <input class="form-control" type="text" name="resposta4" value="<?php echo $resposta4; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 5 (opcional)</label>
      <input class="form-control" type="text" name="resposta5" value="<?php echo $resposta5; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 6 (opcional)</label>
      <input class="form-control" type="text" name="resposta6" value="<?php echo $resposta6; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 7 (opcional)</label>
      <input class="form-control" type="text" name="resposta7" value="<?php echo $resposta7; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 8 (opcional)</label>
      <input class="form-control" type="text" name="resposta8" value="<?php echo $resposta8; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 9 (opcional)</label>
      <input class="form-control" type="text" name="resposta9" value="<?php echo $resposta9; ?>" />
  </div>

  <div class="form-group">
      <label>Resposta 10 (opcional)</label>
      <input class="form-control" type="text" name="resposta10" value="<?php echo $resposta10; ?>" />
  </div>


<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    
  <?php greenCheckmark();?>
  </div>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-63118517-1', 'auto');
  ga('send', 'pageview');
</script>