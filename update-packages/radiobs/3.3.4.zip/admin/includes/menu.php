﻿<!-- /. NAV Dashboard  -->
                    <li class="nav-dash" >
                        <a  href="http://<?php echo $o; ?>/admin/index.php?p=dashboard"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <!-- /. NAV páginas  -->
                    <li class="nav-blocks">
                        <a href="#"><i class="fa fa-file-text fa-3x"></i> Páginas<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-blocks"><i class="fa fa-pencil-square-o"></i>Sobre</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-photo&g=Equipe"><i class="fa fa-pencil-square-o"></i>Equipe</a>
                            </li>

                        </ul>
                      </li>
                    <!-- /. NAV Blog  -->
                    <li class="nav-blog">
                        <a href="#"><i class="fa fa-newspaper-o fa-3x"></i> Publicidade<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-photo&g=Slider"><i class="fa fa-file-image-o"></i>Gerenciar Slider</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-anuncios"><i class="fa fa-bullhorn"></i>Gerenciar Anúncios</a>
                            </li>
                            <!--<li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-blog"><i class="fa fa-book"></i></i>Gerenciar Blog</a>
                            </li>-->
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-videos"><i class="fa fa-film"></i></i>Gerenciar Vídeos</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=gerenciar-albuns"><i class="fa fa-camera"></i></i>Gerenciar Fotos</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-news"><i class="fa fa-file-text-o"></i></i>Gerenciar Notícias</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-eventos"><i class="fa fa-calendar"></i></i>Gerenciar Eventos</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-pages"><i class="fa fa-star-o"></i></i>Gerenciar Widgets</a>
                            </li>

                        </ul>
                      </li>

                    <li class="nav-pedidos">
                        <a href="http://<?php echo $o; ?>/admin/index.php?p=pedidos"><i class="fa fa-envelope-o fa-3x"></i> Pedidos</a>
                    </li>

                    <li class="nav-chat">
                        <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-chat"><i class="fa fa-commenting-o fa-3x"></i> Chat</a>
                    </li>
                    <!-- /. NAV Mídias -->
                    <li class="nav-settings-locutores">
                        <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-locutores"><i class="fa fa-users fa-3x"></i> Locutores</a>
                    </li>
                      <!-- /. NAV backups  -->
                    <li class="nav-backup" >
                        <a  href="http://<?php echo $o; ?>/admin/index.php?p=manage-backups"><i class="fa fa-hdd-o fa-3x"></i></i> Backups</a>
                    </li>

                    <!-- /. NAV Configurações  -->
                    <li class="nav-settings">
                        <a href="#"><i class="fa fa-wrench fa-3x"></i> Configurações<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings"><i class="fa fa-cog"></i>Site</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-theme"><i class="fa fa-desktop"></i>Tema</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-perfil"><i class="fa fa-user"></i>Perfil</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-player"><i class="fa fa-play-circle"></i>Player</a>
                            </li>

                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-stream"><i class="fa fa-volume-up"></i>Streaming</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-tv"><i class="fa fa-video-camera"></i>Câmera Estúdio</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-top5"><i class="fa fa-music"></i>Top 5</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-enquete"><i class="fa fa-check-circle"></i>Enquete</a>
                            </li>
                             <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-programacao"><i class="fa fa-calendar"></i>Programação</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-mural"><i class="fa fa-comments-o"></i>Mural de Recados</a>
                            </li>
                             <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-ouvinte"><i class="fa fa-star"></i>Ouvinte do Mês</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-doacao"><i class="fa fa-money"></i>Doação</a>
                            </li>


                        </ul>
                      </li>
 
                      <!-- /. NAV Ajuda  -->
                    <li class="nav-sobre">
                        <a href="#"><i class="fa fa-info-circle fa-3x"></i> Ajuda<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a  href="http://<?php echo $o; ?>/admin/includes/update.php"><i class="fa fa-refresh"></i>Atualizações</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=key-info"><i class="fa fa-key"></i>Informações da Licença</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=sobre"><i class="fa fa-question-circle"></i>Sobre o Software</a>
                            </li>

    
                        </ul>
                      </li>