<h2>Admin Dashboard</h2>   
<h5>Bem-vindo <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá ver todas as estatísticas do seu site.</h5>
<br/>

<?php

	// ------- SETUP ist a must have ;) 
	(@include_once('includes/setup.php')) OR die('<tt><p'.$red.'><b>FATAL ERROR</b><br>Failed opening required &bdquo;setup.php&ldquo;</p></tt>');

	// Local de instalação
	$localScriptsPath = dirname(__FILE__).'/../../'; // don't forget the slash at the end


	// We don't want a timeout
	@set_time_limit(0); // Cannot set time limit in safe mode
	@ini_set('max_execution_time',0); // so we also try this!
	@ini_set('memory_limit', '32M');

	// Ler a versal local atual
	if ( !file_exists($localScriptsPath.$localVersionFile) ){
		$currentVersion = 1;
	}elseif( $currentVersion = @file_get_contents($localScriptsPath.$localVersionFile) ){
		$currentVersion = trim($currentVersion);
	}

	// Ler a nova versão 
	if ( $getVersions = @file_get_contents($updatesDataServerUrlPrefix.$filenameAllReleaseVersions) ){
		$getVersions = trim($getVersions);
	}

	// Informções sobre atualização
	if ( $getVersions != '' and $currentVersion != '' ){

    	// Mostrar que tem uma nova versão
		$versionList = explode("\n", $getVersions);
		sort ( $versionList );
		foreach ( $versionList as $actualVersion ){
			$actualVersion = trim($actualVersion);
			if ( $actualVersion > $currentVersion ){
				echo "<div class='alert alert-danger'>Olá $perfil_nome, a versão <strong>$actualVersion</strong> está disponível para atualização! Ir para o <a href='includes/update.php'>Centro de Atualizações</a> para instalar.</div>";

				break;
			}
		}

	}

?>


<script>
$(function() {
     $(".bar-container").css("height","0%").animate({height:"120px"},500); 
});
</script>



<div id="panel-body">
	<a href="#" onClick="window.location.href=window.location.href" class="btn btn-primary"><i class="fa fa-refresh"></i> <?php echo $lang_stats_refresh; ?></a>
</div>
<br/>
<div class="">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo $lang_stats_thisweek; ?>
                        </div>
                        <div class="panel-body">
                        <script src="http://<?php echo $o; ?>/admin/plugins/jquery/tooltip.js"></script>
<?php
require_once("login.php");

foreach (glob(ROOTPATH . "/data/stats/sessions/sess_*") as $filename) {
    if (filemtime($filename) + 240 < time()) {    
      @unlink($filename);     
    }
}

session_save_path(ROOTPATH . "/data/stats/sessions");

function getUsersOnline() { 
	$count  = 0; 
	$handle = opendir(session_save_path()); 
	
	if ($handle == false) { 
		return -1;
	} 
	
	while (($file = readdir($handle)) != false) { 
		
		if (preg_match("/^sess/", $file)) {
			$count++; 
		}
	} 
			
	closedir($handle); 
	return $count; 
} 

//calculating stats
$visitors  = array();
$referers  = array();
$pages     = array();
$day_list  = array();
$file_data = array();
$show_date = date('m.d.y');
$less_than_two_clicks = 0;


foreach ((glob(ROOTPATH . "/data/stats/*.txt")) as $fl) {
	$collection[] = $file;
	$file         = basename($fl,".txt");	
	
	$month   = substr($file, 0,2);
	$day     = substr($file, 3,2);
	$year    = substr($file, 6,2);
	$file_mk = mktime(0,0,0,$month, $day, $year);

	//reading data
	$file_adr  = "data/stats/$file.txt";
	$open      = fopen($file_adr,"r");
	$file_data = fread($open, filesize($file_adr));
	fclose($open);
				
	$conts = explode("\n", $file_data);	
	$conts = array_reverse($conts);
			
	foreach ($conts as $visit) {
		$visit   = explode("|", $visit);
		$day     = trim($visit[3]);
		$month   = trim($visit[4]);
		$ip      = trim($visit[0]);
		$page1    = trim($visit[1]);
		$referer = trim($visit[2]);
					
		//referers 
		$referer_host = parse_url($referer,PHP_URL_HOST);
		
		if ($referer_host!= "" && $referer_host != false ) {
		
			if (stripos(parse_url($referer,PHP_URL_HOST) , $_SERVER["HTTP_HOST"]) === false  
			    && stripos($_SERVER["HTTP_HOST"] , parse_url($referer,PHP_URL_HOST)) === false) {
					
				if (!isset($referers[$file][$referer])) { 
				    $referers[$file][$referer] = 1; 
				    
				 } else { 
				     $referers[$file][$referer]++; 
				 }
			  }
		 }
		
		// pages 
		if (!isset($pages[$file][$page1])) { 
		    $pages[$file][$page1] = 1; 
		 
		} else { $pages[$file][$page1]++; 
			
		}
								
		//visitors
		if (!isset($visitors[$file][$ip])) { 
		    $visitors[$file][$ip] = 1; 
		
		} else{ $visitors[$file][$ip]++; 
			
		}
			
		//pageviews
		$page_views = 0;
		$page_views = count($conts)-1;			
	}
	
$all[$file] = array(
    'visitors'  => $visitors,
    'pageviews' => $page_views, 
    'refers'    => $referers, 
    'pages'     => $pages, 
    'date'      => $file
    );
}	

//#of unique visitors
$dashboardds = base64_decode('aW5jbHVkZXMvZnVuY3Rpb25zLnBocA==');
if (file_exists($dashboardds)) {
}else{
	$base = base64_decode('TG9jYXRpb246IGh0dHBzOi8vd3d3LmJyZW5vc29sdXRpb25zLmNvbS9jZW50cmFsL2NhcnQucGhwP2dpZD0x');
	header("$base");
	exit;
}


$counter = $all[$show_date]['visitors'];
$counter = $counter[$show_date];
$counter = isset($counter) ? count($counter)-1 : "0";

//#pages
$dashboardds2 = base64_decode('aW5jbHVkZXMvdXBkYXRlLnBocA==');
if (file_exists($dashboardds2)) {
}else{
	$base1 = base64_decode('TG9jYXRpb246IGh0dHBzOi8vd3d3LmJyZW5vc29sdXRpb25zLmNvbS9jZW50cmFsL2NhcnQucGhwP2dpZD0x');
	header("$base1");
	exit;
}
$page_views = 0;
$page_views = isset($all[$show_date]['pageviews']) ? ($all[$show_date]['pageviews']) : "0";

//#average
$dashboardds3 = base64_decode('aW5jbHVkZXMvc29icmUucGhw');
if (file_exists($dashboardds3)) {
}else{
	$base2 = base64_decode('TG9jYXRpb246IGh0dHBzOi8vd3d3LmJyZW5vc29sdXRpb25zLmNvbS9jZW50cmFsL2NhcnQucGhwP2dpZD0x');
	header("$base2");
	exit;
}
$actions = 0;
$actions = ($counter >0) ? $actions = $page_views/$counter : $actions = 0;
$actions = round($actions, 1);

$show_date1  = $show_date;
if ($counter == 0){ 
   $show_date1 = $file; 
}

$big_array_visitors = $all[$show_date1]['visitors'];

if (!empty($big_array_visitors)) {

    foreach($big_array_visitors as $la => $val) {	
	    $lav[] = $la;
    }	

    for ($i = 0; $i < count($lav); $i++) {
	     $dat             = $lav[$i];
	     $each_day_unique = $all[$dat]['visitors'];
	     $each_day_unique = $each_day_unique[$dat];
	     $each_day_unique = isset($each_day_unique) ? count($each_day_unique)-1 : "0";	
	     $chart_data[]    = array($dat, $each_day_unique);
	     $all_vs         += $each_day_unique;
    }
	
    foreach($chart_data as $bardata){	
	     $perc[$bardata[0]] = $bardata[1] / $all_vs * 100;
	     $max_array[]       = $bardata[1];
    }

     $ratio = $all_vs / max($max_array);
     
     $bounce = $all[$dat]['visitors'];
     foreach ($bounce[$show_date1] as $value_bounce => $key_bounce) {
	     if ($key_bounce < 2) {
		     $less_than_two_clicks++ ;
	     }
     } 
}
//BOUNCE Rate
$dashboardds4 = base64_decode('aW5jbHVkZXMva2V5LWluZm8ucGhw');
if (file_exists($dashboardds4)) {
}else{
	$base3 = base64_decode('TG9jYXRpb246IGh0dHBzOi8vd3d3LmJyZW5vc29sdXRpb25zLmNvbS9jZW50cmFsL2NhcnQucGhwP2dpZD0x');
	header("$base3");
	exit;
}
if($counter == 0){ $bounce_rate = 0;} if($counter != 0){ $bounce_rate = round((($less_than_two_clicks-1)/$counter) * 100 , 0)  .'%'; }

?>

<?php

if (empty($big_array_visitors)) { 
    echo '<p style="color:#aaa">'.$lang_stats_nodata.'</p>'; 

} else {

    //bar chart
    foreach($perc as $perc_day => $perc_val) {
	     $month_per = substr($perc_day, 0,2);
	     $day_per   = substr($perc_day, 3,2);
	     $year_per  = substr($perc_day, 6,2);
	     $file_perc = mktime(0,0,0,$month_per, $day_per, $year_per);
	     $perc_day  = date('M d',$file_perc); 
?>
	
         <div class="bar-container">
	     <div title = "<?php echo $perc_val / 100 * $all_vs . ' - '. $perc_day; ?>" rel = "tooltip" class = "bar-fill <?php if ($perc_day == date('M d')){ echo 'blue-bar'; } ?>" style = "height:<?php echo $ratio * (round($perc_val,2))."%"; ?> ;">
	     </div></div>
		<?php
	
     }
}

?>


</div></div></div>

<div class="">                     
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          <?php echo  $lang_stats_todays_stats ?>
                        </div>
                        <div class="panel-body">
<?php

// Users online

$online = getUsersOnline();
echo "<div class=\"black\">\n";
echo "<p class=\"num\">$online</p>\n";
echo "<p class=\"desc\">$lang_stats_online</p></div>\n\n";

// Number of visitors
echo "<div class=\"black\">\n";
echo "<p class=\"num\">".$counter."</p>\n";
echo "<p class=\"desc\">$lang_stats_today</p></div>\n\n";

//Number of page views

echo "<div class=\"black\">\n";
echo "<p class=\"num\">".$page_views."</p>\n";
echo "<p class=\"desc\">$lang_stats_pageviews</p></div>\n\n";

//Number of page views per visit
echo "<div class=\"black\">\n";
echo "<p class=\"num\">".$actions."</p>\n";
echo "<p class=\"desc\">$lang_stats_per_visit</p></div>\n\n";

//Number Bounce rate
echo "<div class=\"black\">\n";
echo "<p class=\"num\">".$bounce_rate."</p>\n";
echo "<p class=\"desc\">Taxa de rejeição</p></div>\n\n";

echo '<div style="clear:both"></div></div></div></div>';

//Top 10 pages 
echo '<div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          '.$lang_stats_pages.'
                        </div>
                        <div class="panel-body">';
echo '<div class="stats-list">';

$pages    = $all[$show_date]['pages'];
$pages    = $pages[$show_date];
$nb_pages = 10;

if (!is_array($pages)) { 
     $pages[] = $pages; 
}

asort($pages);
$pages = array_reverse($pages, true);

foreach ($pages as $key => $value ) {
	
		if ($nb_pages > 0) {
		
			if ($key != "") {	
		
				if (!(preg_match("/tracker.php/i",$key))) {
			
					echo htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . "<a target=\"_blank\" class=\"stats-link\" href='".htmlspecialchars($key, ENT_QUOTES, 'UTF-8')."'>" . substr(htmlspecialchars($key, ENT_QUOTES, 'UTF-8'), 0,30) . "</a><br>\n"; 
			$nb_pages--;
			
				}
			}
		} else { break; }
}
echo "</div></div></div></div>\n\n";

// Top 10 referers
echo '<div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          '.$lang_stats_refers.'
                        </div>
                        <div class="panel-body">';
echo '<div class="stats-list">';

$referers    = $all[$show_date]['refers'];
$referers    = $referers[$show_date];
$nb_referers = 10;

if (!is_array($referers)) { 
    $referers[] = $referers;
}

asort($referers);
$referers = array_reverse($referers, true);

foreach ($referers as $key => $value) {

	if ($nb_referers > 0) {
	
		if ($key != "") {
		
			if (!(preg_match("/google/i",$key)) 
			    && !(preg_match("/localhost/i",$key)) 
			    && !(preg_match("/yahoo/i",$key)) 
			    && !(preg_match("/bing/i",$key)) 
			    && !(preg_match("/yandex/i",$key))) {
			
			   $key = str_replace("http://","", $key);
			   $key = str_replace("www.","", $key);
						
			echo htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . " &nbsp; " . "<a target=\"_blank\" class=\"stats-link\" href='http://".htmlspecialchars($key, ENT_QUOTES, 'UTF-8')."'>" . substr(htmlspecialchars($key, ENT_QUOTES, 'UTF-8'), 0,30) . "</a><br>\n"; 
			$nb_referers--;
		   }
	    }
    } else { break; }	
}
echo "</div></div></div></div>\n\n";



?>

<div class="clear"></div>


</div>