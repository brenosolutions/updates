<?php
$enquete = "1";
$pergunta_enquete = "O que achou do novo site?";
$resposta1 = "Ótimo";
$resposta2 = "Bom";
$resposta3 = "Ruim";
$resposta4 = "";
$resposta5 = "";
$resposta6 = "";
$resposta7 = "";
$resposta8 = "";
$resposta9 = "";
$resposta10 = "";
?>