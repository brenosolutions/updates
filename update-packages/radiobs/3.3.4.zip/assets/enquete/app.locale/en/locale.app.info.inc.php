<?php

$_lng[ 'app:title' ] = "Ajax Poll Script";
$_lng[ 'app:version' ] = "3.18";
$_lng[ 'app:pid' ] = "APSMX-318";
$_lng[ 'app:homepage' ] = "http://www.phpkobo.com/ajax_poll.php";

?>