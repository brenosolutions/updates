<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php 
    include_once("admin/includes/path.php");
    include_once("admin/includes/helpers/functions.php");
    include_once("admin/includes/helpers/podcasts_lib.php");


    $get_podcasts = new show_Podcasts;

    $id_post  = super_clean($_GET["d"]);
    $podcasts_post_content = $get_podcasts->get_podcast_post($id_post);
    $pod_list = substr($podcasts_post_content[4], 0, 180);
    $pod_txt = trim(strip_tags($pod_list, ''));


    //page dados
    $set_title = $podcasts_post_content[6].' | '. $page_title; 
    $page_desc = $pod_txt.'...';
    $set_img = BASE_URL."/admin/assets/img/podcasts/$podcasts_post_content[7]";


    $opFile = "admin/data/podcasts/audios/". $id_post ."/audios.txt";
    
    if (file_exists($opFile)) {    
        $fp   = fopen($opFile,"r");
        $data = @fread($fp, filesize($opFile));
        fclose($fp);

        $line = explode("\n", $data);
        $nb   = count($line)-1;

        foreach($line as $i){
            $cats_audios[] = explode("|", $i);                             
        }
    }
?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>
<style type="text/css">
.track{background: #fff;}
.album-tracks .track 
.track_title {color: #000;}
.album-detail-content p {padding-bottom: 10px !important;}
#player_podcasts{width: 100%;}
.play_podcasts{height: 32px;width: 32px;background: #673ab7;border-radius: 50%;font-size: 16px;color: #ffffff;border: none;}
.play_podcasts:before {font-family: "FontAwesome";content: "\f04b";}
.stop_podcasts{height: 32px;width: 32px;background: #e91e63;border-radius: 50%;font-size: 16px;color: #ffffff;border: none;}
.stop_podcasts:before {font-family: "FontAwesome";content: "\f04d";}
.list-group-item{color: #000;}
.list-group-item a{text-decoration: none;color: #000;position: absolute;width: 100%;height: 52px;top: 0;line-height: 51px;margin-left: 10px;}
.list-group-item.active a{text-decoration: none;color: #fff;}
.list-group-item.active, 
.list-group-item.active:hover, 
.list-group-item.active:focus{background: #673ab7;border: none;font-weight: 600;}
.album-purchase img, .album-detail-content h3{margin-top: 10px !important;}
.list-group .audio_panel {padding: 0px 0px;line-height: 0px;background: #f1f3f4;}
audio::-webkit-media-controls-panel{background: #f1f3f4;border-radius: ;}
</style>
<div id="ajaxArea">
    <div class="pageContentArea">
        <section class="">
             <div class="container">
                  <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6">
                          <h1><?php echo $podcasts_post_content[6]; ?></h1>
                          
                      </div>

                  </div>
             </div>
        </section>
        <section id="albums">
            <div class="container">
                <div class="row">
                    <div class="album-detail">
                        <div class="album-purchase">
                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <img src="<?php echo "admin/assets/img/podcasts/$podcasts_post_content[7]"; ?>" alt="<?php echo $podcasts_post_content[6]; ?>">
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-9">
                            <div class="album-detail-content">
                                <p><?php echo $podcasts_post_content[4]; ?></p>
                            </div>

                            <div class="album-tracks">
                                <ul class="list-group">
                                    <li class="list-group-item audio_panel">
                                        <audio id="player_podcasts" controls=""></audio>
                                    </li>

                                    <?php for ($i = 0; $i < $nb; $i++) { if ($i > -1) { if ($cats_audios[$i][1] == $id_post) { ?>
                                    <li class="list-group-item">
                                      <button class="play_podcasts" audio_s="admin/data/podcasts/audios/<?php echo $id_post; ?>/<?php echo $cats_audios[$i][2]; ?>"></button> 
                                      <a href="#" class="play_pod_a" audio_s="admin/data/podcasts/audios/<?php echo $id_post; ?>/<?php echo $cats_audios[$i][2]; ?>"><?php echo $cats_audios[$i][0]; ?> - <?php if (empty($cats_audios[$i][3])) {echo $cats_audios[$i][2];}else{echo $cats_audios[$i][3];} ?></a>
                                    </li>
                                    <?php }}}?>
    
                                </ul>
                                  
                                <div class="clearfix"></div>
                            </div>
                            <div class="text-center">
                                <div class="h4" style="margin-bottom:4px;">
                                    #<?php echo $lang_compartilhe; ?>
                                </div>
                                <button class="btn btn-success" data-sharer="whatsapp" data-title="" data-url="<?php echo CURRENT_URL; ?>">
                                    <i class="fa fa-whatsapp"></i>
                                </button>
                                <button class="btn btn-info" data-sharer="telegram" data-title="" data-url="<?php echo CURRENT_URL; ?>" >
                                    <i class="fa fa-paper-plane"></i>
                                </button>
                                <button class="btn btn-primary" data-sharer="facebook" data-title="" data-url="<?php echo CURRENT_URL; ?>">
                                    <i class="fa fa-facebook"></i>
                                </button>
                                <button class="btn btn-info" data-sharer="twitter" data-title="" data-url="<?php echo CURRENT_URL; ?>">
                                    <i class="fa fa-twitter"></i>
                                </button>
                                <button class="btn btn-danger" data-sharer="email" data-title="" data-url="<?php echo CURRENT_URL; ?>">
                                    <i class="fa fa-envelope"></i>
                                </button>
                                <button id="botao" class="btn btn-default">
                                    <i class="fa fa-link"></i>
                                </button>
                                <input style="position:fixed; left:100000px;" type="text" value="<?php echo CURRENT_URL; ?>" id="texto" />
                                <div id="copy-msg"></div>
                            </div>
                            <script defer src="assets/js/sharer.min.js"></script>
                            <script type="text/javascript">
                                document.getElementById("botao").addEventListener("click", function(){
                                    document.getElementById("texto").select();
                                    document.execCommand("copy");
                                    document.getElementById("copy-msg").innerHTML = "<?php echo $lang_copiado; ?>";
                                    setTimeout(function() {
                                        document.getElementById("copy-msg").innerHTML = "";
                                    }, 2000);
                              });
                          </script>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div><!--pageContent-->
</div><!--ajaxwrap--> 


<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
