<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php $set_title = $lang_menu_contato.' | '.$page_title; ?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">
    <section class="breadcrumb">
       <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
              <h1><?php echo $lang_menu_contato; ?></h1>
              <h5><?php echo $lang_entre_contato; ?></h5>
            </div>
          </div>
       </div>
    </section>
    <div class="clearfix"></div>
    
    <section id="contact">
      <section id="updates">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 col-md-9 col-sm-9">
              <form id="contactform" action="assets/php/submit.php" method="post">
                <div class="row">
                  <div class="col-lg-5 col-md-5 col-sm-5">
                    <h5><?php echo $lang_nome; ?>:</h5>
                    <input type="text" id="name" />
                  </div>
                  <div class="col-lg-5 col-md-5 col-sm-5">
                    <h5><?php echo $lang_email; ?>:</h5>
                    <input type="text" name="email" id="email" />
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-10 col-md-10 col-sm-10">
                    <h5><?php echo $lang_mensagem; ?>:</h5>
                    <textarea name="message" id="message"></textarea>
                    <h5 style="color:#000;"><?php echo $lang_captcha; ?>:</h5>
                    <img style="width: 100px; margin-bottom:3px;" src="inc/captcha/captcha.php" alt="código captcha" />
                    <input type="text" name="captcha" id="captcha" required placeholder="<?php echo $lang_digite_codigo; ?>" />
                   <br><br><div id="contact-error" style="display:none;color:#ff002a;"><?php echo $lang_info_validas; ?></div>
                    <div class="text-center"><button id="submit1" type="submit"><?php echo $lang_enviar; ?></button></div><br><br>
                  </div>
                </div>
              </form>
            
            <br>
          <div class="text-center h4" id="contact-success" style="display:none;"><?php echo "$lang_ola "; ?><span id="contact-name"></span><?php echo ", $lang_info_msg_enviado"; ?></div> 
          </div>
          
          <div class="col-lg-3 col-md-3 col-sm-3">
            <h3><?php echo $lang_info; ?></h3>
            <i class="fa fa-whatsapp fa-2x"></i>
            <p><a href="https://api.whatsapp.com/send?phone=<?php echo $nub_whatsapp; ?>" target="_blank">WhatsApp</a></p>
            <b class=" fa fa-envelope"></b>
            <p><?php echo $email_contact; ?></p>
            <br/>
            <?php if (!empty($facebook_url)) { ?>
              <a href="<?php echo $facebook_url; ?>" target="_bank" title="Facebook"><i class="fa fa-facebook fa-2x"></i></a>
            <?php } ?>
            <?php if (!empty($twitter_url)) { ?>
              <a href="<?php echo $twitter_url; ?>" target="_bank" title="Twitter"><i class="fa fa-twitter fa-2x"></i></a> 
            <?php } ?>
            <?php if (!empty($youtube_url)) { ?>
              <a href="<?php echo $youtube_url; ?>" target="_bank" title="Youtube"><i class="fa fa-youtube fa-2x"></i></a> 
            <?php } ?>
            <?php if (!empty($google_url)) { ?>
              <a href="<?php echo $google_url; ?>" target="_bank" title="Google Plus"><i class="fa fa-google-plus fa-2x"></i></a>
            <?php } ?>
            <?php if (!empty($instagram_url)) { ?>
              <a href="<?php echo $instagram_url; ?>" target="_bank" title="Instagram"><i class="fa fa-instagram fa-2x"></i></a>
            <?php } ?>
          </div>
        </div>
      </div>
      </section>
    </section>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
