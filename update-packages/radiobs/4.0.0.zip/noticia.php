<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php 
//error_reporting(0);
include_once("admin/includes/path.php");
include_once("admin/includes/helpers/functions.php");
include_once("admin/includes/helpers/news_lib.php");
require_once('inc/OpenGraph.php');

if($noticias_auto == 1){

  $rss = simplexml_load_file($rss_select);
  foreach ($rss->channel->item as $item) {
    if(substr($_SERVER['REQUEST_URI'], 6) == BS_Clean_URL($item->title)){
      $news_txt = trim(strip_tags($item->description, ''));
      $description = substr($news_txt, 0, 180);
      $img_post = OpenGraph::fetch($item->link)->image;

      //page dados
      $set_title = $item->title.' | '. $page_title; 
      $page_desc = $description.'...';
      $set_img = $img_post;

    }
  }
 
}else{
  $get_blog = new show_Blogs;

  $id_post  = super_clean($_GET["d"]);
  $blog_post_content = $get_blog->get_blog_post($id_post);
  $news_list = substr($blog_post_content[4], 0, 180);
  $news_txt = trim(strip_tags($news_list, ''));

  //page dados
  $set_title = $blog_post_content[6].' | '. $page_title; 
  $page_desc = $news_txt.'...';
  $set_img = BASE_URL."/admin/assets/img/news/$blog_post_content[7]";
}
?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">

    <section id="updates">
          <div class="container">
              <div class="row">
                  <div class="col-lg-9 col-md-9 col-sm-9">
                    <?php 
                      if($noticias_auto == 1){ 
                          include_once("admin/includes/noticias-auto-page.php");
                        }else{
                          include_once("admin/includes/news2.php");
                        } 
                      ?>
                  </div>
                <div class="col-lg-3 col-md-3 col-sm-3">
                  <h1><?php echo $lang_aplicativos; ?></h1>
                  <div class="banner-app">
                    <?php include ("admin/bd/$apk_select"); ?>
                    <?php include ("admin/bd/$ios_select"); ?>
                  </div>
                  <br/>

                  <h1><?php echo $lang_locutor_ar; ?></h1>
                  <span id="no-ar-home"></span>
                  <?php include 'admin/includes/pedido-page.php'; ?>
                  <?php include 'inc/top-musica.php'; ?>
                </div>
              </div>
          </div>    
      </section>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
