<script async src="assets/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
<script defer src="assets/js/jquery.js"></script>
<script defer src="assets/js/ajaxify.min.js"></script>
<script defer src="assets/js/bootstrap.min.js?v=<?php echo $version; ?>"></script>
<?php if(!empty($scripts)){ foreach ($scripts as $value) {echo '<script defer src="'.$value.'?v='.$version.'"></script>';}} ?>
<script defer src="assets/js/jquery.carouFredSel-6.2.1-packed.js?v=<?php echo $version; ?>"></script>
<script defer src="assets/js/jquery.vegas.min.js?v=<?php echo $version; ?>"></script>
<script defer src="assets/jPlayer/jquery.jplayer.min.js"></script>
<script defer src="assets/jPlayer/add-on/jplayer.playlist.min.js"></script>
<script defer src="assets/js/main.js?v=<?php echo $version; ?>"></script>
<script type="text/javascript">
function play_top(value) {
	var audio_play = document.getElementById('music'+value);
	var class_btn = document.getElementById('pButton'+value);
	if(audio_play.paused){
		for (var i = 1; i <= 10; i++) {
			if (i == value) {
				audio_play.play();
				class_btn.className='';
				class_btn.className='pause';
			}else{
				document.getElementById('music'+i).pause();
				document.getElementById('pButton'+i).className='';
				document.getElementById('pButton'+i).className='play';
			}
		}
	}else{
		audio_play.pause();
		class_btn.className='';
		class_btn.className='play';
	}
}
</script>
<script defer src="admin/includes/tracker.js?uri=<?php echo isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/index.php'; ?>&ref=<?php echo isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : ''; ?>"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_id; ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?php echo $analytics_id; ?>');
</script>