<style type="text/css">
	.player{margin-bottom: -4px; border: none !important;}

</style>
<div class="navbar-fixed-top player-sticky">
	<section class="player" id="audio-player">
	  <?php include_once("admin/data/pages/player-proprio.html"); ?>
	</section>
</div>