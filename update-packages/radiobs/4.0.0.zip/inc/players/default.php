<style type="text/css">
	#audio-player {height: 65px; background: <?php if(!empty($color_bg_player)){ echo $color_bg_player; }else{echo "#1167ae";}; ?> !important; <?php if ($pos_player == "fixed") {echo "border-bottom: none !important;";}else{echo "border-top: none !important;"; } ?>}
	.audio-title,.audio-timer,.now_playing{color: <?php if(!empty($color_text_player)){ echo $color_text_player; }else{echo "#fff";}; ?>  !important;}
	.jp-playlist li {
		margin: 0;
	}
</style>
<div class="navbar-fixed-top player-sticky">
	<section id="audio-player">
	    <div class="container">
	      <div class="rock-player">
	        <div class="playListTrigger">
	        </div>
	        <div class="row">
	          <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
	            <div class="row">
	              <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
	                <div id="player-instance" class="jp-jplayer"></div>
	                <div class="controls">
	                  <div class="play-pause jp-play"></div>
	                  <div class="play-pause jp-pause" style="display:none" title="Play/Pause"></div>
	                  <div class="jp-volume-controls">
	                    <button class="jp-mute" role="button" tabindex="0">mute</button>
	                    <button class="jp-volume-max" role="button" tabindex="0">max volume</button>
	                    <div class="jp-volume-bar">
	                      <div class="jp-volume-bar-value"></div>
	                    </div>
	                  </div>
	                </div>
	              </div>
	              <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
	                <div class="player-status">
	                  <h5 class="audio-title"></h5>
	                  <div class="audio-timer">
	                    <span class="current-time jp-current-time">00:00</span> / <span class="total-time jp-duration">0:00</span>
	                  </div>
	                </div>
	              </div>
	              <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
	                <div class="player-social">
	                  <?php include ("admin/bd/botoes/$bapk_select"); ?>
	                  <?php include ("admin/bd/botoes/$bios_select"); ?>
	                  <?php include ("admin/bd/botoes/$bwin_select"); ?>
	                  <?php include ("admin/bd/botoes/$bblack_select"); ?>
	                </div>
	              </div>
	            </div>
	          </div>
	          <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
	            <div class="audio-list">
	              <div class="jp-playlist"> 
	                <ul class="hidden playlist-files">
	                  <li data-title="<?php echo $nome_stream; ?>" data-artist="<span></span>" data-mp3="<?php echo $url_player_stream; ?>"></li>
	                </ul>
	                <h5 class="no-ar"><?php echo $lang_no_ar_agora; ?>:</h5>
	                <div class="audio-track">
	                  <ul>
	                    <li></li>
	                  </ul>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div>
	      </div>
	    </div>
	</section>
</div>
<script type="text/javascript">
	setTimeout(function(){ 
		$.ajax({url: "admin/includes/locutor/no-ar-player.php", success: function(result){
			$(".jp-artist").html(result);
		}});
	}, 2500);
	setInterval(function(){
		$.ajax({url: "admin/includes/locutor/no-ar-player.php", success: function(result){
			$(".jp-artist").html(result);
		}});
	}, 120000);
</script>