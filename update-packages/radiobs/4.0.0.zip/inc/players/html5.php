<style type="text/css">
	#audio-player {height: 50px; background: <?php if(!empty($color_bg_player)){ echo $color_bg_player; }else{echo "#1167ae !important";}; ?>; <?php if ($pos_player == "fixed") {echo "border-bottom: none;";}else{echo "border-top: none;";} ?>}
	.player{padding-top: 4px;}

	.player audio{
		height: 40px;
	}

</style>

<div class="navbar-fixed-top player-sticky">
	<section id="audio-player">
	    <div class="text-center player">
	    	<audio id="native_html5" autoplay="" controls="" preload="none">
				<source src="<?php echo $url_player_stream; ?>" type="audio/mpeg">
				<source src="<?php echo $url_player_stream; ?>" type="audio/mp3">
				<source src="<?php echo $url_player_stream; ?>" type="audio/aac">
			</audio>
	    </div>
	</section>
</div>

<script type="text/javascript">
	//autoplay
	var player = document.getElementById('native_html5');
	playPromise = player.play();
    if (playPromise !== undefined) {
	    playPromise.then(_ => {
      		player.play();
      }).catch(error => {
      		player.pause();
      });
    }
</script>