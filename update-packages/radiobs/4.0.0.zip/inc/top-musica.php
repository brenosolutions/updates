<?php if ($top_5 == 1 || $top_5 == 2){ ?>
	<?php if($top_5 == 1){ ?>
      <h1><?php echo $lang_Top5; ?></h1>
    <?php }elseif($top_5 == 2){ ?>
      <h1><?php echo $lang_Top10; ?></h1>
    <?php } ?>

	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista1.png')) {echo "thumb/80/80/admin/assets/img/artistas/artista1.png";}else{echo "assets/img/music.gif";} ?>" alt="top1" class="top5">
			<audio id="music1" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top1.mp3")) {echo "admin/assets/audios/top5/top1.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton1" class="play" onclick="play_top(1)"></button>
			</div>
			<h5><strong class="top5-numero">1.</strong> <?php echo $artista_top1; ?></h5>
			<p><?php echo $musica_top1; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista2.png')) {echo "thumb/80/80/admin/assets/img/artistas/artista2.png";}else{echo "assets/img/music.gif";} ?>" alt="top2" class="top5">
			<audio id="music2" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top2.mp3")) {echo "admin/assets/audios/top5/top2.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton2" class="play" onclick="play_top(2)"></button>
			</div>
			<h5><strong class="top5-numero">2.</strong> <?php echo $artista_top2; ?></h5>
			<p><?php echo $musica_top2; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista3.png')) {echo  "thumb/80/80/admin/assets/img/artistas/artista3.png";}else{echo "assets/img/music.gif";} ?>" alt="top3" class="top5">
			<audio id="music3" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top3.mp3")) {echo "admin/assets/audios/top5/top3.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton3" class="play" onclick="play_top(3)"></button>
			</div>
			<h5><strong class="top5-numero">3.</strong> <?php echo $artista_top3; ?></h5>
			<p><?php echo $musica_top3; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista4.png')) {echo  "thumb/80/80/admin/assets/img/artistas/artista4.png";}else{echo "assets/img/music.gif";} ?>" alt="top4" class="top5">
			<audio id="music4" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top4.mp3")) {echo "admin/assets/audios/top5/top4.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton4" class="play" onclick="play_top(4)"></button>
			</div>
			<h5><strong class="top5-numero">4.</strong> <?php echo $artista_top4; ?></h5>
			<p><?php echo $musica_top4; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista5.png')) {echo  "thumb/80/80/admin/assets/img/artistas/artista5.png";}else{echo "assets/img/music.gif";} ?>" alt="top5" class="top5">
			<audio id="music5" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top5.mp3")) {echo "admin/assets/audios/top5/top5.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton5" class="play" onclick="play_top(5)"></button>
			</div>
			<h5><strong class="top5-numero">5.</strong> <?php echo $artista_top5; ?></h5>
			<p><?php echo $musica_top5; ?></p>
		</div>
	</div>

	<?php if($top_5 == 2){ ?>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista6.png')) {echo "thumb/80/80/admin/assets/img/artistas/artista6.png";}else{echo "assets/img/music.gif";} ?>" alt="top6" class="top5">
			<audio id="music6" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top6.mp3")) {echo "admin/assets/audios/top5/top6.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton6" class="play" onclick="play_top(6)"></button>
			</div>
			<h5><strong class="top5-numero">6.</strong> <?php echo $artista_top6; ?></h5>
			<p><?php echo $musica_top6; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista7.png')) {echo  "thumb/80/80/admin/assets/img/artistas/artista7.png";}else{echo "assets/img/music.gif";} ?>" alt="top7" class="top5">
			<audio id="music7" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top7.mp3")) {echo "admin/assets/audios/top5/top7.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton7" class="play" onclick="play_top(7)"></button>
			</div>
			<h5><strong class="top5-numero">7.</strong> <?php echo $artista_top7; ?></h5>
			<p><?php echo $musica_top7; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista8.png')) {echo  "thumb/80/80/admin/assets/img/artistas/artista8.png";}else{echo "assets/img/music.gif";} ?>" alt="top8" class="top5">
			<audio id="music8" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top8.mp3")) {echo "admin/assets/audios/top5/top8.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton8" class="play" onclick="play_top(8)"></button>
			</div>
			<h5><strong class="top5-numero">8.</strong> <?php echo $artista_top8; ?></h5>
			<p><?php echo $musica_top8; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista9.png')) {echo  "thumb/80/80/admin/assets/img/artistas/artista9.png";}else{echo "assets/img/music.gif";} ?>" alt="top9" class="top5">
			<audio id="music9" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top9.mp3")) {echo "admin/assets/audios/top5/top9.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton9" class="play" onclick="play_top(9)"></button>
			</div>
			<h5><strong class="top5-numero">9.</strong> <?php echo $artista_top9; ?></h5>
			<p><?php echo $musica_top9; ?></p>
		</div>
	</div>
	<div class="recent-post">
		<div class="top5-back">
			<img src="<?php if (file_exists('admin/assets/img/artistas/artista10.png')) {echo "thumb/80/80/admin/assets/img/artistas/artista10.png";}else{echo "assets/img/music.gif";} ?>" alt="top10" class="top5">
			<audio id="music10" preload="true"><source src="<?php if (file_exists("admin/assets/audios/top5/top10.mp3")) {echo "admin/assets/audios/top5/top10.mp3?".urlencode($cache_today);}else{echo "assets/audio.weba";} ?>"></audio>
			<div class="aligButton">
				<button id="pButton10" class="play" onclick="play_top(10)"></button>
			</div>
			<h5><strong class="top5-numero">10.</strong> <?php echo $artista_top10; ?></h5>
			<p><?php echo $musica_top10; ?></p>
		</div>
	</div>
	<br>
	<?php } ?>
<?php } ?>