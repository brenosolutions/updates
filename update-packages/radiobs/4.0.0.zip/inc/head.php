<head>
<meta charset="utf-8">
<title><?php echo $set_title; ?></title>
<meta name="description" content="<?php echo $page_desc; ?>">
<meta name="keywords" content="<?php echo $page_words; ?>" />

<meta property="og:type" content="website">
<meta property="og:title" content="<?php echo $set_title; ?>">
<meta property="og:description" content="<?php echo $page_desc; ?>">
<meta property="og:image:width" content="600">
<meta property="og:image:height" content="600"> 
<meta property="og:image" content="<?php echo $set_img; ?>">
<meta property="og:url" content="<?php echo CURRENT_URL; ?>">

<meta content="yes" name="apple-mobile-web-app-capable" />
<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1, user-scalable=no" />
<link rel="icon" href="admin/assets/img/favicon.jpg">
<link rel="shortcut icon" href="admin/assets/img/favicon.jpg" />
<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css?v=<?php echo $version; ?>">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/jquery.vegas.css">
<link rel="stylesheet" href="assets/css/<?php echo $theme; ?>?v=<?php echo $version; ?>">
<link rel="stylesheet" type="text/css" href="assets/css/<?php echo $corsite; ?>.css?v=<?php echo $version; ?>">
<style type="text/css">
#audio-player {font-size: 10px;position: <?php echo $pos_player; ?>;width: 100%;bottom: 0;z-index: 9999;transition: all .2s ease-in-out;-webkit-transition: all .2s ease-in-out;-moz-transition: all .2s ease-in-out;-o-transition: all .2s ease-in-out;-ms-transition: all .2s ease-in-out;}
.rock-player .controls {z-index: 100;}
.link-none{padding-left: 0 !important;margin-bottom: 0 !important;}
.player-sticky{position: sticky !important;margin-right: 0px !important;}
</style>

<?php if(!empty($stylesheet)){ foreach ($stylesheet as $value) {echo '<link rel="stylesheet" href="'.$value.'?v='.$version.'">';}} ?>

<link rel="canonical" href="<?php echo CURRENT_URL; ?>">
</head>