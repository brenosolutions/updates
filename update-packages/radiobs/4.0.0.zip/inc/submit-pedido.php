<?php
	if (isset($_POST)){
		$arquivo = "../admin/bd/pedidos.php";
		$newline = 
		"<tr><th>". $_POST['nome'].
		"</th><th>". $_POST['email'].
		"</th><th width='600px'>". $_POST['message'].
		"</th><th>". date("d/m/Y - H:i:s").
		"</th></tr>";
		$open = fopen($arquivo,"a+");
		$write = fwrite($open,$newline);
	}
?>
