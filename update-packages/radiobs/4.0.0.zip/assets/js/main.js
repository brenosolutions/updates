(function ($) {
    "use strict";
	
	$(window).resize(function(){
		var $ww=$(window).width();
				
		if($ww<=993){
			$(document).on('click', '.yamm .dropdown-menu', function (e) {e.stopPropagation();});
			$('body').click(function(e){
			  if($(e.target).closest('.navbar-default').length === 0){
				$('.nav_wrapper').removeClass('active');
				$('ul.dropdown-menu').removeClass('open');
				$('.navbar-toggle').removeClass('fa-times').addClass('fa-navicon');
			  }
			});
		
			$('.navbar-toggle').click(function(e){
				e.stopImmediatePropagation();
				if($(this).hasClass('fa-navicon')){$(this).removeClass('fa-navicon').addClass('fa-times');
				}else{$(this).removeClass('fa-times').addClass('fa-navicon');}
				$('.nav_wrapper').toggleClass('active');
				$('ul.dropdown-menu').removeClass('open');
			});
		
			$('.navbar li.dropdown').click(function(){
				$('ul.dropdown-menu').removeClass('open');
				$(this).children('ul.dropdown-menu').toggleClass('open');
				$('.nav-level-down').fadeIn();
			});
			
			if($('.nav-level-down').length==0){
			$('.navbar-default').find( 'ul.dropdown-menu' ).prepend( '<li class="nav-level-down"><a class="nav-level-down" href="#" style="display: none;"><span class="fa fa-long-arrow-left"></span></a></li>' );
			}
			$('.nav-level-down a').click(function(e){
				e.preventDefault();
				e.stopImmediatePropagation();
				$('ul.dropdown-menu').removeClass('open');
				$('.nav-level-down').fadeOut();
			});
	
		}

	}).resize();
	
	
	$('.navbar-nav a').click(function(){
		$('.navbar-nav > li').removeClass('active');
		$(this).parents('.navbar-nav > li').addClass('active');
		$('.nav_wrapper').removeClass('active');
		$('.navbar-toggle').removeClass('fa-times').addClass('fa-navicon');
	});
	/*============================
	Vegas Slider
	============================*/
	
	if($('.vegas-slides').length){
		var vegas_BG_imgs = [],
		$vegas_img = $('.vegas-slides li img'),
		vegas_slide_length= $('.vegas-slides li').length;
		for (var i=0; i < vegas_slide_length; i++) {
			var new_vegas_img = {};
			new_vegas_img['src'] = $vegas_img.eq(i).attr('src');
			new_vegas_img['fade'] =$vegas_img.eq(i).attr('data-fade');
			vegas_BG_imgs.push(new_vegas_img);
		}
		$.vegas('slideshow', {backgrounds:vegas_BG_imgs,});
	}
	
	/*============================
	Jplayer
	============================*/
	var werock,playlistScroller;
	$('.playListTrigger > a').click(function(){
		$('#audio-player').toggleClass('open');
		return false;
	});
	if($('#audio-player').length!=0 && !($('#audio-player').hasClass('jsExecuted'))){
		$('#audio-player').addClass('jsExecuted');
		$("#player-instance").jPlayer({
			cssSelectorAncestor: "#audio-player",
		});
		if($('.playlist-files').length){
			var playlist_items = [],
			$playlist_audio=$('.playlist-files li'),
			playlist_items_length= $playlist_audio.length;
			
			for (var i=0; i < playlist_items_length; i++) {
				var  new_playlist_item = {};
				new_playlist_item['title'] = $playlist_audio.eq(i).attr('data-title');
				new_playlist_item['artist'] = $playlist_audio.eq(i).attr('data-artist');
				new_playlist_item['mp3'] = $playlist_audio.eq(i).attr('data-mp3');
				playlist_items.push(new_playlist_item);
			}
		
				werock = new jPlayerPlaylist({
				jPlayer: "#player-instance",
				enableRemoveControls:true,
				cssSelectorAncestor: "#audio-player"
			},playlist_items , {
				swfPath: "assets/jPlayer/jquery.jplayer.swf",
				supplied: "mp3",
				displayTime: 'fast',
				addTime: 'fast',
			});
			
			$('.audio-title').html(werock.playlist[0].title);
			
			$("#player-instance").bind($.jPlayer.event.play, function (event) {
				var current = werock.current,
					playlist = werock.playlist;
				jQuery.each(playlist, function (index, obj) {
					if (index == current) {
						$('.audio-title').html(obj.title);
					}
				});
			});
		}

	}
	/*============================
	AjaxCall
	============================*/
	
	
		jQuery('#ajaxArea').ajaxify({requestDelay:2000,forms: false});
		
		
		$(window).on('pronto.render', function(event, eventInfo){
			werockApp();
			
			$('#ajaxArea').removeClass('loading');
		});
		$(window).on('pronto.request', function(event, eventInfo){
			$('#ajaxArea').addClass('loading');
		})
		
		werockApp();


		function werockApp(){

			
		$('.play-youtube').click(function(e){
			e.preventDefault();
			var title_video = $(this).attr('title');
			var id_video = $(this).attr('id');
			$('#youtube-player').modal('show');
			$('#youtube-title').html(title_video);
			$('#youtube-embed').html('<iframe src="https://www.youtube.com/embed/'+id_video+'" frameborder="0" allowfullscreen></iframe>');
		});

		$('#youtube-player').on('hidden.bs.modal', function() {
			$('#youtube-embed').html('');
		});

		$('.emoji-picker').hide();
		$('.autoGrid-lightbox').hide();

		$('#ChatBS').html('<div id="jaxchat" style="width:100%; height:100%; visibility:visible; overflow:hidden;"></div>').show();


		//update locutor
		$.ajax({url: "admin/includes/locutor/no-ar-home.php", success: function(result){
			$("#no-ar-home").html(result);
		}});
		setInterval(function(){
			$.ajax({url: "admin/includes/locutor/no-ar-home.php", success: function(result){
				$("#no-ar-home").html(result);
			}});
		}, 60000);

		/*============================
		2-Calander
		============================*/
		if($('.event_calender').length!=0){
			$('.event_calender').calendarWidget({month: 11,year: 2013,});
		}

		if($('.more-events').length!=0){
			$('.more-events').click(function(){$('.events_showcase').slideToggle(800);return false;});
		}
		
		if($('#flex-home').length!=0){
			$('#flex-home').flexslider({
				animation: $('#flex-home').attr('data-animation'),
				animationSpeed:$('#flex-home').attr('data-animationSpeed'),
				slideshowSpeed: $('#flex-home').attr('data-slideshowSpeed'),
				slideshow:$('#flex-home').data('autoPlay'),
				directionNav: false,controlNav: false,direction: "horizontal",
				start: function(){
					$('#homeSliderNav').show();
					$('.rockPlayerHolder').offset().top;
				}
			});
			var $flex_home = $('#flex-home');
			$('#home-next').click(function () {$flex_home.flexslider("next");return false;});
			$('#home-prev').click(function () {$flex_home.flexslider("prev");return false;});
		}
		if($('.albums-carousel').length!=0 ){
			$('.albums-carousel').carouFredSel({
				width: "100%",
				height: 300,
				circular: false,
				infinite: false,
				auto: false,
				scroll: {items: 1,easing: "linear"},
				prev: {button: "a.prev-album",key: "left"},
				next: {button: "a.next-album",key: "right"}
			});
		}
		
		/*========================
		Track Player
		========================*/
		var allowMultiple=false,trackSelector;
		if($('.track_listen').length != 0){
			
			$('.track_listen span').click(function (e) {
				e.stopImmediatePropagation();
				e.preventDefault();
				trackSelector=$(this);
					if($(this).hasClass('alreadyAdded')){
						$('.alreadyAdded-warning').slideDown();
					}
					else if(!$(this).hasClass('alreadyAdded')){
						$(this).addClass('alreadyAdded');
						werock.add({
							title:$(this).attr('data-title'),
							artist: $(this).attr('data-artist'),
							mp3: $(this).attr('data-mp3'),
						},true);
						$(this).children('i').removeClass('fa-play').addClass('fa-check');		
					}
				return false;
			});
			$('.addAgain').on('click',this,function(){
				$('.alreadyAdded-warning').slideUp();			
				  werock.add({
					  title:trackSelector.attr('data-title'),
					  artist: trackSelector.attr('data-artist'),
					  mp3: trackSelector.attr('data-mp3'),
				  },true);
				  
			});
			$('.dontAdd').on('click',this,function(){
				$('.alreadyAdded-warning').slideUp();			
				 
			});
			
		}
		
		
		/*=======================
		10-Contact Form validation
		=======================*/
		 function IsEmail(email) {
			var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			return regex.test(email);
		}
		
		if($("#contactform").length!=0){
			$("#contactform").submit(function (e) {
				e.preventDefault();
				var name = $("#name").val(),
				email = $("#email").val(),
				message = $("#message").val(),
				captcha = $("#captcha").val(),
				dataString = 'name=' + name + '&email=' + email + '&message=' + message + '&captcha=' + captcha;
				if (name === '' || !IsEmail(email) || message === '') {
					$('#contact-error').slideDown();
				} else {
					$.ajax({
						type: "POST",
						url: "inc/submit-contact.php",
						data: dataString,
						success: function (result) {
							if (result == 'error') {
								$('#contact-error').slideDown();
							}else{
								$('#contactform').slideUp();
								$('#contact-name').html(name).show();
								$('#contact-error').hide();
								$('#contact-success').show();
								setTimeout(function() {
									$('#contactform').show();
									$('#contact-success').hide();
									document.getElementById('message').value = '';
								}, 7000);
							}
							
						}
					});
				}
				return false;
			});
		}


		if($("#pedido-form").length!=0){
			$("#pedido-form").submit(function (e) {
				e.preventDefault();
				var name = $("#nome").val(),
				email = $("#email").val(),
				message = $("#message").val(),
				dataString = 'nome=' + name + '&email=' + email + '&message=' + message;
		
				if (name === '' || !IsEmail(email) || message === '') {
					$('#pedido-error').slideDown();
				} else {
					$.ajax({
						type: "POST",
						url: "inc/submit-pedido.php",
						data: dataString,
						success: function () {
							$('#pedido-form').slideUp();
							$('#pedido-name').html(name).show();
							$('#pedido-error').hide();
							$('#pedido-success').show();
							setTimeout(function() {
								$('#pedido-form').show();
								$('#pedido-success').hide();
								document.getElementById('message').value = '';

							}, 7000);
						}
					});
				}
				return false;
			});
		}	
	}

})(jQuery);