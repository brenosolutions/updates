<?php include 'inc/init.php'; ?>
<!DOCTYPE html>
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->
<?php $set_title = $lang_menu_sobre.' | '. $page_title; ?>
<?php include 'inc/head.php'; ?>
<body>
<?php include 'inc/player-selector.php'; ?>
<?php include 'inc/menu.php'; ?>

<div id="ajaxArea">
    <div class="pageContentArea">
        <section class="breadcrumb">
              
             <div class="container">
                  <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6">
                          <h1><?php echo $lang_menu_sobre; ?></h1>
                          <h5><?php echo $lang_sub_sobre_a; ?> <?php echo $page_title; ?></h5>
                      </div>                  
                  </div>
             </div>
        </section>

      <div class="clearfix"></div>

      <section id="updates">
          <div class="container">
              <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12">
                        <article class="latest-post detail">
                          <?php include_once("admin/data/blocks/sobre.html"); ?>                  
                        </article>
                  </div>
              </div>
          </div>    
      </section>
      <div class="clearfix"></div>
  </div><!--pageContent-->
</div><!--ajaxwrap-->    
<?php include ("inc/ads.php");  ?>
<?php include ("inc/footer.php");  ?>
<?php include ("inc/scripts.php");  ?>
</body>
</html>
