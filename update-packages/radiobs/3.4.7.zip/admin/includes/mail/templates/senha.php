<?php include_once("../../../../config.php"); include_once("../../lang/$pulse_lang.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<style type="text/css">
			<?php include 'style.css'; ?>
		</style>
	</head>
	<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">
		<center>
			<table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable">
				<tr>
					<td align="center" valign="top" id="bodyCell">
						<table border="0" cellpadding="0" cellspacing="0" id="templateContainer">
		
							<tr>
								<td align="center" valign="top">
									<table border="0" cellpadding="0" cellspacing="0" width="100%" id="templateBody">
										<tr>
											<td valign="top" class="bodyContent">
												<h1><?php echo $lang_ola; ?> <?php echo $_POST['nome_destinatario']; ?>,</h1>
												<p><?php echo $lang_recovery_senha3; ?></p>
												<p><b><?php echo $lang_usuario; ?>:</b> <?php echo $_POST['username']; ?></p>
												<p><b><?php echo $lang_senha; ?>:</b> <?php echo $_POST['password']; ?></p>
											</td>
										</tr>
										<tr>
											<td class="aling-button">
												<a href="<?php echo $_SERVER['SERVER_NAME']; ?>/admin" target="_blank" class="btn btn-success" title="Entrar/Login"><?php echo $lang_entrar; ?></a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td align="center" valign="top">
									<table border="0" cellpadding="0" cellspacing="0" width="100%" id="templateFooter">
										<tr>
											<td valign="top" class="footerContent">
												Copyright © <?php echo $_POST['nome_remetente']; ?> - <?php echo date('Y'); ?>.
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>