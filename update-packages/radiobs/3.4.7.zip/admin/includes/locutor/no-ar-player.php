<head>

	<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'>

	<meta http-equiv="refresh" content="120;URL=no-ar-player.php"> 

	<script src="../../../assets/js/jquery.js"></script>

</head> 

<?php

 	include ("../../../config.php");

	include_once("../../bd/locutores.php");

	include_once("../../bd/stream.php");

	include("../lang/$pulse_lang.php");





	date_default_timezone_set("$fuso_horario");

	error_reporting(0);

	include_once("../path.php");

	include_once("../helpers/programacao_lib.php");

	include_once("../helpers/locutores_lib.php");



	$cache_today = date("F j, Y, g:i a s");

	$semana_atual = date('D');

	$hora_atual = date('H:i');

	// Get Conteudo

	$get_programacao = new show_Programacao;

	$get_locutores = new show_Locutores; 

?>

<?php foreach ($get_programacao->get_blog_programacao(999,'') as $programa) { ?>

	<?php if($programa[4] == $semana_atual && $programa[7] == 'ativo'){   ?>

		<?php if ($hora_atual > $programa[5] && $hora_atual < $programa[6]) {  ?>

			<?php 

				foreach ($get_locutores->get_blog_locutores(999,'') as $locutor) {

					if ($locutor[3] == $programa[3]) {

						$facebook_locutor = $locutor[4];

						$foto_locutor = '../../assets/img/locutores/'.$locutor[2]; 

					}

				}

			?>

				<a href="<?php echo $facebook_locutor; ?>" target="_blank" ><img src="<?php echo $foto_locutor; ?>" width="38px" height="38px" /></a>



				<marquee style="position: absolute; margin-top: 15px; color:#fff; margin-left: 7px; width: 100%"  direction="left">

					<span style="font-family: 'Oswald', sans-serif; font-size:15px">

						<b>Tocando agora:</b> <span id="now-playing"></span> / <b><?php echo $lang_apresentador; ?>:</b> <?php echo $programa[3]; ?>  /  <b><?php echo $lang_programa; ?>:</b> <?php echo $programa[2]; ?> / <b><?php echo $lang_horario; ?>:</b> <?php echo $programa[5]; ?> - <?php echo $programa[6];?>

					</span>

				</marquee>

				<?php $vazio = $programa[5]; ?>

		<?php } ?>

	<?php } ?>

<?php } ?>



<?php if(empty($vazio)){ ?>

	<img src="../../assets/img/locutores/padrao.png" width="38px" height="38px" />
	<marquee style="position: absolute; margin-top: 15px; color:#fff; margin-left: 7px; width: 100%"  direction="left">
		<span style="font-family: 'Oswald', sans-serif; font-size:15px">

			<b>Tocando agora:</b> <span id="now-playing"></span> / <b><?php echo $lang_apresentador; ?>:</b> <?php echo $locutor1_nome;?>  /   <b><?php echo $lang_programa; ?>:</b> <?php echo $programa1_nome;?>

		</span>

	</marquee>

<?php } ?>





<?php if(!empty($proto_stream)){ ?>

<script type="text/javascript">

	$('#now-playing').load('https://cdn.radioscast.com.br/bs/now-playing/index.php?ip=<?php echo $ip_stream; ?>&port=<?php echo $port_stream; ?>&protocolo=<?php echo $proto_stream; ?>');

</script>

<?php } ?>