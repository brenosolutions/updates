<?php
	error_reporting(0);
	include_once("../config.php");
	include_once("bd/locutores.php");
	include_once("includes/path.php");
	include_once("includes/lang/$pulse_lang.php");
	date_default_timezone_set("$fuso_horario");
	include_once("includes/mail/config.php");
	include_once("includes/mail/smtp.php");
	include_once("includes/helpers/users_lib.php");
	$get_users = new show_Users; 

	
	if (isset($_POST['pesquisar']) || isset($_POST['enviar'])) {

		$email = $_POST['email'];

		if (!empty($email)) {

			
			foreach ($get_users->get_blog_users(150,'') as $users){
			  if ($email == $users[3]) {
				  	$user_foto = $users[1];
				    $user_nome = $users[2];
				    $user_email = $users[3];
				    $user_nivel = $users[6];
				    $user_login = $users[4];
				    $user_pass = $users[5];
			  }
			   
			}

		    if ($email == $user_email) {
				if (isset($_POST['enviar'])) {
					//enviar e-mail da senha
					send_email(
						array(
							"nome_destinatario" => $user_nome,
							"email_destinatario" => $user_email,
							"nome_remetente" => $page_title,
							"email_remetente" => $email_contact,
							"assunto" => "Sua Senha",
							"password" => $user_pass,
							"username" => $user_login,
							"template" => "senha",
							"http" => $http_https
						)
					);
					
				}
			}else{
				$error['nao_existe'] = "<span style='color:#FF0100;'>$lang_recovery_erro_conta</span><br><br><br>";
			}

			
			
		}
	}
		
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $lang_painel; ?> - <?php echo $page_title; ?></title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<link rel="icon" href="favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="favicon.png" type="image/x-icon"/>
	<link rel="stylesheet" href="css/reset-login.css">
	<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
	<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
	<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

	<link rel="stylesheet" href="css/style-login.css">


	<script type="text/javascript" src="plugins/jquery/jquery.min.js"></script>
</head>

<body>

	<div class="container">
		<div class="info">
		</div>
	</div>
	<?php if (!isset($_POST['pesquisar']) && !isset($_POST['enviar']) || isset($error['email2']) || isset($error['nao_existe'])) { ?>
	<div class="form">
		<h1 class="nome-login"><?php echo $lang_recovery_encontre; ?></h1>
		<br/>
		<form class="login-form" name="login" method="post" id="login">
			<div class="form-group">
				<input class="form-control" type="email" name="email" value="<?php if(isset($email)){echo $email;} ?>" placeholder="<?php echo $lang_email; ?>" required>
			</div>
			<?php
						
	            if(isset($error['nao_existe'])){ echo $error['nao_existe'];} 
				if(isset($error['email2'])){ echo $error['email2'];}
	        ?>
			<button class="login-btn" name="pesquisar" type="submit"><?php echo $lang_pesquisar; ?></button>
		</form>
	</div>
	<?php }elseif(isset($_POST['pesquisar']) || !isset($_POST['enviar']) ){ ?>
	<div class="form">
		<h1 class="nome-login"><?php echo $lang_recovery_senha; ?></h1>
		<br/>
		<form class="login-form" name="login" method="post" id="login">
			<input type="hidden" name="email" value="<?php echo $email; ?>">
			<b><?php echo $lang_recovery_senha2; ?></b><br>
			<?php echo $user_email; ?>
			<br>
			<br>
			<img src="assets/img/users/<?php echo $user_foto; ?>" style="width: 80px; height:80px;">
			<br>
			<strong><?php echo $user_nome; ?></strong>
			<br>
			<br>
			<button class="login-btn" name="enviar" type="submit"><?php echo $lang_enviar; ?></button>
		</form>
	</div>
	<?php }elseif(isset($_POST['enviar'])){?>
	<div class="form">
		<h1 class="nome-login"><?php echo $lang_recovery_senha_send; ?></h1>
		<br/>
		<b><?php echo $lang_recovery_senha_send2; ?></b><br>
		<br>
		<br>
		<a href="index.php"><?php echo $lang_entrar; ?></a>
	</div>
	<?php } ?>

	<script src="plugins/login.js"></script>

</body>
</html>