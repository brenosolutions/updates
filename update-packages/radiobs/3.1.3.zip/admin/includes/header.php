<!DOCTYPE html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" href="favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"/>
    <title>BS Painel - <?php echo $page_title; ?></title>
	<!-- BOOTSTRAP STYLES-->
    <link href="http://<?php echo $o; ?>/admin/assets/css/bootstrap.css" rel="stylesheet" />
    <link rel="stylesheet" href="http://<?php echo $o; ?>/admin/css/style.css" media="all" />
    <?php include('hide.php');?>
    <link rel="stylesheet" href="http://<?php echo $o; ?>/admin/plugins/plupload/jquery.plupload.queue/css/jquery.plupload.queue.css" media="all" />
    <link rel="stylesheet" href="http://<?php echo $o; ?>/admin/plugins/redactor/css/redactor.css" />
     <!-- FONTAWESOME STYLES-->
    <link href="http://<?php echo $o; ?>/admin/assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="http://<?php echo $o; ?>/admin/assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script src="http://<?php echo $o; ?>/admin/plugins/jquery/jquery.min.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/redactor.min.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/jquery/jquery_ui.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/pt_br.js"></script> 
    <!-- Redactor's plugin -->
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fullscreen.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fontsize.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fontfamily.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fontcolor.js"></script>
    <script>
        $(document).ready(function(){
            $('a.embed_toggle').on('click', function(e) {
            e.preventDefault();
            $('#main').slideToggle(400);})
        });
    </script>

    <script>
        if (!RedactorPlugins) var RedactorPlugins = {};
        RedactorPlugins.morebutton = {
            init: function ()
            {
                this.buttonAdd('morebutton', 'Insira LEIA MAIS botão para blog.', this.testButton);
            },
            testButton: function(buttonName, buttonDOM, buttonObj, e)
            {
                this.insertHtml('##mais##');
            }
        };
    </script>
    <script>
        $(function()
        {
            $('#redactor_content').redactor({
                lang: 'pt_br',
                imageUpload: 'includes/editor_images.php',
                imageGetJson: 'includes/data_json.php',
                fileUpload: 'includes/editor_files.php',
                convertDivs: false,
                autoresize: true,
                minHeight: 350,
                phpTags: true,
                linkEmail: true,
                plugins: ['fullscreen','fontsize','fontfamily','fontcolor', 'morebutton']
            });
        });
    </script>
</head>
<body id="<?php echo $page ?>">
<script>
    function select_all(obj)
        { var text_val=eval(obj);
            text_val.select();
        }
</script>

    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand" href="index.php?p=dashboard"><img src="assets/img/bs1.png" height="auto" alt="bs-painel-logo"/></a>
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">

<a href="/" target="_blank" class="btn btn-default"><i class="fa fa-globe"></i> Site</a> 
                  <a href="index.php?p=logout" class="btn btn-excluir"><i class="fa fa-power-off"></i> Sair</a> </div>
        </nav>
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <div class="nome-perfil" >
    <a href="index.php?p=settings-perfil"><img src="assets/img/usuario.png?img=<?php echo urlencode($cache_today); ?>" class="user-image img-responsive"/></a>
                   <?php echo $perfil_nome; ?>
                   </div>
                    <div class="ano-perfil" >
                    <?php
                    $datanas = "$perfil_nascimento_ano";
                    $data = date('Y');
                    $idade = $data-$datanas;
                    echo "$idade anos";
                    ?>
                    <?php echo "<br/>"  .$perfil_cidade. ' - ' .$perfil_estado; ?>
                    </div>
                    <br/>

                    <!-- /. NAV Dashboard  -->
                    <li class="nav-dash" >
                        <a  href="http://<?php echo $o; ?>/admin/index.php?p=dashboard"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <!-- /. NAV páginas  -->
                    <li class="nav-blocks">
                        <a href="#"><i class="fa fa-file-text fa-3x"></i> Páginas<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-blocks"><i class="fa fa-pencil-square-o"></i>Sobre</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-photo&g=Equipe"><i class="fa fa-pencil-square-o"></i>Equipe</a>
                            </li>

                        </ul>
                      </li>
                    <!-- /. NAV Blog  -->
                    <li class="nav-blog">
                        <a href="#"><i class="fa fa-newspaper-o fa-3x"></i> Publicidade<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-photo&g=Slider"><i class="fa fa-file-image-o"></i>Gerenciar Slider</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-anunciantes"><i class="fa fa-bullhorn"></i>Gerenciar Anunciantes</a>
                            </li>
                            <!--<li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-blog"><i class="fa fa-book"></i></i>Gerenciar Blog</a>
                            </li>-->
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-videos"><i class="fa fa-film"></i></i>Gerenciar Vídeos</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-photo&g=Fotos"><i class="fa fa-file-image-o"></i></i>Gerenciar Fotos</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-news"><i class="fa fa-file-text-o"></i></i>Gerenciar Notícias</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-eventos"><i class="fa fa-calendar"></i></i>Gerenciar Eventos</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=manage-pages"><i class="fa fa-star-o"></i></i>Gerenciar Widgets</a>
                            </li>

                        </ul>
                      </li>

                    <li class="nav-pedidos">
                        <a href="http://<?php echo $o; ?>/admin/index.php?p=pedidos"><i class="fa fa-envelope-o fa-3x"></i> Pedidos</a>
                    </li>
                    <!-- /. NAV Mídias -->
                    <li class="nav-settings-locutores">
                        <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-locutores"><i class="fa fa-users fa-3x"></i> Locutores</a>
                    </li>
                      <!-- /. NAV backups  -->
                    <li class="nav-backup" >
                        <a  href="http://<?php echo $o; ?>/admin/index.php?p=manage-backups"><i class="fa fa-hdd-o fa-3x"></i></i> Backups</a>
                    </li>

                    <!-- /. NAV Configurações  -->
                    <li class="nav-settings">
                        <a href="#"><i class="fa fa-wrench fa-3x"></i> Configurações<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings"><i class="fa fa-cog"></i>Site</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-theme"><i class="fa fa-desktop"></i>Tema</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-perfil"><i class="fa fa-user"></i>Perfil</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-player"><i class="fa fa-play-circle"></i>Player</a>
                            </li>

                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-stream"><i class="fa fa-volume-up"></i>Streaming</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-tv"><i class="fa fa-video-camera"></i>Câmera Estúdio</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-top5"><i class="fa fa-music"></i>Top 5</a>
                            </li>
                             <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-programacao"><i class="fa fa-calendar"></i>Programação</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-mural"><i class="fa fa-comments-o"></i>Mural de Recados</a>
                            </li>
                             <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-ouvinte"><i class="fa fa-star"></i>Ouvinte do Mês</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=settings-doacao"><i class="fa fa-money"></i>Doação</a>
                            </li>


                        </ul>
                      </li>
 
                      <!-- /. NAV Ajuda  -->
                    <li class="nav-sobre">
                        <a href="#"><i class="fa fa-info-circle fa-3x"></i> Ajuda<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a  href="http://<?php echo $o; ?>/admin/includes/update.php"><i class="fa fa-refresh"></i>Atualizações</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=key-info"><i class="fa fa-key"></i>Informações da Licença</a>
                            </li>
                            <li>
                                <a href="http://<?php echo $o; ?>/admin/index.php?p=sobre"><i class="fa fa-question-circle"></i>Sobre o Software</a>
                            </li>

    
                        </ul>
                      </li>

                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
        

        <?php

// ------- SETUP ist a must have ;) 
    (@include_once('includes/setup.php')) OR die('<tt><p'.$red.'><b>FATAL ERROR</b><br>Failed opening required &bdquo;setup.php&ldquo;</p></tt>');

// Local de instalação
$localScriptsPath = dirname(__FILE__).'/../../'; // don't forget the slash at the end


// We don't want a timeout
@set_time_limit(0); // Cannot set time limit in safe mode
@ini_set('max_execution_time',0); // so we also try this!
@ini_set('memory_limit', '32M');

// Ler a versal local atual
if ( !file_exists($localScriptsPath.$localVersionFile) )
{
    $currentVersion = 1;
}
else
if( $currentVersion = @file_get_contents($localScriptsPath.$localVersionFile) )
{
    $currentVersion = trim($currentVersion);
}

// Ler a nova versão 
if ( $getVersions = @file_get_contents($updatesDataServerUrlPrefix.$filenameAllReleaseVersions) )
{
    $getVersions = trim($getVersions);
}

// Informções sobre atualização
if ( $getVersions != '' and $currentVersion != '' )
{

    // Mostrar que tem uma nova versão
    $versionList = explode("\n", $getVersions);
    sort ( $versionList );
    foreach ( $versionList as $actualVersion )
    {
        $actualVersion = trim($actualVersion);
        if ( $actualVersion > $currentVersion ) 
        {
            echo "<div class='alert alert-danger'>Olá $perfil_nome, a versão <strong>$actualVersion</strong> está disponível para atualização! Ir para o <a href='includes/update.php'>Centro de Atualizações</a> para instalar.</div>";
            
            break;
        }
    }
    
}

 ?>
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">


