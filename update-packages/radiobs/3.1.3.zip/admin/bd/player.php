<?php
$back_player = "#594d42";
$nome_stream = "Rádio BS - V3.1";
$pos_player = "";
$player_on = "1";



?>