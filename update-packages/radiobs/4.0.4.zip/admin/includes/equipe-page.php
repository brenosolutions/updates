<?php

	include_once("helpers/equipe_lib.php");
	$get_equipe = new show_Equipe; 

?>

	<div class="col-lg-12">
		<?php foreach ($get_equipe->get_equipe() as $equipe) { ?>
			
			<div class="col-sm-3 fix-equipe">
				<div class="equipe">
					<div class="equipe-content">
						<center>
							<img class="equipe-img" src="admin/assets/img/equipe/<?php echo $equipe[2]; ?>" alt="<?php echo $equipe[3]; ?>">
						</center>
						<div class="equipe-info">
							<div class="equipe-text h4"><?php echo $equipe[3]; ?></div>
							<h5 class="equipe-text"><?php echo $equipe[4]; ?></h5>
							<marquee direction="left" >
								<?php echo $equipe[5]; ?>
							</marquee>
							<br>
							
							<?php if (!empty($equipe[6])) { ?>
								<a class="no-ajaxy" href="<?php echo $equipe[6]; ?>" target="_blank"><img src="assets/img/social/facebook.gif" alt="facebook"></a>
							<?php } ?>

							<?php if (!empty($equipe[7])) { ?>
								<a class="no-ajaxy" href="<?php echo $equipe[7]; ?>" target="_blank"><img src="assets/img/social/instagram.gif" alt="instagram"></a>
							<?php } ?>

							<?php if (!empty($equipe[8])) { ?>
								<a class="no-ajaxy" href="<?php echo $equipe[8]; ?>" target="_blank"><img src="assets/img/social/twitter.gif" alt="twitter"></a>
							<?php } ?>

							<?php if (!empty($equipe[9])) { ?>
								<a class="no-ajaxy" href="https://api.whatsapp.com/send?phone=<?php echo $equipe[9]; ?>" target="_blank"><img src="assets/img/social/whatsapp.gif" alt="whatsapp"></a>
							<?php } ?>

						</div>
					</div>
				</div>
			</div>

		<?php } ?>
	</div>
