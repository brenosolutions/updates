<a class="no-ajaxy" href="<?php echo $bapk_url; ?>" target="_blank"><img class="celularimg" src="assets/img/android.png" title="Android"></a>
