<?php include ("config.php");  ?>
<!DOCTYPE html>
<html lang="pt-br">
	  <head>
	  <title><?php echo $page_title; ?></title>
	  <meta name="description" content="<?php echo $page_desc; ?>">
	  <meta charset="utf-8">
	  <meta name = "format-detection" content = "telephone=no" />
	  <link rel="icon" href="admin/assets/img/favicon.jpg" type="image/x-icon">
	  <link rel="shortcut icon" href="admin/assets/img/favicon.jpg" type="image/x-icon"/>
	  <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" type="text/css" href="<?php echo $corsite; ?>">
	  <script src="js/jquery.js"></script>
	  <script src="js/jquery-migrate-1.1.1.js"></script>
	  <script src="js/jquery.easing.1.3.js"></script>
	  <script src="js/scroll_to_top.js"></script>
	  <script src="js/script.js"></script>
	  <script src="js/jquery.equalheights.js"></script>
	  <script src="js/superfish.js"></script>
	  <script src="js/jquery.mobilemenu.js"></script>
	  <script src="js/touchTouch.jquery.js"></script>
	  <!-- font-awesome font -->
	  <link rel="stylesheet" href="font/font-awesome.css" type="text/css" media="screen">
	  <!-- fontello font -->
	  <script src="js/camera.js"></script>
	  <!--[if (gt IE 9)|!(IE)]><!-->
	  <script src="js/jquery.mobile.customized.min.js"></script>
	  <!--<![endif]-->
	  </head>
<body>
<!--button back top-->
<div id="back-top"></div>    
<div class="main">
	<div class="div-content">  
<!--==============================header=================================-->
		  <header>
				<div class="container_24">
					 <div class="grid_24">
					 		<h1><a href="/"><img src="admin/assets/img/logo.png" alt="Logo"></a></h1>
						  <nav>
								<ul class="sf-menu header_menu">
									 <li class="current"><a href="/"><?php echo $menu_home; ?></a></li>
									 <li><a href="vozes"><?php echo $menu_audios; ?></a></li>
									 <li><a href="videos"><?php echo $menu_videos; ?></a></li>
									 <li><a href="estudio"><?php echo $menu_estudio; ?></a></li>
									 <li><a href="blog"><?php echo $menu_blog; ?></a></li>
									 <li><a href="contato"><?php echo $menu_contato; ?></a></li>
								</ul>
						  </nav>
					 </div>
				</div>
		  </header>
<!--=======content================================-->





	
			
            <div class="slideshow-container">
				<?php $gallery ="Slider"; include($_SERVER["DOCUMENT_ROOT"]."/admin/includes/gallery.php"); ?>
			</div>
				
		

			<div class="box-5-servicos">
				<div class="container_24">
					<div class="grid_24">
					<h2 class="center">Serviços</h2>
					 <?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/includes/servicos2.php"); ?> 
					</div>
				</div>
				<div class="espaco-1"></div>
					<div class="center">
					<a href="vozes" class="more_btn v2">Banco de Vozes</a> <a href="contato" class="more_btn2 v2">Solicitar orçamento</a>
					</div>
			</div>
		<div class="box-1">
		  <div class="container_24">
				<div class="grid_24">
				<h2 class="center">ÚLTIMOS VÍDEOS</h2>
				<div class="espaco-1"></div>
					<div class="wrapper">
                    	<?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/includes/videos-home.php");  ?> 
                    	<center><a href="videos" class="more_btn v2">Mais Vídeos...</a></center>
                    <div class="espaco-1"></div>
					</div>
				</div>
			</div>
			</div>
			<div class="box-5">
				<div class="container_24">
					<div class="grid_24">
					<div class="espaco-3"></div>
					<h2 class="center">QUAL ESTILO DE LOCUÇÃO VOCÊ PRECISA?</h2>
					<div class="espaco-1"></div>
						<?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/includes/estilo2.php");  ?>
					  </div>
				</div>
				<div class="espaco-1"></div>
			</div>
     	<br/>
	 </div>
	 </div>
<?php include "rodape.php"; ?>
</body>
</html>