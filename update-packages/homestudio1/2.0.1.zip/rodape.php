	 <!--=======footer=================================-->
		  <footer>
			  <div class="footer_section">
		  		<div class="container_24">
						<div class="grid_24">
							<div class="grid_12 alpha">
								<strong class="fa fa-map-marker"></strong>
								<p><?php echo $endereco; ?></p>
							</div>
							<div class="grid_12 omega">
								<strong class="fa fa-phone"></strong>
								<p>LIGUE AGORA: <span class="color3"><?php echo $telefone; ?></span></p>
							</div>
							
					  </div>
					</div>
				</div>
				
				
				<div class="main-footer">
					 <div class="container_24">
						  <div class="grid_24">
						  	<ul class="soc_icons">
									<li><a href="<?php echo $facebook_url; ?>" target="_bank"><i class="fa fa-facebook"></i></a></li>
									<li><a href="<?php echo $twitter_url; ?>" target="_bank"><i class="fa fa-twitter"></i></a></li>
									<li><a href="<?php echo $soundcloud_url; ?>" target="_bank"><i class="fa fa-soundcloud"></i></a></li>
									<li><a href="<?php echo $youtube_url; ?>" target="_bank"><i class="fa fa-youtube"></i></a></li>
									<li><a href="<?php echo $google_url; ?>" target="_bank"><i class="fa fa-google-plus"></i></a></li>
								</ul>
								<p><span class="color4"><?php echo $page_title; ?></span> &copy;
								<!--{%FOOTER_LINK} -->
								</p>

						  </div>
					 </div>
				</div>
		  </footer>
</div>
<script src="admin/plugins/jquery/tracking.js"></script>
<script type="text/javascript">

	var slideIndex = 1;
	showSlides(slideIndex);

	function plusSlides(n) {
	  showSlides(slideIndex += n);
	}

	function currentSlide(n) {
	  showSlides(slideIndex = n);
	}

	function showSlides(n) {
	  var i;
	  var slides = document.getElementsByClassName("mySlides");
	  var dots = document.getElementsByClassName("dot");
	  if (n > slides.length) {slideIndex = 1}    
	  if (n < 1) {slideIndex = slides.length}
	  for (i = 0; i < slides.length; i++) {
	      slides[i].style.display = "none";  
	  }
	  for (i = 0; i < dots.length; i++) {
	      dots[i].className = dots[i].className.replace(" active", "");
	  }
	  slides[slideIndex-1].style.display = "block";  
	  dots[slideIndex-1].className += " active";
	}


</script>
		<script src="/admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>
		<script type="text/javascript">

  var _gaq = _gaq || [];

  _gaq.push(['_setAccount', '<?php echo $analytics_id; ?>']);

  _gaq.push(['_trackPageview']);

  (function() {

    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;

    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';

    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

  })();

</script>